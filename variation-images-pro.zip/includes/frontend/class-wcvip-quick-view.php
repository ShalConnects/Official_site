<?php
/**
 * Quick view functionality (Pro feature)
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Quick view class
 */
class WCVIP_Quick_View {

	/**
	 * Initialize quick view functionality
	 */
	public function init() {
		add_action( 'woocommerce_single_product_summary', array( $this, 'add_quick_view_support' ), 5 );
		add_filter( 'woocommerce_product_variation_get_image', array( $this, 'get_variation_image_for_quick_view' ), 10, 2 );
	}

	/**
	 * Add quick view support
	 */
	public function add_quick_view_support() {
		// Quick view integration
	}

	/**
	 * Get variation image for quick view
	 */
	public function get_variation_image_for_quick_view( $image, $variation ) {
		$variation_id = $variation->get_id();
		$custom_images = get_post_meta( $variation_id, '_wcvip_images', true );

		if ( ! empty( $custom_images ) && is_array( $custom_images ) ) {
			$primary_image = null;
			foreach ( $custom_images as $img ) {
				if ( ! empty( $img['is_primary'] ) ) {
					$primary_image = $img;
					break;
				}
			}

			if ( ! $primary_image && ! empty( $custom_images[0] ) ) {
				$primary_image = $custom_images[0];
			}

			if ( $primary_image && isset( $primary_image['id'] ) ) {
				$image_id = absint( $primary_image['id'] );
				return wp_get_attachment_image( $image_id, 'woocommerce_thumbnail', false, array( 'class' => 'wcvip-quick-view-image' ) );
			}
		}

		return $image;
	}
}

