<?php
/**
 * The frontend-specific functionality of the plugin
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The frontend-specific functionality of the plugin
 */
class WCVIP_Frontend {

	/**
	 * The ID of this plugin
	 */
	private $plugin_name;

	/**
	 * The version of this plugin
	 */
	private $version;

	/**
	 * Initialize the class and set its properties
	 */
	public function __construct( $plugin_name, $version ) {
		$this->plugin_name = $plugin_name;
		$this->version     = $version;
		
		// Register shortcode
		add_shortcode( 'wcvip_variation_selector', array( $this, 'render_shortcode' ) );
	}

	/**
	 * Register the stylesheets for the frontend
	 */
	public function enqueue_styles() {
		$load_on_all = false;

		if ( WCVIP_IS_PRO ) {
			$shop_enabled = get_option( 'wcvip_enable_shop', 'no' );
			$load_on_all  = 'yes' === $shop_enabled;
		}

		if ( ! is_product() && ! $load_on_all ) {
			return;
		}

		wp_enqueue_style(
			$this->plugin_name,
			WCVIP_PLUGIN_URL . 'public/css/wcvip-public.css',
			array(),
			$this->version,
			'all'
		);

		$display_style = get_option( 'wcvip_display_style', 'basic' );
	}

	/**
	 * Register the JavaScript for the frontend
	 */
	public function enqueue_scripts() {
		$load_on_all = false;

		if ( WCVIP_IS_PRO ) {
			$shop_enabled = get_option( 'wcvip_enable_shop', 'no' );
			$load_on_all  = 'yes' === $shop_enabled;
		}

		if ( ! is_product() && ! $load_on_all ) {
			return;
		}

		wp_enqueue_script(
			$this->plugin_name,
			WCVIP_PLUGIN_URL . 'public/js/wcvip-public.js',
			array( 'jquery' ),
			$this->version,
			true
		);

		wp_enqueue_script(
			'wcvip-variation-handler',
			WCVIP_PLUGIN_URL . 'public/js/wcvip-variation-handler.js',
			array( 'jquery', $this->plugin_name ),
			$this->version,
			true
		);

		wp_localize_script(
			$this->plugin_name,
			'wcvipFrontend',
			array(
				'displayStyle'        => get_option( 'wcvip_display_style', 'none' ),
				'lazyLoad'            => get_option( 'wcvip_lazy_load', 'no' ),
				'isPro'               => WCVIP_IS_PRO,
				'displayInDropdown'   => get_option( 'wcvip_display_in_dropdown', 'no' ),
				'displayThumbnails'   => get_option( 'wcvip_display_thumbnails', 'yes' ),
				'ajaxurl'             => admin_url( 'admin-ajax.php' ),
				'savePreviewNonce'    => wp_create_nonce( 'wcvip-save-preview' ),
			)
		);

		// Enqueue variation dropdown enhancement if enabled
		if ( 'yes' === get_option( 'wcvip_display_in_dropdown', 'no' ) ) {
			wp_enqueue_script(
				'wcvip-variation-dropdown',
				WCVIP_PLUGIN_URL . 'public/js/wcvip-variation-dropdown.js',
				array( 'jquery', $this->plugin_name ),
				$this->version,
				true
			);
		}

		// Enqueue variation display handler based on selected style
		$display_style = get_option( 'wcvip_display_style', 'none' );
		
		// Check if Pro style is selected but user is on free version
		$pro_styles = array( 'circular', 'rectangular', 'grid', 'strip', 'radio', 'custom', 'slider', 'carousel', 'gallery', 'hover', 'zoom' );
		if ( ! WCVIP_IS_PRO && in_array( $display_style, $pro_styles, true ) ) {
			// Fallback to free style
			$display_style = 'square';
			update_option( 'wcvip_display_style', 'square' );
		}

		// Enqueue display handler for Pro styles (only if not 'none')
		if ( 'none' !== $display_style && WCVIP_IS_PRO && in_array( $display_style, $pro_styles, true ) ) {
			wp_enqueue_script(
				'wcvip-variation-display',
				WCVIP_PLUGIN_URL . 'public/js/wcvip-variation-display.js',
				array( 'jquery', $this->plugin_name, 'wcvip-variation-handler' ),
				$this->version,
				true
			);
		}

		// Always enqueue variation selector handler if custom selector is used (not 'none' or 'dropdown')
		// Also check if there's a product-specific style that might render a selector
		$should_enqueue_selector = false;
		
		if ( 'none' !== $display_style && 'dropdown' !== $display_style ) {
			$should_enqueue_selector = true;
		} else {
			// Check if we're on a product page and if product has custom style
			if ( is_product() ) {
				// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce global $product is standard
				global $product;
				if ( $product && $product->is_type( 'variable' ) ) {
					$product_style = get_post_meta( $product->get_id(), '_wcvip_display_style', true );
					if ( ! empty( $product_style ) && 'none' !== $product_style && 'dropdown' !== $product_style ) {
						$should_enqueue_selector = true;
					}
				}
			}
		}
		
		if ( $should_enqueue_selector ) {
			// Use 'jquery' as primary dependency, WooCommerce scripts may not always be available
			wp_enqueue_script(
				'wcvip-variation-selector',
				WCVIP_PLUGIN_URL . 'public/js/wcvip-variation-selector.js',
				array( 'jquery' ),
				$this->version,
				true
			);
		}
	}

	/**
	 * Render shortcode for variation selector
	 * 
	 * Usage: [wcvip_variation_selector product_id="123" style="square"]
	 * 
	 * @param array $atts Shortcode attributes
	 * @return string Shortcode output
	 */
	public function render_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'product_id' => 0,
				'style'      => '',
			),
			$atts,
			'wcvip_variation_selector'
		);

		$product_id = absint( $atts['product_id'] );
		
		// If no product_id, try to get from global product
		if ( ! $product_id && is_product() ) {
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce global $product is standard
			global $product;
			if ( $product ) {
				$product_id = $product->get_id();
			}
		}

		if ( ! $product_id ) {
			return '<p class="wcvip-shortcode-error">' . esc_html__( 'Please specify a product ID.', 'wc-variation-images-pro' ) . '</p>';
		}

		$shortcode_product = wc_get_product( $product_id );
		if ( ! $shortcode_product || ! $shortcode_product->is_type( 'variable' ) ) {
			return '<p class="wcvip-shortcode-error">' . esc_html__( 'Invalid product or product is not variable.', 'wc-variation-images-pro' ) . '</p>';
		}

		// Temporarily override display style if specified
		$original_style = null;
		if ( ! empty( $atts['style'] ) ) {
			$original_style = get_option( 'wcvip_display_style', 'none' );
			update_option( 'wcvip_display_style', sanitize_text_field( $atts['style'] ) );
		}

		// Temporarily set global product for frontend renderer
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce global $product is standard
		global $product;
		$original_global_product = isset( $product ) ? $product : null;
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce global $product is standard
		$product = $shortcode_product;

		// Use the frontend product page class to render selector
		$product_page = new WCVIP_Product_Page();
		
		// Capture output
		ob_start();
		$product_page->render_custom_variation_selector();
		$selector_html = ob_get_clean();

		// Restore original product and style
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce global $product is standard
		$product = $original_global_product;
		if ( $original_style !== null ) {
			update_option( 'wcvip_display_style', $original_style );
		}

		// Ensure scripts/styles are enqueued even if not on product page
		$this->enqueue_styles();
		$this->enqueue_scripts();

		return $selector_html;
	}
}

