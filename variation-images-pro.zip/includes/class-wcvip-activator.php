<?php
/**
 * Fired during plugin activation
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Fired during plugin activation
 */
class WCVIP_Activator {

	/**
	 * Activation tasks
	 */
	public static function activate() {
		// Check WooCommerce is active
		if ( ! class_exists( 'WooCommerce' ) ) {
			deactivate_plugins( plugin_basename( __FILE__ ) );
			wp_die(
				esc_html__( 'Variation Images Pro for WooCommerce requires WooCommerce to be installed and activated.', 'wc-variation-images-pro' ),
				esc_html__( 'Plugin Activation Error', 'wc-variation-images-pro' ),
				array( 'back_link' => true )
			);
		}

		// Set default options
		$defaults = array(
			'wcvip_display_style' => 'none',
			'wcvip_lazy_load'     => WCVIP_IS_PRO ? 'yes' : 'no',
			'wcvip_show_badge'    => WCVIP_IS_PRO ? 'no' : 'yes',
			'wcvip_image_limit'   => WCVIP_IS_PRO ? 0 : 1, // 0 = unlimited for Pro
		);

		foreach ( $defaults as $key => $value ) {
			if ( get_option( $key ) === false ) {
				add_option( $key, $value );
			}
		}

		// Create security logs table
		self::create_security_logs_table();

		// Schedule security log cleanup (runs daily)
		if ( ! wp_next_scheduled( 'wcvip_clean_security_logs' ) ) {
			wp_schedule_event( time(), 'daily', 'wcvip_clean_security_logs' );
		}

		// Flush rewrite rules
		flush_rewrite_rules();

		// Set activation flag
		set_transient( 'wcvip_activated', true, 30 );
	}

	/**
	 * Create security logs database table
	 */
	private static function create_security_logs_table() {
		global $wpdb;
		$charset_collate = $wpdb->get_charset_collate();
		$table_name = $wpdb->prefix . 'wcvip_security_logs';
		
		$sql = "CREATE TABLE IF NOT EXISTS $table_name (
			id bigint(20) NOT NULL AUTO_INCREMENT,
			timestamp datetime NOT NULL,
			event_type varchar(50) NOT NULL,
			message text NOT NULL,
			user_id bigint(20) DEFAULT 0,
			ip_address varchar(45) NOT NULL,
			user_agent text,
			request_uri text,
			context longtext,
			PRIMARY KEY (id),
			KEY event_type (event_type),
			KEY timestamp (timestamp),
			KEY user_id (user_id)
		) $charset_collate;";
		
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
	}
}

