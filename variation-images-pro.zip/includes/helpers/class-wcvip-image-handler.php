<?php
/**
 * Image handler for processing and optimization
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Image handler class
 */
class WCVIP_Image_Handler {

	/**
	 * Get variation images
	 */
	public static function get_variation_images( $variation_id ) {
		$custom_images = get_post_meta( $variation_id, '_wcvip_images', true );

		if ( ! is_array( $custom_images ) ) {
			return array();
		}

		// Validate and process images
		$processed_images = array();

		foreach ( $custom_images as $image ) {
			if ( ! isset( $image['id'] ) || ! is_numeric( $image['id'] ) ) {
				continue;
			}

			$image_id = absint( $image['id'] );

			if ( ! wp_attachment_is_image( $image_id ) ) {
				continue;
			}

			$processed_images[] = array(
				'id'         => $image_id,
				'url'        => isset( $image['url'] ) ? esc_url( $image['url'] ) : wp_get_attachment_image_url( $image_id, 'full' ),
				'thumbnail'  => isset( $image['thumbnail'] ) ? esc_url( $image['thumbnail'] ) : wp_get_attachment_image_url( $image_id, 'thumbnail' ),
				'alt'        => isset( $image['alt'] ) ? sanitize_text_field( $image['alt'] ) : get_post_meta( $image_id, '_wp_attachment_image_alt', true ),
				'is_primary' => isset( $image['is_primary'] ) ? (bool) $image['is_primary'] : false,
			);
		}

		return $processed_images;
	}

	/**
	 * Save variation images
	 */
	public static function save_variation_images( $variation_id, $images ) {
		if ( ! is_array( $images ) ) {
			return false;
		}

		// Sanitize images
		$sanitized_images = array();

		foreach ( $images as $image ) {
			if ( ! isset( $image['id'] ) || ! is_numeric( $image['id'] ) ) {
				continue;
			}

			$image_id = absint( $image['id'] );

			if ( ! wp_attachment_is_image( $image_id ) ) {
				continue;
			}

			$sanitized_images[] = array(
				'id'         => $image_id,
				'url'        => isset( $image['url'] ) ? esc_url_raw( $image['url'] ) : wp_get_attachment_image_url( $image_id, 'full' ),
				'thumbnail'  => isset( $image['thumbnail'] ) ? esc_url_raw( $image['thumbnail'] ) : wp_get_attachment_image_url( $image_id, 'thumbnail' ),
				'alt'        => isset( $image['alt'] ) ? sanitize_text_field( $image['alt'] ) : get_post_meta( $image_id, '_wp_attachment_image_alt', true ),
				'is_primary' => isset( $image['is_primary'] ) ? (bool) $image['is_primary'] : false,
			);
		}

		// Check limit for free version
		if ( ! WCVIP_IS_PRO && count( $sanitized_images ) > 1 ) {
			return new WP_Error( 'image_limit', __( 'Free version is limited to 1 image per variation. Upgrade to Pro for unlimited images!', 'wc-variation-images-pro' ) );
		}

		update_post_meta( $variation_id, '_wcvip_images', $sanitized_images );

		// Update primary image
		if ( ! empty( $sanitized_images ) ) {
			$primary_image = null;
			foreach ( $sanitized_images as $image ) {
				if ( ! empty( $image['is_primary'] ) ) {
					$primary_image = $image;
					break;
				}
			}

			if ( ! $primary_image && ! empty( $sanitized_images[0] ) ) {
				$primary_image = $sanitized_images[0];
			}

			if ( $primary_image ) {
				update_post_meta( $variation_id, '_thumbnail_id', $primary_image['id'] );
			}
		}

		return true;
	}

	/**
	 * Optimize image (Pro feature)
	 */
	public static function optimize_image( $image_id ) {
		if ( ! WCVIP_IS_PRO ) {
			return false;
		}

		// Image optimization logic would go here
		// Could integrate with services like TinyPNG, ShortPixel, etc.

		return true;
	}
}

