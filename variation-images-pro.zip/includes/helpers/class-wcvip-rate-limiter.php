<?php
/**
 * Rate limiter for AJAX endpoints
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Rate limiter class
 */
class WCVIP_Rate_Limiter {

	/**
	 * Check if request is within rate limit
	 *
	 * @param string $action Action name (e.g., 'wcvip_save_images').
	 * @param int    $max_requests Maximum requests allowed.
	 * @param int    $time_window Time window in seconds.
	 * @return bool|WP_Error True if allowed, WP_Error if rate limited.
	 */
	public static function check_rate_limit( $action, $max_requests = 10, $time_window = 60 ) {
		$user_id = get_current_user_id();
		$ip_address = self::get_client_ip();
		
		// Use IP for non-logged-in users, user ID for logged-in users
		$identifier = $user_id > 0 ? "user_{$user_id}" : "ip_{$ip_address}";
		$transient_key = "wcvip_rate_limit_{$action}_{$identifier}";
		
		$requests = get_transient( $transient_key );
		
		if ( false === $requests ) {
			// First request in this window
			set_transient( $transient_key, 1, $time_window );
			return true;
		}
		
		if ( $requests >= $max_requests ) {
			$remaining = get_option( "_transient_timeout_{$transient_key}" ) - time();
			return new WP_Error(
				'rate_limit_exceeded',
				sprintf(
					// translators: %d is the number of seconds to wait
					__( 'Rate limit exceeded. Please wait %d seconds before trying again.', 'wc-variation-images-pro' ),
					$remaining
				),
				array( 'status' => 429, 'retry_after' => $remaining )
			);
		}
		
		// Increment request count
		set_transient( $transient_key, $requests + 1, $time_window );
		return true;
	}

	/**
	 * Get client IP address
	 *
	 * @return string IP address.
	 */
	private static function get_client_ip() {
		$ip_keys = array(
			'HTTP_CF_CONNECTING_IP', // Cloudflare
			'HTTP_X_REAL_IP',
			'HTTP_X_FORWARDED_FOR',
			'REMOTE_ADDR',
		);

		foreach ( $ip_keys as $key ) {
			if ( ! empty( $_SERVER[ $key ] ) ) {
				$ip = sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) );
				// Handle comma-separated IPs (from proxies)
				if ( strpos( $ip, ',' ) !== false ) {
					$ip = explode( ',', $ip )[0];
				}
				return trim( $ip );
			}
		}

		return '0.0.0.0';
	}

	/**
	 * Clear rate limit for a specific action and identifier
	 *
	 * @param string $action Action name.
	 * @param string $identifier User ID or IP.
	 */
	public static function clear_rate_limit( $action, $identifier ) {
		$transient_key = "wcvip_rate_limit_{$action}_{$identifier}";
		delete_transient( $transient_key );
	}
}



