<?php
/**
 * Security event logger
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Security logger class
 */
class WCVIP_Security_Logger {

	/**
	 * Log security event
	 *
	 * @param string $event_type Event type (e.g., 'nonce_failed', 'permission_denied').
	 * @param string $message Log message.
	 * @param array  $context Additional context data.
	 */
	public static function log( $event_type, $message, $context = array() ) {
		// Only log if logging is enabled
		if ( ! self::is_logging_enabled() ) {
			return;
		}

		$log_entry = array(
			'timestamp' => current_time( 'mysql' ),
			'event_type' => sanitize_key( $event_type ),
			'message' => sanitize_text_field( $message ),
			'user_id' => get_current_user_id(),
			'ip_address' => self::get_client_ip(),
			'user_agent' => isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '',
			'request_uri' => isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '',
			'context' => $context,
		);

		// Log to WordPress debug log
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Security logging properly guarded by WP_DEBUG and WP_DEBUG_LOG
			error_log( sprintf(
				'[WCVIP Security] %s: %s | User: %d | IP: %s | Context: %s',
				$log_entry['event_type'],
				$log_entry['message'],
				$log_entry['user_id'],
				$log_entry['ip_address'],
				wp_json_encode( $log_entry['context'] )
			) );
		}

		// Optionally store in database (for admin dashboard viewing)
		if ( self::is_database_logging_enabled() ) {
			self::store_log_entry( $log_entry );
		}
	}

	/**
	 * Check if logging is enabled
	 *
	 * @return bool
	 */
	private static function is_logging_enabled() {
		return 'yes' === get_option( 'wcvip_security_logging_enabled', 'yes' );
	}

	/**
	 * Check if database logging is enabled
	 *
	 * @return bool
	 */
	private static function is_database_logging_enabled() {
		return 'yes' === get_option( 'wcvip_security_logging_database', 'no' );
	}

	/**
	 * Store log entry in database
	 *
	 * @param array $log_entry Log entry data.
	 */
	private static function store_log_entry( $log_entry ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . 'wcvip_security_logs';
		
		// Check if table exists (escape table name for security)
		$escaped_table_name = esc_sql( $table_name );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table check required
		if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $escaped_table_name ) ) !== $table_name ) {
			// Table doesn't exist, skip database logging
			return;
		}
		
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Custom table insert required
		$wpdb->insert(
			$table_name,
			array(
				'timestamp' => $log_entry['timestamp'],
				'event_type' => $log_entry['event_type'],
				'message' => $log_entry['message'],
				'user_id' => $log_entry['user_id'],
				'ip_address' => $log_entry['ip_address'],
				'user_agent' => $log_entry['user_agent'],
				'request_uri' => $log_entry['request_uri'],
				'context' => wp_json_encode( $log_entry['context'] ),
			),
			array( '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s' )
		);
	}

	/**
	 * Get client IP address
	 *
	 * @return string IP address.
	 */
	private static function get_client_ip() {
		$ip_keys = array(
			'HTTP_CF_CONNECTING_IP',
			'HTTP_X_REAL_IP',
			'HTTP_X_FORWARDED_FOR',
			'REMOTE_ADDR',
		);

		foreach ( $ip_keys as $key ) {
			if ( ! empty( $_SERVER[ $key ] ) ) {
				$ip = sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) );
				if ( strpos( $ip, ',' ) !== false ) {
					$ip = explode( ',', $ip )[0];
				}
				return trim( $ip );
			}
		}

		return '0.0.0.0';
	}

	/**
	 * Get recent security logs
	 *
	 * @param int $limit Number of logs to retrieve.
	 * @return array Log entries.
	 */
	public static function get_recent_logs( $limit = 50 ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'wcvip_security_logs';
		
		// Check if table exists (escape table name for security)
		$escaped_table_name = esc_sql( $table_name );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table check required
		if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $escaped_table_name ) ) !== $table_name ) {
			return array();
		}
		return $wpdb->get_results(
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Custom table query, table name already escaped with esc_sql()
			$wpdb->prepare(
				"SELECT * FROM `{$escaped_table_name}` ORDER BY timestamp DESC LIMIT %d",
				$limit
			),
			ARRAY_A
		);
	}

	/**
	 * Clean old logs (run via cron)
	 */
	public static function clean_old_logs() {
		global $wpdb;
		$table_name = $wpdb->prefix . 'wcvip_security_logs';
		
		// Check if table exists (escape table name for security)
		$escaped_table_name = esc_sql( $table_name );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table check required
		if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $escaped_table_name ) ) !== $table_name ) {
			return;
		}
		
		$retention_days = absint( get_option( 'wcvip_security_log_retention_days', 30 ) );
		$wpdb->query(
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Custom table query, table name already escaped with esc_sql()
			$wpdb->prepare(
				"DELETE FROM `{$escaped_table_name}` WHERE timestamp < DATE_SUB(NOW(), INTERVAL %d DAY)",
				$retention_days
			)
		);
	}
}

