<?php
/**
 * Attribute helper for analyzing and grouping variation attributes
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Attribute helper class
 */
class WCVIP_Attribute_Helper {

	/**
	 * Get all unique attributes from variations data
	 *
	 * @param array $variations_data Array of variation data
	 * @return array Associative array of attribute names and their values
	 */
	public static function get_product_attributes( $variations_data ) {
		$all_attributes = array();

		foreach ( $variations_data as $variation ) {
			if ( ! isset( $variation['attributes'] ) || ! is_array( $variation['attributes'] ) ) {
				continue;
			}

			foreach ( $variation['attributes'] as $attr_name => $attr_value ) {
				// Clean attribute name (remove 'attribute_' prefix)
				$clean_name = str_replace( 'attribute_', '', $attr_name );
				
				if ( ! isset( $all_attributes[ $clean_name ] ) ) {
					$all_attributes[ $clean_name ] = array();
				}

				if ( ! empty( $attr_value ) && ! in_array( $attr_value, $all_attributes[ $clean_name ], true ) ) {
					$all_attributes[ $clean_name ][] = $attr_value;
				}
			}
		}

		return $all_attributes;
	}

	/**
	 * Count number of unique attributes
	 *
	 * @param array $variations_data Array of variation data
	 * @return int Number of unique attributes
	 */
	public static function count_attributes( $variations_data ) {
		$attributes = self::get_product_attributes( $variations_data );
		return count( $attributes );
	}

	/**
	 * Check if product has only one attribute
	 *
	 * @param array $variations_data Array of variation data
	 * @return bool True if single attribute, false otherwise
	 */
	public static function is_single_attribute( $variations_data ) {
		return self::count_attributes( $variations_data ) === 1;
	}

	/**
	 * Check if product has multiple attributes
	 *
	 * @param array $variations_data Array of variation data
	 * @return bool True if multiple attributes, false otherwise
	 */
	public static function is_multi_attribute( $variations_data ) {
		return self::count_attributes( $variations_data ) > 1;
	}

	/**
	 * Get primary attribute name (for grouping)
	 * Priority: Color > Size > First alphabetically > First in data
	 *
	 * @param array $variations_data Array of variation data
	 * @return string|null Primary attribute name (with 'attribute_' prefix) or null
	 */
	public static function get_primary_attribute( $variations_data ) {
		$attributes = self::get_product_attributes( $variations_data );
		
		if ( empty( $attributes ) ) {
			return null;
		}

		// Priority order: Color > Size > First alphabetically
		$priority_attributes = array( 'pa_color', 'color', 'pa_size', 'size' );

		// Check for priority attributes
		foreach ( $priority_attributes as $priority_attr ) {
			if ( isset( $attributes[ $priority_attr ] ) ) {
				// Return with proper prefix
				return 'attribute_' . $priority_attr;
			}
		}

		// If no priority attribute, get first attribute from first variation
		if ( ! empty( $variations_data[0]['attributes'] ) ) {
			$first_attr = key( $variations_data[0]['attributes'] );
			return $first_attr;
		}

		// Fallback: first attribute alphabetically
		$sorted_attrs = array_keys( $attributes );
		sort( $sorted_attrs );
		if ( ! empty( $sorted_attrs[0] ) ) {
			// Check if we need to add prefix
			$first_attr_name = $sorted_attrs[0];
			// Try with prefix first
			if ( ! empty( $variations_data[0]['attributes'][ 'attribute_' . $first_attr_name ] ) ) {
				return 'attribute_' . $first_attr_name;
			}
			// Try without prefix
			if ( ! empty( $variations_data[0]['attributes'][ $first_attr_name ] ) ) {
				return $first_attr_name;
			}
		}

		return null;
	}

	/**
	 * Get secondary attributes (all except primary)
	 *
	 * @param array $variations_data Array of variation data
	 * @return array Array of secondary attribute names (with 'attribute_' prefix)
	 */
	public static function get_secondary_attributes( $variations_data ) {
		$primary = self::get_primary_attribute( $variations_data );
		$all_attributes = self::get_product_attributes( $variations_data );
		$secondary = array();

		if ( empty( $primary ) ) {
			return array();
		}

		// Remove 'attribute_' prefix for comparison
		$primary_clean = str_replace( 'attribute_', '', $primary );

		foreach ( $all_attributes as $attr_name => $values ) {
			if ( $attr_name !== $primary_clean ) {
				// Try to find the correct key format
				if ( ! empty( $variations_data[0]['attributes'][ 'attribute_' . $attr_name ] ) ) {
					$secondary[] = 'attribute_' . $attr_name;
				} elseif ( ! empty( $variations_data[0]['attributes'][ $attr_name ] ) ) {
					$secondary[] = $attr_name;
				}
			}
		}

		return $secondary;
	}

	/**
	 * Group variations by primary attribute value
	 *
	 * @param array $variations_data Array of variation data
	 * @return array Grouped variations: array( 'primary_value' => array( variations ) )
	 */
	public static function group_variations_by_primary( $variations_data ) {
		$primary_attr = self::get_primary_attribute( $variations_data );
		
		if ( empty( $primary_attr ) ) {
			// If no primary attribute, return ungrouped
			return array( 'all' => $variations_data );
		}

		$grouped = array();

		foreach ( $variations_data as $variation ) {
			if ( ! isset( $variation['attributes'][ $primary_attr ] ) ) {
				continue;
			}

			$primary_value = $variation['attributes'][ $primary_attr ];
			
			if ( ! isset( $grouped[ $primary_value ] ) ) {
				$grouped[ $primary_value ] = array();
			}

			$grouped[ $primary_value ][] = $variation;
		}

		return $grouped;
	}

	/**
	 * Get attribute display name (formatted for display)
	 *
	 * @param string $attribute_name Attribute name (with or without prefix)
	 * @return string Formatted display name
	 */
	public static function get_attribute_display_name( $attribute_name ) {
		// Remove 'attribute_' prefix
		$clean_name = str_replace( 'attribute_', '', $attribute_name );
		
		// Remove 'pa_' prefix if present
		if ( strpos( $clean_name, 'pa_' ) === 0 ) {
			$clean_name = substr( $clean_name, 3 );
		}

		// Convert to readable format
		$display_name = ucwords( str_replace( array( '-', '_' ), ' ', $clean_name ) );

		return $display_name;
	}

	/**
	 * Get attribute value display name
	 *
	 * @param string $attribute_name Full attribute name (with prefix)
	 * @param string $attribute_value Attribute value (slug or term)
	 * @return string Formatted display value
	 */
	public static function get_attribute_value_display_name( $attribute_name, $attribute_value ) {
		// Try to get term name if it's a taxonomy
		$clean_attr_name = str_replace( 'attribute_', '', $attribute_name );
		
		// Check if it's a taxonomy (starts with pa_)
		if ( strpos( $clean_attr_name, 'pa_' ) === 0 ) {
			$taxonomy = $clean_attr_name;
			if ( taxonomy_exists( $taxonomy ) ) {
				$term = get_term_by( 'slug', $attribute_value, $taxonomy );
				if ( $term ) {
					return $term->name;
				}
			}
		}

		// Fallback: return formatted value
		return ucwords( str_replace( array( '-', '_' ), ' ', $attribute_value ) );
	}

	/**
	 * Determine display strategy based on attribute count
	 *
	 * @param array $variations_data Array of variation data
	 * @return string Strategy: 'single', 'two_attributes', 'multi_attributes'
	 */
	public static function get_display_strategy( $variations_data ) {
		$count = self::count_attributes( $variations_data );

		if ( $count === 1 ) {
			return 'single';
		} elseif ( $count === 2 ) {
			return 'two_attributes';
		} else {
			return 'multi_attributes';
		}
	}
}

