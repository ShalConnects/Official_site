<?php
/**
 * Auto-updater for Pro version (Pro feature)
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Updater class
 */
class WCVIP_Updater {

	/**
	 * Update server URL
	 */
	const UPDATE_SERVER = 'https://your-update-server.com';

	/**
	 * Initialize updater
	 */
	public function __construct() {
		add_filter( 'plugins_api', array( $this, 'plugin_info' ), 20, 3 );
		add_filter( 'site_transient_update_plugins', array( $this, 'push_update' ) );
		add_action( 'upgrader_process_complete', array( $this, 'after_update' ), 10, 2 );
	}

	/**
	 * Get plugin info from update server
	 */
	public function plugin_info( $res, $action, $args ) {
		if ( 'plugin_information' !== $action ) {
			return $res;
		}

		if ( WCVIP_PLUGIN_BASENAME !== $args->slug ) {
			return $res;
		}

		// Get plugin info from update server
		$remote = wp_remote_get(
			self::UPDATE_SERVER . '/wp-json/wcvip/v1/plugin-info',
			array(
				'timeout' => 10,
				'headers' => array(
					'Accept' => 'application/json',
				),
			)
		);

		if ( is_wp_error( $remote ) ) {
			return $res;
		}

		$remote = json_decode( wp_remote_retrieve_body( $remote ), true );

		if ( ! $remote || ! is_array( $remote ) ) {
			return $res;
		}

		// Validate and sanitize remote data
		if ( ! isset( $remote['name'], $remote['version'] ) ) {
			return $res;
		}

		$res = new stdClass();
		$res->name = sanitize_text_field( $remote['name'] );
		$res->slug = WCVIP_PLUGIN_BASENAME;
		$res->version = sanitize_text_field( $remote['version'] );
		$res->tested = isset( $remote['tested'] ) ? sanitize_text_field( $remote['tested'] ) : '';
		$res->requires = isset( $remote['requires'] ) ? sanitize_text_field( $remote['requires'] ) : '';
		$res->author = isset( $remote['author'] ) ? sanitize_text_field( $remote['author'] ) : '';
		$res->author_profile = isset( $remote['author_profile'] ) ? esc_url_raw( $remote['author_profile'] ) : '';
		$res->download_link = isset( $remote['download_link'] ) ? esc_url_raw( $remote['download_link'] ) : '';
		$res->trunk = sanitize_text_field( $remote['version'] );
		$res->requires_php = isset( $remote['requires_php'] ) ? sanitize_text_field( $remote['requires_php'] ) : '';
		$res->last_updated = isset( $remote['last_updated'] ) ? sanitize_text_field( $remote['last_updated'] ) : '';
		$res->sections = array(
			'description' => isset( $remote['sections']['description'] ) ? wp_kses_post( $remote['sections']['description'] ) : '',
			'installation' => isset( $remote['sections']['installation'] ) ? wp_kses_post( $remote['sections']['installation'] ) : '',
			'changelog' => isset( $remote['sections']['changelog'] ) ? wp_kses_post( $remote['sections']['changelog'] ) : '',
		);

		return $res;
	}

	/**
	 * Push update to WordPress
	 */
	public function push_update( $transient ) {
		if ( empty( $transient->checked ) ) {
			return $transient;
		}

		// Get remote version
		$remote = wp_remote_get(
			self::UPDATE_SERVER . '/wp-json/wcvip/v1/version',
			array(
				'timeout' => 10,
				'headers' => array(
					'Accept' => 'application/json',
				),
			)
		);

		if ( is_wp_error( $remote ) ) {
			return $transient;
		}

		$remote = json_decode( wp_remote_retrieve_body( $remote ), true );

		if ( $remote && is_array( $remote ) && isset( $remote['version'] ) && version_compare( WCVIP_VERSION, sanitize_text_field( $remote['version'] ), '<' ) ) {
			$res = new stdClass();
			$res->slug = WCVIP_PLUGIN_BASENAME;
			$res->plugin = WCVIP_PLUGIN_BASENAME;
			$res->new_version = sanitize_text_field( $remote['version'] );
			$res->tested = isset( $remote['tested'] ) ? sanitize_text_field( $remote['tested'] ) : '';
			$res->package = isset( $remote['download_link'] ) ? esc_url_raw( $remote['download_link'] ) : '';
			$transient->response[ WCVIP_PLUGIN_BASENAME ] = $res;
		}

		return $transient;
	}

	/**
	 * After update
	 */
	public function after_update( $upgrader_object, $options ) {
		if ( 'update' === $options['action'] && 'plugin' === $options['type'] ) {
			if ( isset( $options['plugins'] ) && in_array( WCVIP_PLUGIN_BASENAME, $options['plugins'], true ) ) {
				// Clear any caches
				flush_rewrite_rules();
			}
		}
	}
}

