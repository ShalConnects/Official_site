<?php
/**
 * The core plugin class
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main plugin class
 */
class WCVIP_Core {

	/**
	 * The loader that's responsible for maintaining and registering all hooks
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin
	 */
	public function __construct() {
		$this->version     = WCVIP_VERSION;
		$this->plugin_name = 'wc-variation-images-pro';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_frontend_hooks();
		$this->define_api_hooks();
		$this->define_integration_hooks();
	}

	/**
	 * Load the required dependencies for this plugin
	 */
	private function load_dependencies() {
		require_once WCVIP_PLUGIN_DIR . 'includes/class-wcvip-loader.php';
		require_once WCVIP_PLUGIN_DIR . 'includes/class-wcvip-i18n.php';

		require_once WCVIP_PLUGIN_DIR . 'includes/admin/class-wcvip-admin.php';
		require_once WCVIP_PLUGIN_DIR . 'includes/admin/class-wcvip-meta-boxes.php';
		require_once WCVIP_PLUGIN_DIR . 'includes/admin/class-wcvip-settings.php';
		require_once WCVIP_PLUGIN_DIR . 'includes/admin/class-wcvip-visual-designer.php';
		require_once WCVIP_PLUGIN_DIR . 'includes/admin/class-wcvip-deactivation-feedback.php';
		
		if ( WCVIP_IS_PRO ) {
			require_once WCVIP_PLUGIN_DIR . 'includes/admin/class-wcvip-bulk-actions.php';
			require_once WCVIP_PLUGIN_DIR . 'includes/admin/class-wcvip-csv-handler.php';
		}

		require_once WCVIP_PLUGIN_DIR . 'includes/frontend/class-wcvip-frontend.php';
		require_once WCVIP_PLUGIN_DIR . 'includes/frontend/class-wcvip-product-page.php';
		
		if ( WCVIP_IS_PRO ) {
			require_once WCVIP_PLUGIN_DIR . 'includes/frontend/class-wcvip-shop-page.php';
			require_once WCVIP_PLUGIN_DIR . 'includes/frontend/class-wcvip-quick-view.php';
			require_once WCVIP_PLUGIN_DIR . 'includes/frontend/class-wcvip-cart.php';
		}

		require_once WCVIP_PLUGIN_DIR . 'includes/api/class-wcvip-rest-api.php';
		
		if ( WCVIP_IS_PRO ) {
			require_once WCVIP_PLUGIN_DIR . 'includes/api/class-wcvip-products-endpoint.php';
			require_once WCVIP_PLUGIN_DIR . 'includes/api/class-wcvip-variations-endpoint.php';
			require_once WCVIP_PLUGIN_DIR . 'includes/api/class-wcvip-media-endpoint.php';
		}

		require_once WCVIP_PLUGIN_DIR . 'includes/integrations/class-wcvip-page-builders.php';
		
		if ( WCVIP_IS_PRO ) {
			require_once WCVIP_PLUGIN_DIR . 'includes/integrations/elementor/class-wcvip-elementor.php';
			require_once WCVIP_PLUGIN_DIR . 'includes/integrations/bricks/class-wcvip-bricks.php';
			require_once WCVIP_PLUGIN_DIR . 'includes/integrations/divi/class-wcvip-divi.php';
			require_once WCVIP_PLUGIN_DIR . 'includes/integrations/gutenberg/blocks/variation-gallery/block.php';
			
			require_once WCVIP_PLUGIN_DIR . 'includes/integrations/vendors/class-wcvip-dokan.php';
			require_once WCVIP_PLUGIN_DIR . 'includes/integrations/vendors/class-wcvip-wcfm.php';
		}

		require_once WCVIP_PLUGIN_DIR . 'includes/helpers/class-wcvip-image-handler.php';
		require_once WCVIP_PLUGIN_DIR . 'includes/helpers/class-wcvip-attribute-helper.php';
		require_once WCVIP_PLUGIN_DIR . 'includes/helpers/class-wcvip-compatibility.php';
		require_once WCVIP_PLUGIN_DIR . 'includes/helpers/class-wcvip-rate-limiter.php';
		require_once WCVIP_PLUGIN_DIR . 'includes/helpers/class-wcvip-security-logger.php';
		
		if ( WCVIP_IS_PRO ) {
			require_once WCVIP_PLUGIN_DIR . 'includes/helpers/class-wcvip-cdn-handler.php';
		}

		if ( WCVIP_IS_PRO ) {
			require_once WCVIP_PLUGIN_DIR . 'includes/licensing/class-wcvip-license.php';
			require_once WCVIP_PLUGIN_DIR . 'includes/licensing/class-wcvip-updater.php';
		}

		$this->loader = new WCVIP_Loader();
	}

	/**
	 * Define the locale for this plugin for internationalization
	 */
	private function set_locale() {
		$plugin_i18n = new WCVIP_i18n();
		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );
	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 */
	private function define_admin_hooks() {
		$plugin_admin = new WCVIP_Admin( $this->get_plugin_name(), $this->get_version() );
		
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );
		$this->loader->add_action( 'admin_menu', $plugin_admin, 'add_admin_menu' );
		
		// Add AJAX handlers
		$this->loader->add_action( 'wp_ajax_wcvip_get_products', $plugin_admin, 'ajax_get_products' );
		$this->loader->add_action( 'wp_ajax_wcvip_get_variations', $plugin_admin, 'ajax_get_variations' );
		$this->loader->add_action( 'wp_ajax_wcvip_save_images', $plugin_admin, 'ajax_save_images' );
		$this->loader->add_action( 'wp_ajax_wcvip_get_images', $plugin_admin, 'ajax_get_images' );
		$this->loader->add_action( 'wp_ajax_wcvip_save_display_style', $plugin_admin, 'ajax_save_display_style' );
		$this->loader->add_action( 'wp_ajax_wcvip_get_designer_html', $plugin_admin, 'ajax_get_designer_html' );
		$this->loader->add_action( 'wp_ajax_wcvip_reset_product', $plugin_admin, 'ajax_reset_product' );
		$this->loader->add_action( 'wp_ajax_wcvip_upload_image', $plugin_admin, 'ajax_upload_image' );

		$meta_boxes = new WCVIP_Meta_Boxes();
		$this->loader->add_action( 'add_meta_boxes', $meta_boxes, 'add_meta_boxes' );
		$this->loader->add_action( 'save_post', $meta_boxes, 'save_meta_box_data' );

		$settings = new WCVIP_Settings();
		$this->loader->add_action( 'admin_init', $settings, 'register_settings' );
		$this->loader->add_action( 'admin_menu', $settings, 'add_settings_page' );

		$visual_designer = new WCVIP_Visual_Designer();
		// Visual designer hooks are registered in its constructor

		if ( WCVIP_IS_PRO ) {
			$bulk_actions = new WCVIP_Bulk_Actions();
			$this->loader->add_action( 'admin_init', $bulk_actions, 'init' );
		}

		// Register attribute term color field hooks for all WC attribute taxonomies
		$this->loader->add_action( 'admin_init', $plugin_admin, 'register_attribute_term_color_hooks' );

		// Security log cleanup cron hook (cron is scheduled in activator)
		$this->loader->add_action( 'wcvip_clean_security_logs', 'WCVIP_Security_Logger', 'clean_old_logs' );

		// Deactivation feedback system
		$deactivation_feedback = new WCVIP_Deactivation_Feedback();
		// Hooks are registered in the constructor
	}

	/**
	 * Register all of the hooks related to the frontend functionality
	 */
	private function define_frontend_hooks() {
		$plugin_frontend = new WCVIP_Frontend( $this->get_plugin_name(), $this->get_version() );
		
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_frontend, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_frontend, 'enqueue_scripts' );

		$product_page = new WCVIP_Product_Page();
		$this->loader->add_filter( 'woocommerce_available_variation', $product_page, 'add_variation_images_to_json', 10, 3 );
		$this->loader->add_action( 'woocommerce_product_thumbnails', $product_page, 'display_variation_gallery', 25 );
		$this->loader->add_action( 'woocommerce_before_variations_form', $product_page, 'render_custom_variation_selector', 10 );
		$this->loader->add_action( 'woocommerce_before_single_product', $product_page, 'render_preview_banner', 5 );
		
		// Frontend AJAX handlers for preview mode
		$this->loader->add_action( 'wp_ajax_wcvip_save_preview_design', $product_page, 'ajax_save_preview_design' );

		if ( WCVIP_IS_PRO ) {
			$shop_page = new WCVIP_Shop_Page();
			$this->loader->add_action( 'woocommerce_before_shop_loop_item', $shop_page, 'init' );
			
			$quick_view = new WCVIP_Quick_View();
			$this->loader->add_action( 'woocommerce_single_product_summary', $quick_view, 'init' );
			
			$cart = new WCVIP_Cart();
			$this->loader->add_action( 'woocommerce_cart_item_thumbnail', $cart, 'display_cart_item_image', 10, 3 );
		}
	}

	/**
	 * Register REST API hooks
	 */
	private function define_api_hooks() {
		if ( WCVIP_IS_PRO ) {
			$rest_api = new WCVIP_REST_API();
			$this->loader->add_action( 'rest_api_init', $rest_api, 'register_routes' );
		}
	}

	/**
	 * Register integration hooks
	 */
	private function define_integration_hooks() {
		$page_builders = new WCVIP_Page_Builders();
		$this->loader->add_action( 'init', $page_builders, 'init' );

		if ( WCVIP_IS_PRO ) {
			if ( did_action( 'elementor/loaded' ) ) {
				$elementor = new WCVIP_Elementor();
				$this->loader->add_action( 'elementor/widgets/register', $elementor, 'register_widgets' );
			}

			if ( class_exists( 'Bricks\Theme' ) ) {
				$bricks = new WCVIP_Bricks();
				$this->loader->add_action( 'init', $bricks, 'init' );
			}

			if ( class_exists( 'ET_Builder_Plugin' ) ) {
				$divi = new WCVIP_Divi();
				$this->loader->add_action( 'et_builder_ready', $divi, 'init' );
			}

			// Multi-vendor support
			if ( class_exists( 'WeDevs_Dokan' ) ) {
				$dokan = new WCVIP_Dokan();
				$this->loader->add_action( 'init', $dokan, 'init' );
			}

			if ( class_exists( 'WCFM' ) ) {
				$wcfm = new WCVIP_WCFM();
				$this->loader->add_action( 'init', $wcfm, 'init' );
			}
		}
	}

	/**
	 * Run the loader to execute all of the hooks with WordPress
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin
	 */
	public function get_version() {
		return $this->version;
	}
}

