<?php
/**
 * Elementor Variation Gallery Widget (Pro feature)
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
	return;
}

/**
 * Elementor widget class
 */
class WCVIP_Elementor_Variation_Gallery_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name
	 */
	public function get_name() {
		return 'wcvip-variation-gallery';
	}

	/**
	 * Get widget title
	 */
	public function get_title() {
		return __( 'Variation Gallery', 'wc-variation-images-pro' );
	}

	/**
	 * Get widget icon
	 */
	public function get_icon() {
		return 'eicon-gallery-grid';
	}

	/**
	 * Get widget categories
	 */
	public function get_categories() {
		return array( 'woocommerce-elements' );
	}

	/**
	 * Register widget controls
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			array(
				'label' => __( 'Content', 'wc-variation-images-pro' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'product_id',
			array(
				'label'   => __( 'Product', 'wc-variation-images-pro' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => $this->get_products(),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Get products for select
	 */
	private function get_products() {
		$products = wc_get_products(
			array(
				'type'   => 'variable',
				'limit'  => -1,
				'status' => 'publish',
				'return' => 'ids',
			)
		);

		$options = array();
		foreach ( $products as $product_id ) {
			$product = wc_get_product( $product_id );
			if ( $product ) {
				$options[ $product_id ] = $product->get_name();
			}
		}

		return $options;
	}

	/**
	 * Render widget output
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$product_id = isset( $settings['product_id'] ) ? absint( $settings['product_id'] ) : 0;

		if ( ! $product_id ) {
			echo '<p>' . esc_html__( 'Please select a product.', 'wc-variation-images-pro' ) . '</p>';
			return;
		}

		$product = wc_get_product( $product_id );
		if ( ! $product || ! $product->is_type( 'variable' ) ) {
			echo '<p>' . esc_html__( 'Invalid product.', 'wc-variation-images-pro' ) . '</p>';
			return;
		}

		// Render variation gallery
		echo '<div class="wcvip-elementor-gallery" data-product-id="' . esc_attr( $product_id ) . '">';
		echo '<p>' . esc_html__( 'Variation gallery will be displayed here.', 'wc-variation-images-pro' ) . '</p>';
		echo '</div>';
	}
}

