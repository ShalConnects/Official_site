<?php
/**
 * Page builder integration base class
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Page builders base class
 */
class WCVIP_Page_Builders {

	/**
	 * Initialize page builder integrations
	 */
	public function init() {
		// Base compatibility for all page builders
		add_filter( 'wcvip_gallery_wrapper', array( $this, 'ensure_compatibility' ), 10, 2 );
	}

	/**
	 * Ensure compatibility with page builders
	 */
	public function ensure_compatibility( $html, $product_id ) {
		// Add data attributes for page builder compatibility
		$html = str_replace( '<div class="wcvip-gallery', '<div class="wcvip-gallery" data-product-id="' . esc_attr( $product_id ) . '"', $html );
		return $html;
	}
}

