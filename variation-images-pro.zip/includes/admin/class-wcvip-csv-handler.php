<?php
/**
 * CSV import/export handler (Pro feature)
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CSV handler class
 */
class WCVIP_CSV_Handler {

	/**
	 * Export variation images to CSV
	 */
	public function export_to_csv( $product_ids = array() ) {
		$filename = 'wcvip-export-' . gmdate( 'Y-m-d-H-i-s' ) . '.csv';

		header( 'Content-Type: text/csv' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- Direct file operation required for CSV export to browser
		$output = fopen( 'php://output', 'w' );

		// Headers
		fputcsv( $output, array( 'Product ID', 'Variation ID', 'Variation SKU', 'Image IDs', 'Image URLs' ) );

		// Get products
		$args = array(
			'type'   => 'variable',
			'limit'  => -1,
			'status' => 'publish',
			'return' => 'ids',
		);

		if ( ! empty( $product_ids ) ) {
			$args['include'] = $product_ids;
		}

		$product_ids = wc_get_products( $args );

		foreach ( $product_ids as $product_id ) {
			$product = wc_get_product( $product_id );
			if ( ! $product ) {
				continue;
			}

			$variation_ids = $product->get_children();

			foreach ( $variation_ids as $variation_id ) {
				$variation = wc_get_product( $variation_id );
				if ( ! $variation ) {
					continue;
				}

				$custom_images = get_post_meta( $variation_id, '_wcvip_images', true );
				if ( ! is_array( $custom_images ) || empty( $custom_images ) ) {
					continue;
				}

				$image_ids = array();
				$image_urls = array();

				foreach ( $custom_images as $image ) {
					if ( isset( $image['id'] ) ) {
						$image_ids[] = $image['id'];
						$image_urls[] = isset( $image['url'] ) ? $image['url'] : '';
					}
				}

				fputcsv( $output, array(
					$product_id,
					$variation_id,
					$variation->get_sku(),
					implode( '|', $image_ids ),
					implode( '|', $image_urls ),
				) );
			}
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Direct file operation required for CSV export to browser
		fclose( $output );
		exit;
	}

	/**
	 * Import variation images from CSV
	 */
	public function import_from_csv( $file_path ) {
		$imported = 0;
		$errors   = array();

		if ( ! file_exists( $file_path ) ) {
			return array(
				'success' => false,
				'message' => __( 'CSV file not found.', 'wc-variation-images-pro' ),
			);
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- Direct file operation required for CSV import from uploaded file
		$handle = fopen( $file_path, 'r' );

		if ( false === $handle ) {
			return array(
				'success' => false,
				'message' => __( 'Could not open CSV file.', 'wc-variation-images-pro' ),
			);
		}

		// Skip header row
		$header = fgetcsv( $handle );

		while ( ( $data = fgetcsv( $handle ) ) !== false ) {
			if ( count( $data ) < 5 ) {
				continue;
			}

			$variation_id = absint( $data[1] );
			$image_ids    = explode( '|', $data[3] );
			$image_urls   = explode( '|', $data[4] );

			$variation = wc_get_product( $variation_id );
			if ( ! $variation ) {
				// translators: %d is the variation ID
				$errors[] = sprintf( __( 'Variation %d not found.', 'wc-variation-images-pro' ), $variation_id );
				continue;
			}

			$images = array();

			foreach ( $image_ids as $index => $image_id ) {
				$image_id = absint( $image_id );
				if ( $image_id && wp_attachment_is_image( $image_id ) ) {
					$images[] = array(
						'id'         => $image_id,
						'url'        => isset( $image_urls[ $index ] ) ? esc_url_raw( $image_urls[ $index ] ) : wp_get_attachment_image_url( $image_id, 'full' ),
						'thumbnail'  => wp_get_attachment_image_url( $image_id, 'thumbnail' ),
						'alt'        => get_post_meta( $image_id, '_wp_attachment_image_alt', true ),
						'is_primary' => 0 === $index,
					);
				}
			}

			if ( ! empty( $images ) ) {
				update_post_meta( $variation_id, '_wcvip_images', $images );
				$imported++;
			}
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Direct file operation required for CSV import
		fclose( $handle );

		return array(
			'success' => true,
			'imported' => $imported,
			'errors'   => $errors,
		);
	}
}

