<?php
/**
 * Fired during plugin deactivation
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Fired during plugin deactivation
 */
class WCVIP_Deactivator {

	/**
	 * Deactivation tasks
	 */
	public static function deactivate() {
		// Flush rewrite rules
		flush_rewrite_rules();

		// Clear any transients
		delete_transient( 'wcvip_activated' );
	}
}

