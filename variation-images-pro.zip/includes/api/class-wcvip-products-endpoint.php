<?php
/**
 * Products REST API endpoint (Pro feature)
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Products endpoint class
 */
class WCVIP_Products_Endpoint {

	/**
	 * Extend WooCommerce products endpoint
	 */
	public function __construct() {
		add_filter( 'woocommerce_rest_product_response', array( $this, 'add_variation_images_to_response' ), 10, 2 );
	}

	/**
	 * Add variation images to product response
	 */
	public function add_variation_images_to_response( $response, $product ) {
		if ( ! $product->is_type( 'variable' ) ) {
			return $response;
		}

		$variation_ids = $product->get_children();
		$variations_data = array();

		foreach ( $variation_ids as $variation_id ) {
			$custom_images = get_post_meta( $variation_id, '_wcvip_images', true );
			if ( is_array( $custom_images ) && ! empty( $custom_images ) ) {
				$variations_data[ $variation_id ] = $custom_images;
			}
		}

		if ( ! empty( $variations_data ) ) {
			$response->data['wcvip_variation_images'] = $variations_data;
		}

		return $response;
	}
}

