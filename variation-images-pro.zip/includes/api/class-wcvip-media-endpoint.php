<?php
/**
 * Media REST API endpoint (Pro feature)
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Media endpoint class
 */
class WCVIP_Media_Endpoint {

	/**
	 * Register media upload endpoint
	 */
	public function register_routes() {
		register_rest_route(
			'wcvip/v1',
			'/media/upload',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_upload' ),
				'permission_callback' => array( $this, 'check_permission' ),
			)
		);
	}

	/**
	 * Check permission
	 */
	public function check_permission( $request ) {
		return current_user_can( 'upload_files' );
	}

	/**
	 * Handle media upload
	 */
	public function handle_upload( $request ) {
		$files = $request->get_file_params();

		if ( empty( $files['file'] ) ) {
			return new WP_Error( 'no_file', __( 'No file uploaded', 'wc-variation-images-pro' ), array( 'status' => 400 ) );
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$attachment_id = media_handle_upload( 'file', 0 );

		if ( is_wp_error( $attachment_id ) ) {
			return $attachment_id;
		}

		$attachment = get_post( $attachment_id );

		return new WP_REST_Response(
			array(
				'id'        => $attachment_id,
				'url'       => wp_get_attachment_image_url( $attachment_id, 'full' ),
				'thumbnail' => wp_get_attachment_image_url( $attachment_id, 'thumbnail' ),
				'alt'       => get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ),
			),
			200
		);
	}
}

