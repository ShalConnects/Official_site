<?php
/**
 * REST API functionality (Pro feature)
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * REST API class
 */
class WCVIP_REST_API {

	/**
	 * Register REST API routes
	 */
	public function register_routes() {
		register_rest_route(
			'wcvip/v1',
			'/products',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_products' ),
				'permission_callback' => array( $this, 'check_permission' ),
			)
		);

		register_rest_route(
			'wcvip/v1',
			'/products/(?P<id>\d+)/variations',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_variations' ),
				'permission_callback' => array( $this, 'check_permission' ),
				'args'                => array(
					'id' => array(
						'validate_callback' => function( $param ) {
							return is_numeric( $param );
						},
					),
				),
			)
		);

		register_rest_route(
			'wcvip/v1',
			'/variations/(?P<id>\d+)/images',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( $this, 'get_variation_images' ),
					'permission_callback' => array( $this, 'check_permission' ),
				),
				array(
					'methods'             => 'POST',
					'callback'            => array( $this, 'save_variation_images' ),
					'permission_callback' => array( $this, 'check_permission' ),
				),
				'args' => array(
					'id' => array(
						'validate_callback' => function( $param ) {
							return is_numeric( $param );
						},
					),
				),
			)
		);
	}

	/**
	 * Check API permission with CSRF protection
	 */
	public function check_permission( $request ) {
		// Check basic capability
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			WCVIP_Security_Logger::log(
				'permission_denied',
				'User attempted REST API access without manage_woocommerce capability',
				array(
					'route' => $request->get_route(),
					'method' => $request->get_method(),
					'user_id' => get_current_user_id(),
				)
			);
			return false;
		}

		// For write operations, verify CSRF token
		$method = $request->get_method();
		if ( in_array( $method, array( 'POST', 'PUT', 'PATCH', 'DELETE' ), true ) ) {
			$csrf_token = $request->get_header( 'X-WP-Nonce' );
			
			if ( ! $csrf_token ) {
				$csrf_token = $request->get_param( '_wpnonce' );
			}
			
			if ( ! $csrf_token || ! wp_verify_nonce( $csrf_token, 'wp_rest' ) ) {
				WCVIP_Security_Logger::log(
					'csrf_failed',
					'Failed CSRF verification for REST API request',
					array(
						'method' => $method,
						'route' => $request->get_route(),
						'user_id' => get_current_user_id(),
					)
				);
				return false;
			}
		}

		return true;
	}

	/**
	 * Get products
	 */
	public function get_products( $request ) {
		$args = array(
			'type'   => 'variable',
			'limit'  => 100,
			'status' => 'publish',
			'return' => 'ids',
		);

		$product_ids = wc_get_products( $args );
		$products    = array();

		foreach ( $product_ids as $product_id ) {
			$product = wc_get_product( $product_id );
			if ( ! $product ) {
				continue;
			}

			$products[] = array(
				'id'              => $product->get_id(),
				'name'            => $product->get_name(),
				'sku'             => $product->get_sku(),
				'variation_count' => count( $product->get_children() ),
			);
		}

		$response = new WP_REST_Response( $products, 200 );
		
		// Add nonce for subsequent requests
		$response->header( 'X-WP-Nonce', wp_create_nonce( 'wp_rest' ) );
		
		return $response;
	}

	/**
	 * Get variations for a product
	 */
	public function get_variations( $request ) {
		$product_id = absint( $request->get_param( 'id' ) );
		$product    = wc_get_product( $product_id );

		if ( ! $product || ! $product->is_type( 'variable' ) ) {
			return new WP_Error( 'invalid_product', __( 'Invalid product', 'wc-variation-images-pro' ), array( 'status' => 404 ) );
		}

		$variation_ids = $product->get_children();
		$variations    = array();

		foreach ( $variation_ids as $variation_id ) {
			$variation = wc_get_product( $variation_id );
			if ( ! $variation ) {
				continue;
			}

			$custom_images = get_post_meta( $variation_id, '_wcvip_images', true );

			$variations[] = array(
				'id'            => $variation->get_id(),
				'attributes'    => $variation->get_variation_attributes(),
				'sku'           => $variation->get_sku(),
				'image_count'   => is_array( $custom_images ) ? count( $custom_images ) : 0,
			);
		}

		$response = new WP_REST_Response( $variations, 200 );
		
		// Add nonce for subsequent requests
		$response->header( 'X-WP-Nonce', wp_create_nonce( 'wp_rest' ) );
		
		return $response;
	}

	/**
	 * Get variation images
	 */
	public function get_variation_images( $request ) {
		$variation_id = absint( $request->get_param( 'id' ) );
		$custom_images = get_post_meta( $variation_id, '_wcvip_images', true );

		if ( ! is_array( $custom_images ) ) {
			$custom_images = array();
		}

		$response = new WP_REST_Response( $custom_images, 200 );
		
		// Add nonce for subsequent requests
		$response->header( 'X-WP-Nonce', wp_create_nonce( 'wp_rest' ) );
		
		return $response;
	}

	/**
	 * Save variation images
	 */
	public function save_variation_images( $request ) {
		$variation_id = absint( $request->get_param( 'id' ) );
		$images       = $request->get_json_params();

		if ( ! is_array( $images ) ) {
			return new WP_Error( 'invalid_data', __( 'Invalid image data', 'wc-variation-images-pro' ), array( 'status' => 400 ) );
		}

		// Sanitize and save
		$sanitized_images = array();
		foreach ( $images as $image ) {
			if ( isset( $image['id'] ) && is_numeric( $image['id'] ) ) {
				$sanitized_images[] = array(
					'id'         => absint( $image['id'] ),
					'url'        => isset( $image['url'] ) ? esc_url_raw( $image['url'] ) : '',
					'thumbnail'  => isset( $image['thumbnail'] ) ? esc_url_raw( $image['thumbnail'] ) : '',
					'alt'        => isset( $image['alt'] ) ? sanitize_text_field( $image['alt'] ) : '',
					'is_primary' => isset( $image['is_primary'] ) ? (bool) $image['is_primary'] : false,
				);
			}
		}

		update_post_meta( $variation_id, '_wcvip_images', $sanitized_images );

		$response = new WP_REST_Response( array( 'success' => true, 'images' => $sanitized_images ), 200 );
		
		// Add nonce for subsequent requests
		$response->header( 'X-WP-Nonce', wp_create_nonce( 'wp_rest' ) );
		
		return $response;
	}
}

