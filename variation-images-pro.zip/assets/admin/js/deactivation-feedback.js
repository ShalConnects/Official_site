/**
 * Deactivation Feedback Modal
 *
 * @package WCVIP
 */

(function($) {
	'use strict';

	var $modal = $('#wcvip-deactivation-feedback-modal');
	var $overlay = $modal.find('.wcvip-feedback-modal-overlay');
	var $form = $('#wcvip-deactivation-feedback-form');
	var $reasons = $form.find('input[name="reason"]');
	var $additional = $('#wcvip-feedback-additional');
	var $submitBtn = $('.wcvip-feedback-submit');
	var $cancelBtn = $('.wcvip-feedback-cancel');
	var $skipLink = $('.wcvip-feedback-skip');
	var pluginSlug = wcvipDeactivationFeedback.plugin;
	var deactivateLink = '';

	/**
	 * Initialize the feedback system
	 */
	function init() {
		// Find deactivate links for this plugin
		$('tr[data-plugin="' + pluginSlug + '"] .deactivate a').on('click', function(e) {
			e.preventDefault();
			deactivateLink = $(this).attr('href');
			showModal();
		});
	}

	/**
	 * Show the feedback modal
	 */
	function showModal() {
		$modal.fadeIn(200);
		$('body').addClass('wcvip-modal-open');
	}

	/**
	 * Hide the feedback modal
	 */
	function hideModal() {
		$modal.fadeOut(200);
		$('body').removeClass('wcvip-modal-open');
		// Reset form
		$form[0].reset();
		$reasons.prop('checked', false);
		$additional.hide();
		$submitBtn.prop('disabled', true);
	}

	/**
	 * Handle reason selection
	 */
	$reasons.on('change', function() {
		var reason = $(this).val();
		$submitBtn.prop('disabled', false);

		// Show additional textarea for "other" reason
		if ('other' === reason) {
			$additional.slideDown(200);
		} else {
			$additional.slideUp(200);
		}
	});

	/**
	 * Handle form submission
	 */
	$submitBtn.on('click', function(e) {
		e.preventDefault();

		if ($submitBtn.prop('disabled')) {
			return;
		}

		var reason = $reasons.filter(':checked').val();
		var additional = $additional.find('textarea').val();

		if (!reason) {
			return;
		}

		// Disable submit button
		$submitBtn.prop('disabled', true).text(wcvipDeactivationFeedback.submitting);

		// Submit feedback via AJAX
		$.ajax({
			url: wcvipDeactivationFeedback.ajaxUrl,
			type: 'POST',
			data: {
				action: 'wcvip_submit_deactivation_feedback',
				nonce: wcvipDeactivationFeedback.nonce,
				reason: reason,
				additional: additional || ''
			},
			success: function(response) {
				// Proceed with deactivation
				if (deactivateLink) {
					window.location.href = deactivateLink;
				}
			},
			error: function() {
				// Even if submission fails, proceed with deactivation
				if (deactivateLink) {
					window.location.href = deactivateLink;
				}
			}
		});
	});

	/**
	 * Handle cancel button
	 */
	$cancelBtn.on('click', function(e) {
		e.preventDefault();
		hideModal();
	});

	/**
	 * Handle skip link
	 */
	$skipLink.on('click', function(e) {
		e.preventDefault();
		hideModal();
		// Proceed with deactivation without feedback
		if (deactivateLink) {
			window.location.href = deactivateLink;
		}
	});

	/**
	 * Close modal on overlay click
	 */
	$overlay.on('click', function(e) {
		if (e.target === this) {
			hideModal();
		}
	});

	/**
	 * Close modal on ESC key
	 */
	$(document).on('keydown', function(e) {
		if (27 === e.keyCode && $modal.is(':visible')) {
			hideModal();
		}
	});

	// Initialize on document ready
	$(document).ready(init);

})(jQuery);

