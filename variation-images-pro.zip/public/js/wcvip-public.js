/**
 * Frontend public script
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        // Initialize variation image handler
        // The actual variation switching is handled by wcvip-variation-handler.js
        
        // Add branding badge if enabled (free version)
        if (wcvipFrontend && !wcvipFrontend.isPro) {
            const showBadge = true; // Get from settings
            if (showBadge) {
                // Add branding badge (optional)
            }
        }

        // Enhanced floating effect for preview banner when scrolled
        const $previewBanner = $('.wcvip-preview-banner');
        if ($previewBanner.length > 0) {
            let lastScrollTop = 0;
            $(window).on('scroll', function() {
                const scrollTop = $(this).scrollTop();
                if (scrollTop > 10) {
                    $previewBanner.addClass('is-scrolled');
                } else {
                    $previewBanner.removeClass('is-scrolled');
                }
                lastScrollTop = scrollTop;
            });
            
            // Check initial scroll position
            if ($(window).scrollTop() > 10) {
                $previewBanner.addClass('is-scrolled');
            }
        }

        // Handle save design from preview banner
        $(document).on('click', '.wcvip-save-design', function(e) {
            e.preventDefault();
            
            const $button = $(this);
            const $banner = $button.closest('.wcvip-preview-banner');
            const productId = $button.data('product-id');
            const style = $button.data('style');
            
            if (!productId || !style) {
                alert('Missing required data. Please try again.');
                return;
            }

            // Disable button and show loading state with spinner
            $button.prop('disabled', true)
                   .addClass('saving')
                   .text('Saving...');

            $.ajax({
                url: wcvipFrontend.ajaxurl,
                type: 'POST',
                data: {
                    action: 'wcvip_save_preview_design',
                    nonce: wcvipFrontend.savePreviewNonce,
                    product_id: productId,
                    style: style
                },
                success: function(response) {
                    if (response.success) {
                        // Update button to success state
                        $button.removeClass('saving')
                               .addClass('saved')
                               .text('Saved!');
                        
                        // Update banner to success state
                        $banner.addClass('saved');
                        
                        // Update note to show saved state
                        const $note = $banner.find('.wcvip-preview-banner-note');
                        $note.text('Design saved successfully');
                        
                        // Show brief success message (non-blocking)
                        const $successMsg = $('<div style="position: fixed; top: 32px; right: 20px; background: #10b981; color: white; padding: 12px 20px; border-radius: 6px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); z-index: 100000; animation: slideInRight 0.3s ease;">✓ ' + (response.data.message || 'Design saved successfully!') + '</div>');
                        $('body').append($successMsg);
                        
                        setTimeout(function() {
                            $successMsg.fadeOut(300, function() {
                                $(this).remove();
                            });
                        }, 3000);
                        
                        // Redirect after a brief delay to show success state
                        if (response.data.redirect_url) {
                            setTimeout(function() {
                            window.location.href = response.data.redirect_url;
                            }, 1500);
                        }
                    } else {
                        // Reset button on error
                        $button.removeClass('saving')
                               .prop('disabled', false)
                               .text('Save Design');
                        
                        alert('Error: ' + (response.data.message || 'Failed to save design'));
                    }
                },
                error: function() {
                    // Reset button on error
                    $button.removeClass('saving')
                           .prop('disabled', false)
                           .text('Save Design');
                    
                    alert('Error saving design. Please try again.');
                }
            });
        });

        // Handle close preview button
        $(document).on('click', '.wcvip-preview-close', function(e) {
            e.preventDefault();
            
            const $button = $(this);
            const cleanUrl = $button.data('clean-url');
            
            if (cleanUrl) {
                window.location.href = cleanUrl;
            } else {
                // Fallback: remove preview parameters from current URL
                const currentUrl = window.location.href;
                const url = new URL(currentUrl);
                url.searchParams.delete('wcvip_preview');
                url.searchParams.delete('wcvip_style');
                url.searchParams.delete('wcvip_nonce');
                window.location.href = url.toString();
            }
        });
    });

})(jQuery);

