/**
 * Add images to variation dropdown/selector
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        const $variationsForm = $('.variations_form');
        
        if ($variationsForm.length === 0) {
            return;
        }

        // Check if dropdown images are enabled
        const displayInDropdown = wcvipFrontend.displayInDropdown === 'yes';
        
        if (!displayInDropdown) {
            return;
        }

        // Wait for variation data to be loaded
        $variationsForm.on('woocommerce_variations_loaded', function() {
            addImagesToDropdown();
        });

        // Also run on page load if variations already loaded
        if ($variationsForm.data('product_variations')) {
            addImagesToDropdown();
        }

        /**
         * Add images to variation dropdown options
         */
        function addImagesToDropdown() {
            const variations = $variationsForm.data('product_variations');
            
            if (!variations || !Array.isArray(variations)) {
                return;
            }

            // Find all variation select dropdowns
            $variationsForm.find('select.variation_id, select[id^="pa_"], select[id*="attribute_"]').each(function() {
                const $select = $(this);
                
                $select.find('option').each(function() {
                    const $option = $(this);
                    const value = $option.val();
                    
                    if (!value || value === '') {
                        return;
                    }

                    // Find matching variation
                    const variation = variations.find(v => {
                        // Match by variation ID or attributes
                        if (v.variation_id && value === v.variation_id.toString()) {
                            return true;
                        }
                        
                        // Match by attribute values
                        if (v.attributes) {
                            const attrName = $select.attr('name') || $select.attr('id');
                            const attrValue = $option.text().trim();
                            
                            // Try to match attribute
                            for (let key in v.attributes) {
                                if (v.attributes[key] === attrValue || v.attributes[key] === value) {
                                    return true;
                                }
                            }
                        }
                        
                        return false;
                    });

                    if (variation && variation.wcvip_images && variation.wcvip_images.length > 0) {
                        const primaryImage = variation.wcvip_images.find(img => img.is_primary) || variation.wcvip_images[0];
                        const imageUrl = primaryImage.thumbnail || primaryImage.url || primaryImage.src;
                        
                        if (imageUrl) {
                            // Add image to option
                            $option.data('image', imageUrl);
                            
                            // For select2 dropdowns (if using)
                            if ($select.hasClass('select2-hidden-accessible')) {
                                $select.trigger('change.select2');
                            }
                        }
                    }
                });
            });

            // Enhance dropdown with images using custom rendering
            if ($.fn.select2) {
                $variationsForm.find('select.variation_id, select[id^="pa_"], select[id*="attribute_"]').each(function() {
                    if (!$(this).hasClass('wcvip-enhanced')) {
                        $(this).addClass('wcvip-enhanced');
                        
                        // Initialize or update Select2 with image support
                        if ($(this).data('select2')) {
                            // Update existing Select2
                            updateSelect2WithImages($(this));
                        } else {
                            // Initialize Select2 with image template
                            $(this).select2({
                                templateResult: formatOptionWithImage,
                                templateSelection: formatOptionWithImage
                            });
                        }
                    }
                });
            } else {
                // Fallback: Add images as CSS background or before text
                $variationsForm.find('select.variation_id, select[id^="pa_"], select[id*="attribute_"] option').each(function() {
                    const $option = $(this);
                    const imageUrl = $option.data('image');
                    
                    if (imageUrl) {
                        $option.css({
                            'background-image': 'url(' + imageUrl + ')',
                            'background-repeat': 'no-repeat',
                            'background-position': 'left center',
                            'background-size': '20px 20px',
                            'padding-left': '25px'
                        });
                    }
                });
            }
        }

        /**
         * Format option with image for Select2
         */
        function formatOptionWithImage(option) {
            if (!option.id) {
                return option.text;
            }

            const $option = $(option.element);
            const imageUrl = $option.data('image');
            
            if (imageUrl) {
                return $('<span><img src="' + imageUrl + '" style="width: 20px; height: 20px; margin-right: 8px; vertical-align: middle;">' + option.text + '</span>');
            }
            
            return option.text;
        }

        /**
         * Update Select2 with images
         */
        function updateSelect2WithImages($select) {
            // This will be called when Select2 is already initialized
            // We'll update the template functions
            const select2Data = $select.data('select2');
            if (select2Data) {
                select2Data.options.templateResult = formatOptionWithImage;
                select2Data.options.templateSelection = formatOptionWithImage;
            }
        }
    });

})(jQuery);

