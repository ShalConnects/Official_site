/**
 * Frontend variation display handler
 * Handles different display styles based on free/paid version
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        const $variationsForm = $('.variations_form');
        
        if ($variationsForm.length === 0) {
            return;
        }

        const displayStyle = wcvipFrontend.displayStyle || 'square';
        const isPro = wcvipFrontend.isPro || false;

        // Initialize based on display style
        initDisplayStyle(displayStyle);

        /**
         * Initialize display style
         */
        function initDisplayStyle(style) {
            // Check if style is Pro-only
            const proStyles = ['circular', 'rectangular', 'grid', 'strip', 'radio', 'custom', 'slider', 'carousel', 'gallery', 'hover', 'zoom'];
            
            if (!isPro && proStyles.indexOf(style) !== -1) {
                // Fallback to free style
                style = 'square';
            }

            switch(style) {
                case 'circular':
                    initCircularThumbnails();
                    break;
                case 'square':
                    initSquareThumbnails();
                    break;
                case 'rectangular':
                    initRectangularThumbnails();
                    break;
                case 'grid':
                    initGridLayout();
                    break;
                case 'dropdown':
                    // Handled by wcvip-variation-dropdown.js
                    break;
                case 'buttons':
                    initButtonStyle();
                    break;
                case 'vertical':
                    initVerticalList();
                    break;
                default:
                    initSquareThumbnails(); // Default fallback
            }
        }

        /**
         * Initialize circular thumbnails (Pro feature)
         */
        function initCircularThumbnails() {
            if (!isPro) {
                return;
            }

            $variationsForm.on('found_variation', function(event, variation) {
                if (variation.wcvip_images && variation.wcvip_images.length > 0) {
                    renderCircularThumbnails(variation.wcvip_images);
                }
            });
        }

        /**
         * Render circular thumbnails
         */
        function renderCircularThumbnails(images) {
            // Remove existing variation display
            $('.wcvip-variation-display').remove();

            const $container = $('<div class="wcvip-variation-display wcvip-circular-thumbnails"></div>');
            
            images.forEach(function(image, index) {
                const $thumb = $(
                    '<div class="wcvip-circular-thumb" data-image-index="' + index + '">' +
                    '<img src="' + (image.thumbnail || image.url) + '" alt="' + (image.alt || '') + '">' +
                    '</div>'
                );

                if (index === 0 || image.is_primary) {
                    $thumb.addClass('active');
                }

                $container.append($thumb);
            });

            // Insert before variation form or after product gallery
            $variationsForm.before($container);

            // Handle thumbnail clicks
            $container.find('.wcvip-circular-thumb').on('click', function() {
                const index = $(this).data('image-index');
                const image = images[index];
                
                // Update main product image
                updateMainImage(image);
                
                // Update active state
                $container.find('.wcvip-circular-thumb').removeClass('active');
                $(this).addClass('active');
            });
        }

        /**
         * Initialize square thumbnails (Free)
         */
        function initSquareThumbnails() {
            // This is the default behavior - already handled by wcvip-variation-handler.js
        }

        /**
         * Initialize rectangular thumbnails (Pro)
         */
        function initRectangularThumbnails() {
            if (!isPro) {
                return;
            }
            // Similar to circular but with rectangular shape
        }

        /**
         * Initialize grid layout (Pro)
         */
        function initGridLayout() {
            if (!isPro) {
                return;
            }
            // Grid layout implementation
        }

        /**
         * Initialize button style
         */
        function initButtonStyle() {
            // Button style implementation
        }

        /**
         * Initialize vertical list
         */
        function initVerticalList() {
            // Vertical list implementation
        }

        /**
         * Update main product image
         */
        function updateMainImage(image) {
            const $mainImage = $('.woocommerce-product-gallery__image:first img');
            if ($mainImage.length > 0) {
                $mainImage.addClass('wcvip-fade');
                $mainImage.attr('src', image.src || image.url);
                if (image.srcset) {
                    $mainImage.attr('srcset', image.srcset);
                }
                setTimeout(function() {
                    $mainImage.removeClass('wcvip-fade');
                }, 300);
            }
        }
    });

})(jQuery);

