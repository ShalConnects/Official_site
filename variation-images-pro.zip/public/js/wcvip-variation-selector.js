/**
 * Variation Selector Handler
 * Handles custom variation selector clicks and syncs with WooCommerce
 * Works with any theme/builder using flexible selectors
 */

(function($) {
    'use strict';

    // Script loaded - only log in debug mode
    if (typeof wcvipDebug !== 'undefined' && wcvipDebug === true) {
        // Debug logging removed
    }

    // Initialize when DOM is ready
    function initWCVIPVariationSelector() {
        const $allSelectors = $('.wcvip-variation-selector');
        
        if ($allSelectors.length === 0) {
            return; // No custom selector found
        }
        
        // Initialize each selector separately
        $allSelectors.each(function() {
            const $selector = $(this);
            
            // Prevent double initialization
            if ($selector.data('wcvip-initialized')) {
                return;
            }
            $selector.data('wcvip-initialized', true);

        const displayStyle = $selector.data('style') || 'square';
        const productId = $selector.data('product-id');

        // Hide default WooCommerce variations table when custom selector is present
        // This ensures compatibility with all browsers and handles edge cases
        const $form = $selector.closest('form.variations_form');
        if ($form.length > 0) {
            $form.find('table.variations').hide();
        } else {
            // Fallback: hide variations table that comes after custom selector
            $selector.siblings('.variations').hide();
            $selector.next('.variations').hide();
        }

        // Initialize selector
        initVariationSelector();
        
        // Mark default variation as active for square thumbnails
        initSquareThumbnailsDefault();
        
        // Initialize enhanced features for horizontal text boxes
        if (displayStyle === 'horizontal_text') {
            initHorizontalTextBoxesEnhancements();
        }
        
        // Initialize enhanced features for vertical text list
        if (displayStyle === 'vertical_text') {
            initVerticalTextListEnhancements();
        }
        
        // Initialize enhanced features for color swatches
        if (displayStyle === 'color_swatches') {
            initColorSwatchesEnhancements();
            initColorSwatchesDefault();
        }
        
        // Initialize enhanced features for button style (all button variants)
        const buttonStyles = ['buttons', 'buttons_vertical', 'buttons_horizontal', 'buttons_text_first', 'buttons_text_first_vertical', 'buttons_text_first_horizontal'];
        if (buttonStyles.indexOf(displayStyle) !== -1) {
            initButtonStyleEnhancements();
        }
        
        // Initialize enhanced features for square thumbnails
        if (displayStyle === 'square') {
            initSquareThumbnailsEnhancements();
            initImageLoadingOptimization();
        }
        
        // Initialize enhanced features for circular thumbnails
        if (displayStyle === 'circular') {
            initCircularThumbnailsEnhancements();
            initImageLoadingOptimization();
        }

        // Initialize attribute sections format if enabled
        if ($selector.hasClass('wcvip-attribute-sections')) {
            initAttributeSections();
        }

        /**
         * Initialize variation selector
         */
        function initVariationSelector() {
            // Handle clicks on variation thumbnails
            // Note: Horizontal text boxes have their own enhanced handler, so we skip them here
            $selector.on('click', '.wcvip-circular-thumb, .wcvip-square-thumb, .wcvip-rectangular-item, .wcvip-button-thumb, .wcvip-vertical-item, .wcvip-grid-thumb, .wcvip-strip-item, .wcvip-radio-item, .wcvip-text-box', function(e) {
                e.preventDefault();
                
                const $item = $(this);
                
                // Skip if within attribute sections - they have their own handler
                if ($item.closest('.wcvip-attribute-sections-container').length > 0) {
                    return;
                }
                
                // Skip horizontal text boxes - they have enhanced handler
                if ($item.closest('.wcvip-horizontal-text-boxes').length > 0 && displayStyle === 'horizontal_text') {
                    return;
                }
                
                // Skip vertical text list - they have enhanced handler
                if ($item.closest('.wcvip-vertical-text-list').length > 0 && displayStyle === 'vertical_text') {
                    return;
                }
                
                // Skip color swatches - they have enhanced handler
                if ($item.hasClass('wcvip-color-swatch') && displayStyle === 'color_swatches') {
                    return;
                }
                
                // Skip button style - they have enhanced handler
                const buttonStyles = ['buttons', 'buttons_vertical', 'buttons_horizontal', 'buttons_text_first', 'buttons_text_first_vertical', 'buttons_text_first_horizontal'];
                if ($item.hasClass('wcvip-button-thumb') && buttonStyles.indexOf(displayStyle) !== -1) {
                    return;
                }
                
                // Skip square thumbnails - they have enhanced handler
                if ($item.hasClass('wcvip-square-thumb') && displayStyle === 'square') {
                    return;
                }
                
                // Skip circular thumbnails - they have enhanced handler
                if ($item.hasClass('wcvip-circular-thumb') && displayStyle === 'circular') {
                    return;
                }
                
                // Prevent clicking on unavailable items
                if ($item.data('unavailable') === true || $item.attr('data-unavailable') === 'true') {
                    return;
                }
                
                const variationId = $item.data('variation-id');
                let attributes = $item.data('attributes');
                
                // If attributes is a string (JSON), parse it
                if (typeof attributes === 'string') {
                    try {
                        attributes = JSON.parse(attributes);
                    } catch (e) {
                        console.error('WCVIP: Failed to parse attributes JSON', e);
                        return;
                    }
                }

                if (!variationId || !attributes) {
                    console.warn('WCVIP: Missing variation data', { variationId, attributes });
                    return;
                }

                // Set WooCommerce variation
                setWooCommerceVariation(attributes);

                // Update active state
                updateActiveState($item);

                // Update label for square thumbnails
                updateSquareThumbnailsLabel($item);

                // Trigger variation change (for WooCommerce to update price, etc.)
                triggerVariationChange(variationId);
            });

            // Handle radio button changes
            $selector.on('change', 'input[type="radio"][name="wcvip_variation"]', function() {
                const $radio = $(this);
                const variationId = $radio.val();
                const $item = $radio.closest('.wcvip-radio-item');
                const attributes = $item.data('attributes');

                if (attributes) {
                    setWooCommerceVariation(attributes);
                    updateActiveState($item);
                    triggerVariationChange(variationId);
                }
            });

            // Sync with WooCommerce variation changes (if user uses dropdown)
            syncWithWooCommerceVariation();
        }

        /**
         * Set WooCommerce variation using attributes
         * Enhanced to handle multiple attributes correctly
         */
        function setWooCommerceVariation(attributes) {
            // Find variation form using multiple selectors (for compatibility)
            const $form = findVariationForm();
            
            if ($form.length === 0) {
                console.warn('WCVIP: Variation form not found');
                return;
            }

            // Set each attribute (handles multiple attributes correctly)
            $.each(attributes, function(attribute, value) {
                // Try multiple selectors for attribute inputs
                const selectors = [
                    'select[name="' + attribute + '"]',
                    'input[name="' + attribute + '"]',
                    'select[data-attribute_name="' + attribute + '"]',
                    'input[data-attribute_name="' + attribute + '"]',
                ];

                let $input = null;
                for (let i = 0; i < selectors.length; i++) {
                    $input = $form.find(selectors[i]);
                    if ($input.length > 0) {
                        break;
                    }
                }

                if ($input.length > 0) {
                    if ($input.is('select')) {
                        $input.val(value).trigger('change');
                    } else if ($input.is('input[type="radio"]')) {
                        $input.filter('[value="' + value + '"]').prop('checked', true).trigger('change');
                    } else if ($input.is('input')) {
                        $input.val(value).trigger('change');
                    }
                }
            });
            
            // Update active states in grouped displays (for multi-attribute products)
            updateActiveStatesInGroups(attributes);
        }
        
        /**
         * Update active states in attribute groups for multi-attribute products
         */
        function updateActiveStatesInGroups(attributes) {
            // Find all items with matching attributes and update their active states
            const $allItems = $selector.find('[data-attributes]');
            
            $allItems.each(function() {
                const $item = $(this);
                const itemAttributes = $item.data('attributes');
                
                if (!itemAttributes || typeof itemAttributes !== 'object') {
                    return;
                }
                
                // Check if all attributes match
                let allMatch = true;
                $.each(attributes, function(attr, value) {
                    if (itemAttributes[attr] !== value) {
                        allMatch = false;
                        return false; // break loop
                    }
                });
                
                // If attributes match, mark as active within its group
                if (allMatch) {
                    // Remove active from siblings in the same group
                    const $group = $item.closest('.wcvip-attribute-group, .wcvip-circular-thumbnails, .wcvip-square-thumbnails, .wcvip-rectangular-thumbnails');
                    if ($group.length > 0) {
                        $group.find('.active').removeClass('active');
                    }
                    $item.addClass('active');
                }
            });
        }

        /**
         * Find variation form using flexible selectors
         */
        function findVariationForm() {
            const selectors = [
                '.variations_form',
                'form.variations_form',
                '[data-product_id="' + productId + '"]',
                '.woocommerce-variations',
                '.product form',
                'form[data-product_id]',
            ];

            for (let i = 0; i < selectors.length; i++) {
                const $form = $(selectors[i]).first();
                if ($form.length > 0) {
                    return $form;
                }
            }

            // Fallback: find form containing variation selector
            return $selector.closest('form');
        }

        /**
         * Update active state of thumbnails
         */
        function updateActiveState($activeItem) {
            // Remove active class from all items
            $selector.find('.wcvip-circular-thumb, .wcvip-square-thumb, .wcvip-rectangular-item, .wcvip-button-thumb, .wcvip-vertical-item, .wcvip-grid-thumb, .wcvip-strip-item, .wcvip-radio-item, .wcvip-text-box').removeClass('active');
            
            // Add active class to clicked item
            $activeItem.addClass('active');
            
            // Update ARIA attributes for horizontal text boxes
            if ($activeItem.hasClass('wcvip-text-box') && $activeItem.closest('.wcvip-horizontal-text-boxes').length > 0) {
                $selector.find('.wcvip-horizontal-text-boxes .wcvip-text-box').attr('aria-pressed', 'false').attr('aria-checked', 'false');
                $activeItem.attr('aria-pressed', 'true').attr('aria-checked', 'true');
            }
            
            // Update ARIA attributes for vertical text list
            if ($activeItem.hasClass('wcvip-text-box') && $activeItem.closest('.wcvip-vertical-text-list').length > 0) {
                $selector.find('.wcvip-vertical-text-list .wcvip-text-box').attr('aria-pressed', 'false').attr('aria-checked', 'false');
                $activeItem.attr('aria-pressed', 'true').attr('aria-checked', 'true');
            }
            
            // Update ARIA attributes for square thumbnails
            if ($activeItem.hasClass('wcvip-square-thumb')) {
                $selector.find('.wcvip-square-thumbnails .wcvip-square-thumb').attr('aria-pressed', 'false').attr('aria-checked', 'false');
                $activeItem.attr('aria-pressed', 'true').attr('aria-checked', 'true');
            }
            
            // Update ARIA attributes for circular thumbnails
            if ($activeItem.hasClass('wcvip-circular-thumb')) {
                $selector.find('.wcvip-circular-thumbnails .wcvip-circular-thumb').attr('aria-pressed', 'false').attr('aria-checked', 'false');
                $activeItem.attr('aria-pressed', 'true').attr('aria-checked', 'true');
            }
        }

        /**
         * Initialize square/circular thumbnails with default variation active
         */
        function initSquareThumbnailsDefault() {
            // Check for square thumbnails
            const $squareLabel = $selector.find('.wcvip-square-thumbnails-label');
            if ($squareLabel.length > 0) {
                const defaultVariationId = $squareLabel.data('default-variation-id');
                if (defaultVariationId) {
                    const $defaultThumb = $selector.find('[data-variation-id="' + defaultVariationId + '"]');
                    if ($defaultThumb.length > 0) {
                        $defaultThumb.addClass('active');
                    }
                }
            }
            
            // Check for circular thumbnails
            const $circularLabel = $selector.find('.wcvip-circular-thumbnails-label');
            if ($circularLabel.length > 0) {
                const defaultVariationId = $circularLabel.data('default-variation-id');
                if (defaultVariationId) {
                    const $defaultThumb = $selector.find('[data-variation-id="' + defaultVariationId + '"]');
                    if ($defaultThumb.length > 0) {
                        $defaultThumb.addClass('active');
                    }
                }
            }
        }

        /**
         * Update square/circular thumbnails label when variation is selected
         */
        function updateSquareThumbnailsLabel($selectedThumb) {
            const variationValue = $selectedThumb.data('variation-value');
            if (!variationValue) {
                return;
            }
            
            // Update square thumbnails label
            const $squareLabel = $selector.find('.wcvip-square-thumbnails-label');
            if ($squareLabel.length > 0) {
                $squareLabel.find('.wcvip-label-value').text(variationValue);
            }
            
            // Update circular thumbnails label
            const $circularLabel = $selector.find('.wcvip-circular-thumbnails-label');
            if ($circularLabel.length > 0) {
                $circularLabel.find('.wcvip-label-value').text(variationValue);
            }
            
            // Update color swatches label
            const $colorSwatchesLabel = $selector.find('.wcvip-color-swatches-label');
            if ($colorSwatchesLabel.length > 0) {
                $colorSwatchesLabel.find('.wcvip-label-value').text(variationValue);
            }
        }

        /**
         * Trigger WooCommerce variation change
         */
        function triggerVariationChange(variationId) {
            const $form = findVariationForm();
            
            if ($form.length === 0) {
                return;
            }

            // Trigger WooCommerce variation change event
            $form.trigger('check_variations');
            $form.trigger('found_variation', [variationId]);
            
            // Also try to find and trigger variation_id change
            const $variationInput = $form.find('input[name="variation_id"]');
            if ($variationInput.length > 0) {
                $variationInput.val(variationId).trigger('change');
            }
        }

        /**
         * Sync with WooCommerce variation changes (if user uses dropdown)
         */
        function syncWithWooCommerceVariation() {
            const $form = findVariationForm();
            
            if ($form.length === 0) {
                return;
            }

            // Listen for WooCommerce variation found event
            $form.on('found_variation', function(event, variation) {
                if (!variation || !variation.variation_id) {
                    return;
                }

                // Find and highlight matching thumbnail
                const variationId = variation.variation_id;
                const $matchingItem = $selector.find('[data-variation-id="' + variationId + '"]');
                
                if ($matchingItem.length > 0) {
                    // Check if it's square or circular thumbnails (both grouped and single attribute format)
                    const variationName = $matchingItem.data('variation-name');
                    if (variationName) {
                        if ($matchingItem.hasClass('wcvip-square-thumb')) {
                            const $globalLabel = $selector.find('.wcvip-square-thumbnails-wrapper .wcvip-selected-variation-global');
                            if ($globalLabel.length > 0) {
                                $globalLabel.find('.wcvip-selected-value').text(variationName);
                                $globalLabel.show();
                            }
                        } else if ($matchingItem.hasClass('wcvip-circular-thumb')) {
                            const $globalLabel = $selector.find('.wcvip-circular-thumbnails-wrapper .wcvip-selected-variation-global');
                            if ($globalLabel.length > 0) {
                                $globalLabel.find('.wcvip-selected-value').text(variationName);
                                $globalLabel.show();
                            }
                        }
                    }
                    
                    // Check if it's in grouped format for auto-expand
                    const $group = $matchingItem.closest('.wcvip-attribute-group');
                    if ($group.length > 0) {
                        // Grouped format - auto-expand group
                        $group.removeClass('wcvip-group-collapsed').addClass('wcvip-group-active');
                        const $content = $group.find('.wcvip-group-content');
                        $content.slideDown(200);
                    }
                    
                    if ($matchingItem.hasClass('wcvip-button-thumb')) {
                        // Button Style - update global selected variation label
                        const variationName = $matchingItem.data('variation-name');
                        if (variationName) {
                            const $globalLabel = $selector.find('.wcvip-button-style .wcvip-selected-variation-global');
                            if ($globalLabel.length > 0) {
                                $globalLabel.find('.wcvip-selected-value').text(variationName);
                                $globalLabel.show();
                            }
                        }
                    } else if ($matchingItem.hasClass('wcvip-text-box') && $matchingItem.closest('.wcvip-horizontal-text-boxes').length > 0) {
                        // Horizontal Text Boxes - update global selected variation label
                        const variationName = $matchingItem.data('variation-name');
                        if (variationName) {
                            const $wrapper = $selector.find('.wcvip-horizontal-text-boxes-wrapper, .wcvip-horizontal-text-boxes').parent();
                            let $globalLabel = $wrapper.find('.wcvip-selected-variation-global');
                            if ($globalLabel.length === 0) {
                                // If no wrapper, check the selector itself
                                $globalLabel = $selector.find('.wcvip-selected-variation-global');
                            }
                            if ($globalLabel.length > 0) {
                                $globalLabel.find('.wcvip-selected-value').text(variationName);
                                $globalLabel.show();
                            }
                        }
                    } else if ($matchingItem.hasClass('wcvip-text-box') && $matchingItem.closest('.wcvip-vertical-text-list').length > 0) {
                        // Vertical Text List - update global selected variation label
                        const variationName = $matchingItem.data('variation-name');
                        if (variationName) {
                            const $wrapper = $selector.find('.wcvip-vertical-text-list-wrapper, .wcvip-vertical-text-list').parent();
                            let $globalLabel = $wrapper.find('.wcvip-selected-variation-global');
                            if ($globalLabel.length === 0) {
                                // If no wrapper, check the selector itself
                                $globalLabel = $selector.find('.wcvip-selected-variation-global');
                            }
                            if ($globalLabel.length > 0) {
                                $globalLabel.find('.wcvip-selected-value').text(variationName);
                                $globalLabel.show();
                            }
                        }
                    } else if ($matchingItem.hasClass('wcvip-color-swatch')) {
                        // Color Swatches - update global selected variation label
                        const variationName = $matchingItem.data('variation-name');
                        if (variationName) {
                            // Find the label directly - it's a sibling or in a parent container
                            const $closestContainer = $matchingItem.closest('.wcvip-color-swatches');
                            let $globalLabel = $closestContainer.siblings('.wcvip-selected-variation-global');
                            if ($globalLabel.length === 0) {
                                // Try finding in parent container
                                $globalLabel = $closestContainer.parent().find('.wcvip-selected-variation-global');
                            }
                            if ($globalLabel.length === 0) {
                                // Fallback: search within entire selector
                                $globalLabel = $selector.find('.wcvip-selected-variation-global');
                            }
                            if ($globalLabel.length > 0) {
                                const $valueSpan = $globalLabel.find('.wcvip-selected-value');
                                $valueSpan.text(variationName);
                                // Ensure value span is visible
                                if ($valueSpan.length > 0) {
                                    $valueSpan[0].style.setProperty('display', 'inline', 'important');
                                    $valueSpan[0].style.setProperty('visibility', 'visible', 'important');
                                    $valueSpan[0].style.setProperty('opacity', '1', 'important');
                                }
                                // Use !important via direct style attribute to override everything
                                $globalLabel[0].style.setProperty('display', 'block', 'important');
                                // Set up MutationObserver to catch if something tries to hide it
                                if (!$globalLabel.data('wcvip-observer-setup')) {
                                    const observer = new MutationObserver(function(mutations) {
                                        mutations.forEach(function(mutation) {
                                            if (mutation.type === 'attributes' && mutation.attributeName === 'style') {
                                                const display = window.getComputedStyle($globalLabel[0]).display;
                                                if (display === 'none') {
                                                    $globalLabel[0].style.setProperty('display', 'block', 'important');
                                                }
                                            }
                                        });
                                    });
                                    observer.observe($globalLabel[0], {
                                        attributes: true,
                                        attributeFilter: ['style']
                                    });
                                    $globalLabel.data('wcvip-observer-setup', true);
                                }
                                // Store variation name for restoration
                                $globalLabel.data('wcvip-variation-name', variationName);
                                // Check after a short delay if something is hiding it or clearing the value
                                setTimeout(function() {
                                    if ($globalLabel.css('display') === 'none') {
                                        $globalLabel[0].style.setProperty('display', 'block', 'important');
                                    }
                                    // Check if value was cleared
                                    const $valueSpan = $globalLabel.find('.wcvip-selected-value');
                                    if ($valueSpan.length > 0 && !$valueSpan.text().trim()) {
                                        const storedName = $globalLabel.data('wcvip-variation-name') || variationName;
                                        $valueSpan.text(storedName);
                                        $valueSpan[0].style.setProperty('display', 'inline', 'important');
                                        $valueSpan[0].style.setProperty('visibility', 'visible', 'important');
                                        $valueSpan[0].style.setProperty('opacity', '1', 'important');
                                    }
                                }, 100);
                            }
                        }
                    }
                    
                    // Update active state (generic function handles all styles)
                    updateActiveState($matchingItem);
                    
                    // Update label for square thumbnails (single attribute)
                    updateSquareThumbnailsLabel($matchingItem);
                }
            });

            // Listen for variation reset
            $form.on('reset_data', function() {
                $selector.find('.wcvip-circular-thumb, .wcvip-square-thumb, .wcvip-rectangular-item, .wcvip-button-thumb, .wcvip-vertical-item, .wcvip-grid-thumb, .wcvip-strip-item, .wcvip-radio-item, .wcvip-text-box, .wcvip-color-swatch').removeClass('active');
                
                // Reset label to default value for square thumbnails (single attribute)
                const $squareLabel = $selector.find('.wcvip-square-thumbnails-label');
                if ($squareLabel.length > 0) {
                    const defaultValue = $squareLabel.data('default-value');
                    if (defaultValue) {
                        $squareLabel.find('.wcvip-label-value').text(defaultValue);
                    }
                }
                
                // Reset global selected variation label for square thumbnails (grouped format)
                const $squareGlobalLabel = $selector.find('.wcvip-square-thumbnails-wrapper .wcvip-selected-variation-global');
                if ($squareGlobalLabel.length > 0) {
                    $squareGlobalLabel.hide();
                    $squareGlobalLabel.find('.wcvip-selected-value').text('');
                }
                
                // Reset label to default value for circular thumbnails (single attribute)
                const $circularLabel = $selector.find('.wcvip-circular-thumbnails-label');
                if ($circularLabel.length > 0) {
                    const defaultValue = $circularLabel.data('default-value');
                    if (defaultValue) {
                        $circularLabel.find('.wcvip-label-value').text(defaultValue);
                    }
                }
                
                // Reset global selected variation label for circular thumbnails (grouped format)
                const $circularGlobalLabel = $selector.find('.wcvip-circular-thumbnails-wrapper .wcvip-selected-variation-global');
                if ($circularGlobalLabel.length > 0) {
                    $circularGlobalLabel.hide();
                    $circularGlobalLabel.find('.wcvip-selected-value').text('');
                }
                
                // Reset global selected variation label for button style
                const $buttonGlobalLabel = $selector.find('.wcvip-button-style .wcvip-selected-variation-global');
                if ($buttonGlobalLabel.length > 0) {
                    $buttonGlobalLabel.hide();
                    $buttonGlobalLabel.find('.wcvip-selected-value').text('');
                }
                
                // Reset global selected variation label for horizontal text boxes
                const $horizontalTextGlobalLabel = $selector.find('.wcvip-horizontal-text-boxes-wrapper .wcvip-selected-variation-global, .wcvip-horizontal-text-boxes').parent().find('.wcvip-selected-variation-global');
                if ($horizontalTextGlobalLabel.length > 0) {
                    $horizontalTextGlobalLabel.hide();
                    $horizontalTextGlobalLabel.find('.wcvip-selected-value').text('');
                }
                
                // Reset global selected variation label for vertical text list
                const $verticalTextGlobalLabel = $selector.find('.wcvip-vertical-text-list-wrapper .wcvip-selected-variation-global, .wcvip-vertical-text-list').parent().find('.wcvip-selected-variation-global');
                if ($verticalTextGlobalLabel.length > 0) {
                    $verticalTextGlobalLabel.hide();
                    $verticalTextGlobalLabel.find('.wcvip-selected-value').text('');
                }
                
                // Reset global selected variation label for color swatches
                let $colorSwatchesGlobalLabel = $selector.find('.wcvip-selected-variation-global');
                if ($colorSwatchesGlobalLabel.length > 0) {
                    $colorSwatchesGlobalLabel.hide();
                    $colorSwatchesGlobalLabel.find('.wcvip-selected-value').text('');
                }
                
                // Reset label to default value for color swatches
                const $colorSwatchesLabel = $selector.find('.wcvip-color-swatches-label');
                if ($colorSwatchesLabel.length > 0) {
                    const defaultValue = $colorSwatchesLabel.data('default-value');
                    if (defaultValue) {
                        $colorSwatchesLabel.find('.wcvip-label-value').text(defaultValue);
                    }
                }
            });
        }

        /**
         * Initialize enhanced features for Horizontal Text Boxes
         * Includes: keyboard navigation, loading states, tooltips, error handling
         */
        function initHorizontalTextBoxesEnhancements() {
            const $horizontalBoxes = $selector.find('.wcvip-horizontal-text-boxes');
            
            if ($horizontalBoxes.length === 0) {
                return;
            }

            const $textBoxes = $horizontalBoxes.find('.wcvip-text-box');
            
            if ($textBoxes.length === 0) {
                return;
            }

            // Cache jQuery selectors for performance
            const $form = findVariationForm();
            
            /**
             * Enhanced click handler
             */
            $textBoxes.on('click', function(e) {
                e.preventDefault();
                
                const $item = $(this);
                
                // Prevent clicking on unavailable items
                if ($item.data('unavailable') === true || $item.attr('data-unavailable') === 'true') {
                    return;
                }
                
                const variationId = $item.data('variation-id');
                const attributes = $item.data('attributes');

                if (!variationId || !attributes) {
                    console.warn('WCVIP: Missing variation data', { variationId, attributes });
                    return;
                }
                
                try {
                    // Set WooCommerce variation
                    setWooCommerceVariation(attributes);

                    // Update active state with animation
                    updateActiveStateWithAnimation($item);

                    // Trigger variation change
                    triggerVariationChange(variationId);
                    
                    // Update ARIA attributes
                    updateAriaAttributes($item);
                    
                } catch (error) {
                    console.error('WCVIP: Error selecting variation', error);
                }
            });

            /**
             * Keyboard Navigation
             */
            $textBoxes.on('keydown', function(e) {
                const $current = $(this);
                const $allBoxes = $horizontalBoxes.find('.wcvip-text-box:not([data-unavailable="true"])');
                const currentIndex = $allBoxes.index($current);
                let $next = null;

                // Arrow Right or Down: Move to next
                if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
                    e.preventDefault();
                    $next = currentIndex < $allBoxes.length - 1 ? $allBoxes.eq(currentIndex + 1) : $allBoxes.first();
                }
                // Arrow Left or Up: Move to previous
                else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
                    e.preventDefault();
                    $next = currentIndex > 0 ? $allBoxes.eq(currentIndex - 1) : $allBoxes.last();
                }
                // Home: Move to first
                else if (e.key === 'Home') {
                    e.preventDefault();
                    $next = $allBoxes.first();
                }
                // End: Move to last
                else if (e.key === 'End') {
                    e.preventDefault();
                    $next = $allBoxes.last();
                }
                // Enter or Space: Select current
                else if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    $current.trigger('click');
                    return;
                }
                // Escape: Blur
                else if (e.key === 'Escape') {
                    e.preventDefault();
                    $current.blur();
                    return;
                }

                // Move focus to next item
                if ($next && $next.length > 0) {
                    $current.attr('tabindex', '-1');
                    $next.attr('tabindex', '0').focus();
                    
                    // Scroll into view if needed (for horizontal scroll)
                    scrollIntoViewIfNeeded($next);
                }
            });


            /**
             * Lazy loading for dynamically added images (if any)
             */
            if ('IntersectionObserver' in window) {
                const imageObserver = new IntersectionObserver(function(entries) {
                    entries.forEach(function(entry) {
                        if (entry.isIntersecting) {
                            const $img = $(entry.target);
                            if ($img.data('src')) {
                                $img.attr('src', $img.data('src')).removeAttr('data-src');
                                imageObserver.unobserve(entry.target);
                            }
                        }
                    });
                }, {
                    rootMargin: '50px'
                });

                // Observe any images that might be added later
                $horizontalBoxes.find('img[data-src]').each(function() {
                    imageObserver.observe(this);
                });
            }

            /**
             * Update active state
             */
            function updateActiveStateWithAnimation($activeItem) {
                // Remove active from all
                $textBoxes.removeClass('active');
                
                // Add active class
                $activeItem.addClass('active');
                
                // Update global selected variation label
                const variationName = $activeItem.data('variation-name');
                if (variationName) {
                    const $wrapper = $selector.find('.wcvip-horizontal-text-boxes-wrapper, .wcvip-horizontal-text-boxes').parent();
                    let $globalLabel = $wrapper.find('.wcvip-selected-variation-global');
                    if ($globalLabel.length === 0) {
                        // If no wrapper, check the selector itself
                        $globalLabel = $selector.find('.wcvip-selected-variation-global');
                    }
                    if ($globalLabel.length > 0) {
                        $globalLabel.find('.wcvip-selected-value').text(variationName);
                        $globalLabel.show();
                    }
                }
            }

            /**
             * Update ARIA attributes
             */
            function updateAriaAttributes($activeItem) {
                $textBoxes.attr({
                    'aria-pressed': 'false',
                    'aria-checked': 'false'
                });
                
                $activeItem.attr({
                    'aria-pressed': 'true',
                    'aria-checked': 'true'
                });
            }

            /**
             * Scroll item into view if needed (for horizontal scroll)
             */
            function scrollIntoViewIfNeeded($item) {
                const container = $horizontalBoxes[0];
                const item = $item[0];
                
                if (!container || !item) {
                    return;
                }

                const containerRect = container.getBoundingClientRect();
                const itemRect = item.getBoundingClientRect();

                // Check if item is outside viewport
                if (itemRect.left < containerRect.left) {
                    // Scroll left
                    item.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'start' });
                } else if (itemRect.right > containerRect.right) {
                    // Scroll right
                    item.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'end' });
                }
            }

            // Initialize ARIA attributes on page load
            const $activeBox = $horizontalBoxes.find('.wcvip-text-box.active');
            if ($activeBox.length > 0) {
                updateAriaAttributes($activeBox);
            }
        }

        /**
         * Initialize enhanced features for Vertical Text List
         * Includes: keyboard navigation, error handling
         */
        function initVerticalTextListEnhancements() {
            const $verticalList = $selector.find('.wcvip-vertical-text-list');
            
            if ($verticalList.length === 0) {
                return;
            }

            const $textBoxes = $verticalList.find('.wcvip-text-box');
            
            if ($textBoxes.length === 0) {
                return;
            }

            // Cache jQuery selectors for performance
            const $form = findVariationForm();
            
            /**
             * Enhanced click handler
             */
            $textBoxes.on('click', function(e) {
                e.preventDefault();
                
                const $item = $(this);
                
                // Prevent clicking on unavailable items
                if ($item.data('unavailable') === true || $item.attr('data-unavailable') === 'true') {
                    return;
                }
                
                const variationId = $item.data('variation-id');
                const attributes = $item.data('attributes');

                if (!variationId || !attributes) {
                    console.warn('WCVIP: Missing variation data', { variationId, attributes });
                    return;
                }
                
                try {
                    // Set WooCommerce variation
                    setWooCommerceVariation(attributes);

                    // Update active state
                    updateActiveStateForVertical($item);

                    // Trigger variation change
                    triggerVariationChange(variationId);
                    
                    // Update ARIA attributes
                    updateAriaAttributesForVertical($item);
                    
                } catch (error) {
                    console.error('WCVIP: Error selecting variation', error);
                }
            });

            /**
             * Keyboard Navigation
             */
            $textBoxes.on('keydown', function(e) {
                const $current = $(this);
                const $allBoxes = $verticalList.find('.wcvip-text-box:not([data-unavailable="true"])');
                const currentIndex = $allBoxes.index($current);
                let $next = null;

                // Arrow Down: Move to next
                if (e.key === 'ArrowDown') {
                    e.preventDefault();
                    $next = currentIndex < $allBoxes.length - 1 ? $allBoxes.eq(currentIndex + 1) : $allBoxes.first();
                }
                // Arrow Up: Move to previous
                else if (e.key === 'ArrowUp') {
                    e.preventDefault();
                    $next = currentIndex > 0 ? $allBoxes.eq(currentIndex - 1) : $allBoxes.last();
                }
                // Home: Move to first
                else if (e.key === 'Home') {
                    e.preventDefault();
                    $next = $allBoxes.first();
                }
                // End: Move to last
                else if (e.key === 'End') {
                    e.preventDefault();
                    $next = $allBoxes.last();
                }
                // Enter or Space: Select current
                else if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    $current.trigger('click');
                    return;
                }
                // Escape: Blur
                else if (e.key === 'Escape') {
                    e.preventDefault();
                    $current.blur();
                    return;
                }

                // Move focus to next item
                if ($next && $next.length > 0) {
                    $current.attr('tabindex', '-1');
                    $next.attr('tabindex', '0').focus();
                    
                    // Scroll into view if needed
                    $next[0].scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                }
            });

            /**
             * Update active state
             */
            function updateActiveStateForVertical($activeItem) {
                // Remove active from all
                $textBoxes.removeClass('active');
                
                // Add active class
                $activeItem.addClass('active');
                
                // Update global selected variation label
                const variationName = $activeItem.data('variation-name');
                if (variationName) {
                    const $wrapper = $selector.find('.wcvip-vertical-text-list-wrapper, .wcvip-vertical-text-list').parent();
                    let $globalLabel = $wrapper.find('.wcvip-selected-variation-global');
                    if ($globalLabel.length === 0) {
                        // If no wrapper, check the selector itself
                        $globalLabel = $selector.find('.wcvip-selected-variation-global');
                    }
                    if ($globalLabel.length > 0) {
                        $globalLabel.find('.wcvip-selected-value').text(variationName);
                        $globalLabel.show();
                    }
                }
            }

            /**
             * Update ARIA attributes
             */
            function updateAriaAttributesForVertical($activeItem) {
                $textBoxes.attr({
                    'aria-pressed': 'false',
                    'aria-checked': 'false'
                });
                
                $activeItem.attr({
                    'aria-pressed': 'true',
                    'aria-checked': 'true'
                });
            }

            // Initialize ARIA attributes on page load
            const $activeBox = $verticalList.find('.wcvip-text-box.active');
            if ($activeBox.length > 0) {
                updateAriaAttributesForVertical($activeBox);
            }
        }

        /**
         * Initialize enhanced features for Color Swatches
         * Includes: keyboard navigation, error handling
         */
        function initColorSwatchesEnhancements() {
            const $colorSwatches = $selector.find('.wcvip-color-swatches');
            
            if ($colorSwatches.length === 0) {
                return;
            }

            const $swatches = $colorSwatches.find('.wcvip-color-swatch');
            
            if ($swatches.length === 0) {
                return;
            }

            // Cache jQuery selectors for performance
            const $form = findVariationForm();
            
            /**
             * Enhanced click handler
             */
            $swatches.on('click', function(e) {
                e.preventDefault();
                
                const $item = $(this);
                
                // Prevent clicking on unavailable items
                if ($item.data('unavailable') === true || $item.attr('data-unavailable') === 'true') {
                    return;
                }
                
                const variationId = $item.data('variation-id');
                const attributes = $item.data('attributes');

                if (!variationId || !attributes) {
                    console.warn('WCVIP: Missing variation data', { variationId, attributes });
                    return;
                }
                
                try {
                    // Set WooCommerce variation
                    setWooCommerceVariation(attributes);

                    // Update active state
                    updateActiveStateForSwatches($item);

                    // Update label
                    updateSquareThumbnailsLabel($item);

                    // Trigger variation change
                    triggerVariationChange(variationId);
                    
                    // Update ARIA attributes
                    updateAriaAttributesForSwatches($item);
                    
                } catch (error) {
                    console.error('WCVIP: Error selecting variation', error);
                }
            });

            /**
             * Keyboard Navigation
             */
            $swatches.on('keydown', function(e) {
                const $current = $(this);
                const $allSwatches = $colorSwatches.find('.wcvip-color-swatch:not([data-unavailable="true"])');
                const currentIndex = $allSwatches.index($current);
                let $next = null;

                // Arrow Right or Down: Move to next
                if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
                    e.preventDefault();
                    $next = currentIndex < $allSwatches.length - 1 ? $allSwatches.eq(currentIndex + 1) : $allSwatches.first();
                }
                // Arrow Left or Up: Move to previous
                else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
                    e.preventDefault();
                    $next = currentIndex > 0 ? $allSwatches.eq(currentIndex - 1) : $allSwatches.last();
                }
                // Home: Move to first
                else if (e.key === 'Home') {
                    e.preventDefault();
                    $next = $allSwatches.first();
                }
                // End: Move to last
                else if (e.key === 'End') {
                    e.preventDefault();
                    $next = $allSwatches.last();
                }
                // Enter or Space: Select current
                else if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    $current.trigger('click');
                    return;
                }
                // Escape: Blur
                else if (e.key === 'Escape') {
                    e.preventDefault();
                    $current.blur();
                    return;
                }

                // Move focus to next item
                if ($next && $next.length > 0) {
                    $current.attr('tabindex', '-1');
                    $next.attr('tabindex', '0').focus();
                }
            });

            /**
             * Update active state
             */
            function updateActiveStateForSwatches($activeItem) {
                // Remove active from all
                $swatches.removeClass('active');
                // Remove active border from all
                $swatches.each(function() {
                    this.style.removeProperty('border-color');
                });
                
                // Add active class
                $activeItem.addClass('active');
                
                // Apply active border color via inline style with !important
                const activeBorderColor = getComputedStyle(document.documentElement).getPropertyValue('--wcvip-active-border-color').trim() || 'rgba(0, 0, 0, 0.6)';
                $activeItem[0].style.setProperty('border-color', activeBorderColor, 'important');
                
                // Update global selected variation label
                const variationName = $activeItem.data('variation-name');
                if (variationName) {
                    // Find the label directly - it's a sibling or in a parent container
                    const $closestContainer = $activeItem.closest('.wcvip-color-swatches');
                    let $globalLabel = $closestContainer.siblings('.wcvip-selected-variation-global');
                    if ($globalLabel.length === 0) {
                        // Try finding in parent container
                        $globalLabel = $closestContainer.parent().find('.wcvip-selected-variation-global');
                    }
                    if ($globalLabel.length === 0) {
                        // Fallback: search within entire selector
                        $globalLabel = $selector.find('.wcvip-selected-variation-global');
                    }
                    if ($globalLabel.length > 0) {
                        const $valueSpan = $globalLabel.find('.wcvip-selected-value');
                        $valueSpan.text(variationName);
                        // Ensure value span is visible
                        if ($valueSpan.length > 0) {
                            $valueSpan[0].style.setProperty('display', 'inline', 'important');
                            $valueSpan[0].style.setProperty('visibility', 'visible', 'important');
                            $valueSpan[0].style.setProperty('opacity', '1', 'important');
                        }
                        // Use !important via direct style attribute to override everything
                        $globalLabel[0].style.setProperty('display', 'block', 'important');
                        // Check if span still exists after a delay and restore if cleared
                        setTimeout(function() {
                            const $checkSpan = $globalLabel.find('.wcvip-selected-value');
                            if ($checkSpan.length > 0) {
                                const currentText = $checkSpan.text();
                                // If value was cleared, restore it
                                if (!currentText.trim()) {
                                    const storedName = $globalLabel.data('wcvip-variation-name') || variationName;
                                    $checkSpan.text(storedName);
                                    $checkSpan[0].style.setProperty('display', 'inline', 'important');
                                    $checkSpan[0].style.setProperty('visibility', 'visible', 'important');
                                    $checkSpan[0].style.setProperty('opacity', '1', 'important');
                                }
                            }
                        }, 200);
                        // Set up MutationObserver to catch if something tries to hide it or clear the value
                        if (!$globalLabel.data('wcvip-observer-setup')) {
                            const observer = new MutationObserver(function(mutations) {
                                mutations.forEach(function(mutation) {
                                    if (mutation.type === 'attributes' && mutation.attributeName === 'style') {
                                        const display = window.getComputedStyle($globalLabel[0]).display;
                                        if (display === 'none') {
                                            $globalLabel[0].style.setProperty('display', 'block', 'important');
                                        }
                                    }
                                    // Watch for child list changes (content being removed)
                                    if (mutation.type === 'childList') {
                                        const storedName = $globalLabel.data('wcvip-variation-name');
                                        const $valueSpan = $globalLabel.find('.wcvip-selected-value');
                                        if ($valueSpan.length > 0 && !$valueSpan.text().trim() && storedName) {
                                            $valueSpan.text(storedName);
                                            $valueSpan[0].style.setProperty('display', 'inline', 'important');
                                            $valueSpan[0].style.setProperty('visibility', 'visible', 'important');
                                            $valueSpan[0].style.setProperty('opacity', '1', 'important');
                                        }
                                    }
                                    // Watch for character data changes (text being cleared)
                                    if (mutation.type === 'characterData' || (mutation.type === 'childList' && mutation.target.classList && mutation.target.classList.contains('wcvip-selected-value'))) {
                                        const storedName = $globalLabel.data('wcvip-variation-name');
                                        const $valueSpan = $globalLabel.find('.wcvip-selected-value');
                                        if ($valueSpan.length > 0 && !$valueSpan.text().trim() && storedName) {
                                            $valueSpan.text(storedName);
                                        }
                                    }
                                });
                            });
                            observer.observe($globalLabel[0], {
                                attributes: true,
                                childList: true,
                                characterData: true,
                                subtree: true,
                                attributeFilter: ['style']
                            });
                            // Store the variation name so we can restore it
                            $globalLabel.data('wcvip-variation-name', variationName);
                            $globalLabel.data('wcvip-observer-setup', true);
                        } else {
                            // Update stored variation name if observer already exists
                            $globalLabel.data('wcvip-variation-name', variationName);
                        }
                        // Check after a short delay if something is hiding it
                        setTimeout(function() {
                            if ($globalLabel.css('display') === 'none') {
                                $globalLabel[0].style.setProperty('display', 'block', 'important');
                            }
                        }, 100);
                    }
                }
            }

            /**
             * Update ARIA attributes
             */
            function updateAriaAttributesForSwatches($activeItem) {
                $swatches.attr({
                    'aria-pressed': 'false',
                    'aria-checked': 'false'
                });
                
                $activeItem.attr({
                    'aria-pressed': 'true',
                    'aria-checked': 'true'
                });
            }

            // Initialize ARIA attributes on page load
            const $activeSwatch = $colorSwatches.find('.wcvip-color-swatch.active');
            if ($activeSwatch.length > 0) {
                updateAriaAttributesForSwatches($activeSwatch);
            }
        }

        /**
         * Initialize color swatches with default variation
         */
        function initColorSwatchesDefault() {
            // Find the label
            const $globalLabel = $selector.find('.wcvip-selected-variation-global');
            if ($globalLabel.length === 0) {
                return;
            }

            // Check if it's multi-attribute format
            const $multiAttributeContainer = $selector.find('.wcvip-color-swatches.wcvip-multi-attribute');
            let $defaultSwatch = null;
            
            if ($multiAttributeContainer.length > 0) {
                // Multi-attribute format: find default group and swatch within it
                const $defaultGroup = $multiAttributeContainer.find('.wcvip-attribute-group.wcvip-group-active');
                
                if ($defaultGroup.length > 0) {
                    // Find swatches within the default group
                    const $groupSwatches = $defaultGroup.find('.wcvip-color-swatch');
                    
                    if ($groupSwatches.length > 0) {
                        // Check for active swatch first
                        $defaultSwatch = $groupSwatches.filter('.active').first();
                        
                        // If no active swatch, check WooCommerce form for default attributes
                        if ($defaultSwatch.length === 0) {
                            const $form = findVariationForm();
                            if ($form.length > 0) {
                                // Get default attributes from form
                                const defaultAttributes = {};
                                $form.find('.variations select').each(function() {
                                    const $select = $(this);
                                    const attrName = $select.data('attribute_name') || $select.attr('name');
                                    if (attrName) {
                                        const selectedValue = $select.val();
                                        if (selectedValue) {
                                            defaultAttributes[attrName] = selectedValue;
                                        }
                                    }
                                });

                                // If we have default attributes, find matching swatch
                                if (Object.keys(defaultAttributes).length > 0) {
                                    $groupSwatches.each(function() {
                                        const $swatch = $(this);
                                        const swatchAttributes = $swatch.data('attributes');
                                        if (swatchAttributes) {
                                            // Check if swatch attributes match default attributes
                                            let matches = true;
                                            for (const attrName in defaultAttributes) {
                                                const attrKey = attrName.startsWith('attribute_') ? attrName : 'attribute_' + attrName;
                                                if (swatchAttributes[attrKey] !== defaultAttributes[attrName]) {
                                                    matches = false;
                                                    break;
                                                }
                                            }
                                            if (matches) {
                                                $defaultSwatch = $swatch;
                                                return false; // Break the loop
                                            }
                                        }
                                    });
                                }
                            }
                        }
                        
                        // If still no default, use first available swatch in the group
                        if ($defaultSwatch.length === 0) {
                            $defaultSwatch = $groupSwatches.filter(':not([data-unavailable="true"])').first();
                        }
                    }
                }
            } else {
                // Single attribute format: find swatches in container
                let $colorSwatches = $selector.find('.wcvip-color-swatches .wcvip-color-swatches');
                if ($colorSwatches.length === 0) {
                    // Fallback to outer container
                    const $outerContainer = $selector.find('.wcvip-color-swatches').first();
                    if ($outerContainer.length > 0) {
                        $colorSwatches = $outerContainer.find('.wcvip-color-swatches');
                    }
                }
                
                if ($colorSwatches.length === 0) {
                    return;
                }

                const $swatches = $colorSwatches.find('.wcvip-color-swatch');
                
                if ($swatches.length === 0) {
                    return;
                }

                // Check for active swatch first (if one is already marked as active)
                $defaultSwatch = $swatches.filter('.active').first();
                
                // If no active swatch, check WooCommerce form for default attributes
                if ($defaultSwatch.length === 0) {
                    const $form = findVariationForm();
                    if ($form.length > 0) {
                        // Get default attributes from form
                        const defaultAttributes = {};
                        $form.find('.variations select').each(function() {
                            const $select = $(this);
                            const attrName = $select.data('attribute_name') || $select.attr('name');
                            if (attrName) {
                                const selectedValue = $select.val();
                                if (selectedValue) {
                                    defaultAttributes[attrName] = selectedValue;
                                }
                            }
                        });

                        // If we have default attributes, find matching swatch
                        if (Object.keys(defaultAttributes).length > 0) {
                            $swatches.each(function() {
                                const $swatch = $(this);
                                const swatchAttributes = $swatch.data('attributes');
                                if (swatchAttributes) {
                                    // Check if swatch attributes match default attributes
                                    let matches = true;
                                    for (const attrName in defaultAttributes) {
                                        const attrKey = attrName.startsWith('attribute_') ? attrName : 'attribute_' + attrName;
                                        if (swatchAttributes[attrKey] !== defaultAttributes[attrName]) {
                                            matches = false;
                                            break;
                                        }
                                    }
                                    if (matches) {
                                        $defaultSwatch = $swatch;
                                        return false; // Break the loop
                                    }
                                }
                            });
                        }
                    }
                }

                // If still no default, use first available swatch
                if ($defaultSwatch.length === 0) {
                    $defaultSwatch = $swatches.filter(':not([data-unavailable="true"])').first();
                }
            }

            // If we found a default swatch, update the label
            if ($defaultSwatch.length > 0) {
                const variationName = $defaultSwatch.data('variation-name');
                if (variationName) {
                    const $valueSpan = $globalLabel.find('.wcvip-selected-value');
                    $valueSpan.text(variationName);
                    
                    // Ensure value span is visible
                    if ($valueSpan.length > 0) {
                        $valueSpan[0].style.setProperty('display', 'inline', 'important');
                        $valueSpan[0].style.setProperty('visibility', 'visible', 'important');
                        $valueSpan[0].style.setProperty('opacity', '1', 'important');
                    }
                    
                    // Show the label
                    $globalLabel[0].style.setProperty('display', 'block', 'important');
                    
                    // Store variation name for restoration
                    $globalLabel.data('wcvip-variation-name', variationName);
                    
                    // Set up MutationObserver to protect the label from being hidden
                    if (!$globalLabel.data('wcvip-observer-setup')) {
                        const observer = new MutationObserver(function(mutations) {
                            mutations.forEach(function(mutation) {
                                if (mutation.type === 'attributes' && mutation.attributeName === 'style') {
                                    const display = window.getComputedStyle($globalLabel[0]).display;
                                    if (display === 'none') {
                                        $globalLabel[0].style.setProperty('display', 'block', 'important');
                                    }
                                }
                                // Watch for content being cleared
                                if (mutation.type === 'childList' || mutation.type === 'characterData') {
                                    const $valueSpan = $globalLabel.find('.wcvip-selected-value');
                                    if ($valueSpan.length > 0 && !$valueSpan.text().trim()) {
                                        const storedName = $globalLabel.data('wcvip-variation-name');
                                        if (storedName) {
                                            $valueSpan.text(storedName);
                                            $valueSpan[0].style.setProperty('display', 'inline', 'important');
                                            $valueSpan[0].style.setProperty('visibility', 'visible', 'important');
                                            $valueSpan[0].style.setProperty('opacity', '1', 'important');
                                        }
                                    }
                                }
                            });
                        });
                        observer.observe($globalLabel[0], {
                            attributes: true,
                            childList: true,
                            characterData: true,
                            subtree: true,
                            attributeFilter: ['style']
                        });
                        $globalLabel.data('wcvip-observer-setup', true);
                    }
                    
                    // Mark swatch as active
                    $defaultSwatch.addClass('active');
                    $defaultSwatch.attr({
                        'aria-pressed': 'true',
                        'aria-checked': 'true'
                    });
                    
                    // Apply active border color via inline style with !important
                    const activeBorderColor = getComputedStyle(document.documentElement).getPropertyValue('--wcvip-active-border-color').trim() || 'rgba(0, 0, 0, 0.6)';
                    $defaultSwatch[0].style.setProperty('border-color', activeBorderColor, 'important');
                    
                    // Check after a delay if something hid it
                    setTimeout(function() {
                        if ($globalLabel.css('display') === 'none') {
                            $globalLabel[0].style.setProperty('display', 'block', 'important');
                        }
                        const $valueSpan = $globalLabel.find('.wcvip-selected-value');
                        if ($valueSpan.length > 0 && !$valueSpan.text().trim()) {
                            const storedName = $globalLabel.data('wcvip-variation-name');
                            if (storedName) {
                                $valueSpan.text(storedName);
                                $valueSpan[0].style.setProperty('display', 'inline', 'important');
                                $valueSpan[0].style.setProperty('visibility', 'visible', 'important');
                                $valueSpan[0].style.setProperty('opacity', '1', 'important');
                            }
                        }
                    }, 200);
                }
            }
        }

        /**
         * Initialize enhanced features for Button Style
         * Includes: keyboard navigation, error handling
         */
        function initButtonStyleEnhancements() {
            const $buttonStyle = $selector.find('.wcvip-button-style');
            
            if ($buttonStyle.length === 0) {
                return;
            }

            const $buttons = $buttonStyle.find('.wcvip-button-thumb');
            
            if ($buttons.length === 0) {
                return;
            }

            // Cache jQuery selectors for performance
            const $form = findVariationForm();
            const isHorizontal = $buttonStyle.hasClass('wcvip-orientation-horizontal');
            
            /**
             * Enhanced click handler
             */
            $buttons.on('click', function(e) {
                e.preventDefault();
                
                const $item = $(this);
                
                // Skip if within attribute sections - they have their own handler
                if ($item.closest('.wcvip-attribute-sections-container').length > 0) {
                    return;
                }
                
                e.stopPropagation();
                
                // Prevent clicking on unavailable items
                if ($item.data('unavailable') === true || $item.attr('data-unavailable') === 'true') {
                    return;
                }
                
                const variationId = $item.data('variation-id');
                let attributes = $item.data('attributes');
                
                // If attributes is a string (JSON), parse it
                if (typeof attributes === 'string') {
                    try {
                        attributes = JSON.parse(attributes);
                    } catch (e) {
                        console.error('WCVIP: Failed to parse attributes JSON', e);
                        return;
                    }
                }

                if (!variationId || !attributes) {
                    console.warn('WCVIP: Missing variation data', { variationId, attributes });
                    return;
                }
                
                try {
                    // Set WooCommerce variation
                    setWooCommerceVariation(attributes);

                    // Update active state
                    updateActiveStateForButtons($item);

                    // Trigger variation change
                    triggerVariationChange(variationId);
                    
                    // Update ARIA attributes
                    updateAriaAttributesForButtons($item);
                    
                } catch (error) {
                    console.error('WCVIP: Error selecting variation', error);
                }
            });

            /**
             * Keyboard Navigation
             */
            $buttons.on('keydown', function(e) {
                const $current = $(this);
                
                // Skip if within attribute sections - they have their own handler
                if ($current.closest('.wcvip-attribute-sections-container').length > 0) {
                    return;
                }
                
                const $allButtons = $buttonStyle.find('.wcvip-button-thumb:not([data-unavailable="true"])');
                const currentIndex = $allButtons.index($current);
                let $next = null;

                // Arrow Right or Down: Move to next
                if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
                    e.preventDefault();
                    $next = currentIndex < $allButtons.length - 1 ? $allButtons.eq(currentIndex + 1) : $allButtons.first();
                }
                // Arrow Left or Up: Move to previous
                else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
                    e.preventDefault();
                    $next = currentIndex > 0 ? $allButtons.eq(currentIndex - 1) : $allButtons.last();
                }
                // Home: Move to first
                else if (e.key === 'Home') {
                    e.preventDefault();
                    $next = $allButtons.first();
                }
                // End: Move to last
                else if (e.key === 'End') {
                    e.preventDefault();
                    $next = $allButtons.last();
                }
                // Enter or Space: Select current
                else if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    $current.trigger('click');
                    return;
                }
                // Escape: Blur
                else if (e.key === 'Escape') {
                    e.preventDefault();
                    $current.blur();
                    return;
                }

                // Move focus to next item
                if ($next && $next.length > 0) {
                    $current.attr('tabindex', '-1');
                    $next.attr('tabindex', '0').focus();
                }
            });

            /**
             * Update active state
             */
            function updateActiveStateForButtons($activeItem) {
                // Remove active from all
                $buttons.removeClass('active');
                
                // Add active class
                $activeItem.addClass('active');
                
                // Update global selected variation label
                const variationName = $activeItem.data('variation-name');
                if (variationName) {
                    const $globalLabel = $buttonStyle.find('.wcvip-selected-variation-global');
                    if ($globalLabel.length > 0) {
                        $globalLabel.find('.wcvip-selected-value').text(variationName);
                        $globalLabel.show();
                    }
                }
            }

            /**
             * Update ARIA attributes
             */
            function updateAriaAttributesForButtons($activeItem) {
                $buttons.attr({
                    'aria-pressed': 'false',
                    'aria-checked': 'false'
                });
                
                $activeItem.attr({
                    'aria-pressed': 'true',
                    'aria-checked': 'true'
                });
            }

            // Initialize ARIA attributes on page load
            const $activeButton = $buttonStyle.find('.wcvip-button-thumb.active');
            if ($activeButton.length > 0) {
                updateAriaAttributesForButtons($activeButton);
            }
        }

        /**
         * Initialize enhanced features for Square Thumbnails
         * Includes: keyboard navigation, error handling
         */
        function initSquareThumbnailsEnhancements() {
            const $squareThumbnails = $selector.find('.wcvip-square-thumbnails');
            
            if ($squareThumbnails.length === 0) {
                return;
            }

            const $thumbs = $squareThumbnails.find('.wcvip-square-thumb');
            
            if ($thumbs.length === 0) {
                return;
            }

            // Cache jQuery selectors
            const $form = findVariationForm();
            
            // Check for default variation on page load (single attribute format)
            // For single attribute, check if there's an active thumb or find the first thumb
            const $wrapper = $squareThumbnails.closest('.wcvip-square-thumbnails-wrapper');
            const $oldLabel = $wrapper.find('.wcvip-square-thumbnails-label');
            if ($oldLabel.length === 0) {
                // Single attribute format - check for active thumb or default
                const $activeThumb = $thumbs.filter('.active');
                if ($activeThumb.length > 0) {
                    const variationName = $activeThumb.data('variation-name');
                    if (variationName) {
                        const $globalLabel = $wrapper.find('.wcvip-selected-variation-global');
                        if ($globalLabel.length > 0) {
                            $globalLabel.find('.wcvip-selected-value').text(variationName);
                            $globalLabel.show();
                        }
                    }
                } else {
                    // Check if first thumb should be active (default variation)
                    const $firstThumb = $thumbs.first();
                    if ($firstThumb.length > 0 && !$firstThumb.data('unavailable')) {
                        const variationName = $firstThumb.data('variation-name');
                        if (variationName) {
                            const $globalLabel = $wrapper.find('.wcvip-selected-variation-global');
                            if ($globalLabel.length > 0) {
                                $globalLabel.find('.wcvip-selected-value').text(variationName);
                                $globalLabel.show();
                                $firstThumb.addClass('active');
                            }
                        }
                    }
                }
            }
            
            /**
             * Enhanced click handler
             */
            $thumbs.on('click', function(e) {
                e.preventDefault();
                
                const $item = $(this);
                
                // Skip if within attribute sections - they have their own handler
                if ($item.closest('.wcvip-attribute-sections-container').length > 0) {
                    return;
                }
                
                if ($item.data('unavailable') === true || $item.attr('data-unavailable') === 'true') {
                    return;
                }
                
                const variationId = $item.data('variation-id');
                const attributes = $item.data('attributes');

                if (!variationId || !attributes) {
                    console.warn('WCVIP: Missing variation data', { variationId, attributes });
                    return;
                }
                
                try {
                    setWooCommerceVariation(attributes);
                    updateActiveStateForSquare($item);
                    triggerVariationChange(variationId);
                    updateAriaAttributesForSquare($item);
                    updateSquareThumbnailsLabel($item);
                } catch (error) {
                    console.error('WCVIP: Error selecting variation', error);
                }
            });

            /**
             * Keyboard Navigation
             */
            $thumbs.on('keydown', function(e) {
                const $current = $(this);
                
                // Skip if within attribute sections - they have their own handler
                if ($current.closest('.wcvip-attribute-sections-container').length > 0) {
                    return;
                }
                
                const $allThumbs = $squareThumbnails.find('.wcvip-square-thumb:not([data-unavailable="true"])');
                const currentIndex = $allThumbs.index($current);
                let $next = null;

                if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
                    e.preventDefault();
                    $next = currentIndex < $allThumbs.length - 1 ? $allThumbs.eq(currentIndex + 1) : $allThumbs.first();
                } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
                    e.preventDefault();
                    $next = currentIndex > 0 ? $allThumbs.eq(currentIndex - 1) : $allThumbs.last();
                } else if (e.key === 'Home') {
                    e.preventDefault();
                    $next = $allThumbs.first();
                } else if (e.key === 'End') {
                    e.preventDefault();
                    $next = $allThumbs.last();
                } else if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    $current.trigger('click');
                    return;
                } else if (e.key === 'Escape') {
                    e.preventDefault();
                    $current.blur();
                    return;
                }

                if ($next && $next.length > 0) {
                    $current.attr('tabindex', '-1');
                    $next.attr('tabindex', '0').focus();
                }
            });

            function updateActiveStateForSquare($activeItem) {
                $thumbs.removeClass('active');
                $activeItem.addClass('active');
                
                // Update global selected variation label (for both single attribute and grouped format)
                const variationName = $activeItem.data('variation-name');
                if (variationName) {
                    const $globalLabel = $selector.find('.wcvip-square-thumbnails-wrapper .wcvip-selected-variation-global');
                    if ($globalLabel.length > 0) {
                        $globalLabel.find('.wcvip-selected-value').text(variationName);
                        $globalLabel.show();
                    }
                }
                
                // Auto-expand group when variation is selected (grouped format only)
                const $group = $activeItem.closest('.wcvip-attribute-group');
                if ($group.length > 0) {
                    $group.removeClass('wcvip-group-collapsed').addClass('wcvip-group-active');
                    const $content = $group.find('.wcvip-group-content');
                    $content.slideDown(200);
                    
                    // Scroll to group if needed
                    const groupOffset = $group.offset().top;
                    const windowScroll = $(window).scrollTop();
                    const windowHeight = $(window).height();
                    if (groupOffset < windowScroll || groupOffset > windowScroll + windowHeight - 100) {
                        $('html, body').animate({
                            scrollTop: groupOffset - 50
                        }, 300);
                    }
                }
            }

            function updateAriaAttributesForSquare($activeItem) {
                $thumbs.attr({ 'aria-pressed': 'false', 'aria-checked': 'false' });
                $activeItem.attr({ 'aria-pressed': 'true', 'aria-checked': 'true' });
            }

            const $activeThumb = $squareThumbnails.find('.wcvip-square-thumb.active');
            if ($activeThumb.length > 0) {
                updateAriaAttributesForSquare($activeThumb);
            }
        }

        /**
         * Initialize enhanced features for Circular Thumbnails
         * Includes: keyboard navigation, error handling
         */
        function initCircularThumbnailsEnhancements() {
            const $circularThumbnails = $selector.find('.wcvip-circular-thumbnails');
            
            if ($circularThumbnails.length === 0) {
                return;
            }

            const $thumbs = $circularThumbnails.find('.wcvip-circular-thumb');
            
            if ($thumbs.length === 0) {
                return;
            }

            // Cache jQuery selectors
            const $form = findVariationForm();
            
            // Check for default variation on page load (single attribute format)
            // For single attribute, check if there's an active thumb or find the first thumb
            const $wrapper = $circularThumbnails.closest('.wcvip-circular-thumbnails-wrapper');
            const $oldLabel = $wrapper.find('.wcvip-circular-thumbnails-label');
            if ($oldLabel.length === 0) {
                // Single attribute format - check for active thumb or default
                const $activeThumb = $thumbs.filter('.active');
                if ($activeThumb.length > 0) {
                    const variationName = $activeThumb.data('variation-name');
                    if (variationName) {
                        const $globalLabel = $wrapper.find('.wcvip-selected-variation-global');
                        if ($globalLabel.length > 0) {
                            $globalLabel.find('.wcvip-selected-value').text(variationName);
                            $globalLabel.show();
                        }
                    }
                } else {
                    // Check if first thumb should be active (default variation)
                    const $firstThumb = $thumbs.first();
                    if ($firstThumb.length > 0 && !$firstThumb.data('unavailable')) {
                        const variationName = $firstThumb.data('variation-name');
                        if (variationName) {
                            const $globalLabel = $wrapper.find('.wcvip-selected-variation-global');
                            if ($globalLabel.length > 0) {
                                $globalLabel.find('.wcvip-selected-value').text(variationName);
                                $globalLabel.show();
                                $firstThumb.addClass('active');
                            }
                        }
                    }
                }
            }
            
            /**
             * Enhanced click handler
             */
            $thumbs.on('click', function(e) {
                e.preventDefault();
                
                const $item = $(this);
                
                // Skip if within attribute sections - they have their own handler
                if ($item.closest('.wcvip-attribute-sections-container').length > 0) {
                    return;
                }
                
                if ($item.data('unavailable') === true || $item.attr('data-unavailable') === 'true') {
                    return;
                }
                
                const variationId = $item.data('variation-id');
                const attributes = $item.data('attributes');

                if (!variationId || !attributes) {
                    console.warn('WCVIP: Missing variation data', { variationId, attributes });
                    return;
                }
                
                try {
                    setWooCommerceVariation(attributes);
                    updateActiveStateForCircular($item);
                    triggerVariationChange(variationId);
                    updateAriaAttributesForCircular($item);
                    updateCircularThumbnailsLabel($item);
                } catch (error) {
                    console.error('WCVIP: Error selecting variation', error);
                }
            });

            /**
             * Keyboard Navigation
             */
            $thumbs.on('keydown', function(e) {
                const $current = $(this);
                
                // Skip if within attribute sections - they have their own handler
                if ($current.closest('.wcvip-attribute-sections-container').length > 0) {
                    return;
                }
                
                const $allThumbs = $circularThumbnails.find('.wcvip-circular-thumb:not([data-unavailable="true"])');
                const currentIndex = $allThumbs.index($current);
                let $next = null;

                if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
                    e.preventDefault();
                    $next = currentIndex < $allThumbs.length - 1 ? $allThumbs.eq(currentIndex + 1) : $allThumbs.first();
                } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
                    e.preventDefault();
                    $next = currentIndex > 0 ? $allThumbs.eq(currentIndex - 1) : $allThumbs.last();
                } else if (e.key === 'Home') {
                    e.preventDefault();
                    $next = $allThumbs.first();
                } else if (e.key === 'End') {
                    e.preventDefault();
                    $next = $allThumbs.last();
                } else if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    $current.trigger('click');
                    return;
                } else if (e.key === 'Escape') {
                    e.preventDefault();
                    $current.blur();
                    return;
                }

                if ($next && $next.length > 0) {
                    $current.attr('tabindex', '-1');
                    $next.attr('tabindex', '0').focus();
                }
            });

            function updateActiveStateForCircular($activeItem) {
                $thumbs.removeClass('active');
                $activeItem.addClass('active');
                
                // Update global selected variation label (for both single attribute and grouped format)
                const variationName = $activeItem.data('variation-name');
                if (variationName) {
                    const $globalLabel = $selector.find('.wcvip-circular-thumbnails-wrapper .wcvip-selected-variation-global');
                    if ($globalLabel.length > 0) {
                        $globalLabel.find('.wcvip-selected-value').text(variationName);
                        $globalLabel.show();
                    }
                }
                
                // Auto-expand group when variation is selected (grouped format only)
                const $group = $activeItem.closest('.wcvip-attribute-group');
                if ($group.length > 0) {
                    $group.removeClass('wcvip-group-collapsed').addClass('wcvip-group-active');
                    const $content = $group.find('.wcvip-group-content');
                    $content.slideDown(200);
                    
                    // Scroll to group if needed
                    const groupOffset = $group.offset().top;
                    const windowScroll = $(window).scrollTop();
                    const windowHeight = $(window).height();
                    if (groupOffset < windowScroll || groupOffset > windowScroll + windowHeight - 100) {
                        $('html, body').animate({
                            scrollTop: groupOffset - 50
                        }, 300);
                    }
                }
            }

            function updateAriaAttributesForCircular($activeItem) {
                $thumbs.attr({ 'aria-pressed': 'false', 'aria-checked': 'false' });
                $activeItem.attr({ 'aria-pressed': 'true', 'aria-checked': 'true' });
            }

            function updateCircularThumbnailsLabel($selectedThumb) {
                const variationValue = $selectedThumb.data('variation-value');
                if (!variationValue) {
                    return;
                }
                
                const $circularLabel = $selector.find('.wcvip-circular-thumbnails-label');
                if ($circularLabel.length > 0) {
                    $circularLabel.find('.wcvip-label-value').text(variationValue);
                }
            }

            const $activeThumb = $circularThumbnails.find('.wcvip-circular-thumb.active');
            if ($activeThumb.length > 0) {
                updateAriaAttributesForCircular($activeThumb);
            }
        }

        /**
         * Initialize collapsible attribute groups
         * Note: Square and Circular thumbnails don't use collapsible groups
         */
        function initCollapsibleGroups() {
            // Skip Square and Circular thumbnails - they have always-visible groups
            const $groups = $selector.find('.wcvip-attribute-group').not('.wcvip-square-thumbnails-wrapper .wcvip-attribute-group, .wcvip-circular-thumbnails-wrapper .wcvip-attribute-group');
            
            if ($groups.length === 0) {
                return;
            }

            // Use event delegation to handle group toggle clicks (works even if elements are added dynamically)
            $selector.off('click', '.wcvip-group-toggle').on('click', '.wcvip-group-toggle', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                const $toggle = $(this);
                const $group = $toggle.closest('.wcvip-attribute-group');
                
                // Skip if this is Square or Circular thumbnails
                if ($group.closest('.wcvip-square-thumbnails-wrapper, .wcvip-circular-thumbnails-wrapper').length > 0) {
                    return;
                }
                
                const $content = $group.find('.wcvip-group-content');
                const isExpanded = $toggle.attr('aria-expanded') === 'true';
                
                // Toggle state
                if (isExpanded) {
                    // Collapse
                    $group.addClass('wcvip-group-collapsed').removeClass('wcvip-group-active');
                    $toggle.attr('aria-expanded', 'false');
                    $content.slideUp(300);
                } else {
                    // Expand
                    $group.removeClass('wcvip-group-collapsed').addClass('wcvip-group-active');
                    $toggle.attr('aria-expanded', 'true');
                    $content.slideDown(300);
                }
            });
        }

        // Initialize collapsible groups
        initCollapsibleGroups();

        /**
         * Initialize lazy loading for many variations
         * Works with both grouped and non-grouped displays
         */
        function initLazyLoading() {
            const $selectorContainer = $selector.find('.wcvip-circular-thumbnails-wrapper, .wcvip-square-thumbnails-wrapper, .wcvip-rectangular-thumbnails, .wcvip-grid-layout, .wcvip-horizontal-strip, .wcvip-vertical-list, .wcvip-button-style, .wcvip-horizontal-text-boxes-wrapper, .wcvip-vertical-text-list-wrapper, .wcvip-color-swatches-wrapper, .wcvip-attribute-section-wrapper');
            
            $selectorContainer.each(function() {
                const $container = $(this);
                // Find all variation items (including those in groups and attribute sections)
                // Attribute sections use [data-attributes], regular items use [data-variation-id]
                const $items = $container.find('[data-variation-id], [data-attributes]').filter(':visible');
                const totalItems = $container.find('[data-variation-id], [data-attributes]').length;
                
                // For attribute sections, use 10 as threshold; for grouped format, use 30
                const isAttributeSection = $container.hasClass('wcvip-attribute-section-wrapper');
                const initialBatch = isAttributeSection ? 10 : 30; // Show first 10 items for attribute sections, 30 for grouped
                const batchSize = isAttributeSection ? 10 : 20; // Load 10 more at a time for attribute sections, 20 for grouped
                
                // Only enable lazy loading if there are more than initial batch
                if (totalItems <= initialBatch) {
                    return;
                }
                
                // Get all items (including hidden ones in collapsed groups and attribute sections)
                const $allItems = $container.find('[data-variation-id], [data-attributes]');
                
                // Hide items beyond initial batch (only if they're currently visible)
                $allItems.each(function(index) {
                    if (index >= initialBatch && $(this).is(':visible')) {
                        $(this).addClass('wcvip-lazy-hidden').hide();
                    }
                });
                
                // Add "Load More" button (wrapped in centered container)
                const $loadMoreBtn = $('<button>', {
                    type: 'button',
                    class: 'wcvip-load-more-btn',
                    text: 'Load More (' + (totalItems - initialBatch) + ' remaining)',
                    'data-loaded': initialBatch,
                    'data-total': totalItems,
                    'data-batch-size': batchSize
                });
                
                const $buttonWrapper = $('<div>', {
                    class: 'wcvip-load-more-wrapper',
                    css: { 'text-align': 'center' }
                }).append($loadMoreBtn);
                
                $container.after($buttonWrapper);
                
                // Function to load next batch
                function loadNextBatch() {
                    const loaded = parseInt($loadMoreBtn.data('loaded'), 10);
                    const total = parseInt($loadMoreBtn.data('total'), 10);
                    const batchSize = parseInt($loadMoreBtn.data('batch-size'), 10);
                    const nextBatch = Math.min(loaded + batchSize, total);
                    
                    // Show next batch of lazy-hidden items
                    let shownCount = 0;
                    $allItems.each(function(index) {
                        if (index >= loaded && index < nextBatch && $(this).hasClass('wcvip-lazy-hidden')) {
                            $(this).removeClass('wcvip-lazy-hidden').fadeIn(300);
                            shownCount++;
                        }
                    });
                    
                    // Update button
                    const remaining = total - nextBatch;
                    if (remaining > 0) {
                        $loadMoreBtn.data('loaded', nextBatch);
                        $loadMoreBtn.text('Load More (' + remaining + ' remaining)');
                    } else {
                        $buttonWrapper.fadeOut(300, function() {
                            $(this).remove();
                        });
                    }
                }
                
                // Handle "Load More" click
                $loadMoreBtn.on('click', function() {
                    loadNextBatch();
                });
                
                // Also detect scroll near bottom for auto-loading
                let isLoading = false;
                $container.on('scroll', function() {
                    if (isLoading) return;
                    
                    const $scrollContainer = $(this);
                    const scrollTop = $scrollContainer.scrollTop();
                    const scrollHeight = $scrollContainer[0].scrollHeight;
                    const clientHeight = $scrollContainer[0].clientHeight;
                    const loaded = parseInt($loadMoreBtn.data('loaded'), 10);
                    const total = parseInt($loadMoreBtn.data('total'), 10);
                    
                    // If scrolled near bottom (within 100px) and more items to load
                    if (scrollTop + clientHeight >= scrollHeight - 100 && loaded < total) {
                        isLoading = true;
                        loadNextBatch();
                        setTimeout(function() {
                            isLoading = false;
                        }, 500);
                    }
                });
                
                // Re-check when groups are expanded (items might become visible)
                $container.closest('.wcvip-variation-selector').on('wcvip:group-expanded', function() {
                    // Recalculate visible items and update button if needed
                    const visibleCount = $container.find('[data-variation-id]:visible').length;
                    const loaded = parseInt($loadMoreBtn.data('loaded'), 10);
                    if (visibleCount > loaded) {
                        $loadMoreBtn.data('loaded', visibleCount);
                    }
                });
            });
        }
        
        /**
         * Initialize image loading optimization for multi-attribute groups
         * Preloads default group images and uses Intersection Observer for others
         */
        function initImageLoadingOptimization() {
            const $wrapper = $selector.find('.wcvip-square-thumbnails-wrapper.wcvip-multi-attribute, .wcvip-circular-thumbnails-wrapper.wcvip-multi-attribute');
            
            if ($wrapper.length === 0) {
                return;
            }
            
            // Preload images in default group immediately
            const $defaultGroup = $wrapper.find('.wcvip-attribute-group[data-is-default-group="true"]');
            if ($defaultGroup.length > 0) {
                const $defaultImages = $defaultGroup.find('.wcvip-variation-image');
                $defaultImages.each(function() {
                    const $img = $(this);
                    if (!$img.hasClass('loaded')) {
                        const img = new Image();
                        img.onload = function() {
                            $img.addClass('loaded');
                        };
                        img.src = $img.attr('src');
                        // If already loaded (cached), mark as loaded immediately
                        if (img.complete) {
                            $img.addClass('loaded');
                        }
                    }
                });
            }
            
            // Set up Intersection Observer for lazy-loaded images in non-default groups
            if ('IntersectionObserver' in window) {
                const imageObserver = new IntersectionObserver(function(entries, observer) {
                    entries.forEach(function(entry) {
                        if (entry.isIntersecting) {
                            const $img = $(entry.target);
                            if (!$img.hasClass('loaded') && $img.attr('data-wcvip-lazy') === 'true') {
                                // Load the image
                                const img = new Image();
                                img.onload = function() {
                                    $img.addClass('loaded');
                                };
                                img.src = $img.attr('src');
                                // If already loaded (cached), mark as loaded immediately
                                if (img.complete) {
                                    $img.addClass('loaded');
                                }
                                // Remove lazy attribute and stop observing
                                $img.removeAttr('data-wcvip-lazy');
                                observer.unobserve(entry.target);
                            }
                        }
                    });
                }, {
                    rootMargin: '50px' // Start loading 50px before image enters viewport
                });
                
                // Observe all lazy images in non-default groups
                $wrapper.find('.wcvip-attribute-group:not([data-is-default-group="true"]) .wcvip-variation-image[data-wcvip-lazy="true"]').each(function() {
                    imageObserver.observe(this);
                });
                
                // Also observe images when groups are expanded
                $wrapper.on('wcvip:group-expanded', function(e) {
                    const $expandedGroup = $(e.target).closest('.wcvip-attribute-group');
                    if ($expandedGroup.length > 0 && !$expandedGroup.attr('data-is-default-group')) {
                        $expandedGroup.find('.wcvip-variation-image[data-wcvip-lazy="true"]').each(function() {
                            imageObserver.observe(this);
                        });
                    }
                });
            } else {
                // Fallback for browsers without Intersection Observer
                // Load images when they become visible
                $wrapper.find('.wcvip-attribute-group:not([data-is-default-group="true"]) .wcvip-variation-image[data-wcvip-lazy="true"]').each(function() {
                    const $img = $(this);
                    const checkVisibility = function() {
                        const rect = $img[0].getBoundingClientRect();
                        const isVisible = rect.top < window.innerHeight + 100 && rect.bottom > -100;
                        if (isVisible && !$img.hasClass('loaded')) {
                            const img = new Image();
                            img.onload = function() {
                                $img.addClass('loaded');
                            };
                            img.src = $img.attr('src');
                            if (img.complete) {
                                $img.addClass('loaded');
                            }
                            $img.removeAttr('data-wcvip-lazy');
                            $(window).off('scroll resize', checkVisibility);
                        }
                    };
                    $(window).on('scroll resize', checkVisibility);
                    checkVisibility(); // Check immediately
                });
            }
        }

        /**
         * Initialize attribute sections format
         * Handles progressive selection and availability filtering
         */
        function initAttributeSections() {
            const $container = $selector.find('.wcvip-attribute-sections-container');
            if ($container.length === 0) {
                return;
            }

            /**
             * Remove stock status text from display name
             */
            function stripStockStatus(displayName) {
                if (!displayName) return displayName;
                return displayName.replace(/\s*\(In Stock\)/gi, '').replace(/\s*\(Out of Stock\)/gi, '').trim();
            }

            // Get all variations data from the selector
            const variationsData = $selector.data('variations') || [];
            const selectedAttributes = {};
            const $sections = $container.find('.wcvip-attribute-section');

            // Initialize default selections and enhance items with additional data attributes
            $sections.each(function() {
                const $section = $(this);
                const attributeKey = $section.data('attribute-key');
                const $selectedValue = $section.find('.wcvip-attribute-selected-value');
                const defaultText = $selectedValue.text().trim();
                
                // Enhance items with additional data attributes for easier access
                $section.find('[data-attributes]').each(function() {
                    const $item = $(this);
                    const itemAttributes = $item.data('attributes');
                    if (itemAttributes && itemAttributes[attributeKey]) {
                        // Add data-attribute-value and data-attribute-display-name if not already present
                        if (!$item.attr('data-attribute-value')) {
                            $item.attr('data-attribute-value', itemAttributes[attributeKey]);
                        }
                        if (!$item.attr('data-attribute-display-name')) {
                            // Try to get display name from various sources
                            let displayName = $item.find('.wcvip-text-box-content').text().trim() ||
                                              $item.find('.wcvip-button-text').text().trim() ||
                                              $item.find('.wcvip-variation-name-label').text().trim() ||
                                              $item.find('.wcvip-secondary-label').text().trim() ||
                                              $item.attr('title') ||
                                              $item.attr('data-variation-name') ||
                                              $item.find('img').attr('alt') ||
                                              itemAttributes[attributeKey];
                            // Remove stock status text from display name
                            displayName = stripStockStatus(displayName);
                            $item.attr('data-attribute-display-name', displayName);
                        }
                    }
                });
                
                // Find the default value from the selected value display or first active item
                if (defaultText && defaultText !== 'Select') {
                    // Strip stock status from default text for comparison
                    const cleanDefaultText = stripStockStatus(defaultText);
                    // Try to find item matching the default text
                    const $matchingItem = $section.find('[data-attributes]').filter(function() {
                        const $item = $(this);
                        let displayName = $item.attr('data-attribute-display-name') ||
                                         $item.find('.wcvip-text-box-content').text().trim() ||
                                         $item.find('.wcvip-button-text').text().trim() ||
                                         $item.find('.wcvip-variation-name-label').text().trim() ||
                                         $item.find('.wcvip-secondary-label').text().trim() ||
                                         $item.attr('title') ||
                                         $item.attr('data-variation-name') ||
                                         '';
                        // Strip stock status from display name for comparison
                        displayName = stripStockStatus(displayName);
                        return displayName === cleanDefaultText;
                    }).first();
                    
                    if ($matchingItem.length > 0) {
                        const itemAttributes = $matchingItem.data('attributes');
                        if (itemAttributes && itemAttributes[attributeKey]) {
                            selectedAttributes[attributeKey] = itemAttributes[attributeKey];
                            $matchingItem.addClass('active');
                            return;
                        }
                    }
                }
                
                // Fallback: Find the first active item
                const $firstActive = $section.find('[data-attributes]').filter('.active').first();
                if ($firstActive.length > 0) {
                    const itemAttributes = $firstActive.data('attributes');
                    if (itemAttributes && itemAttributes[attributeKey]) {
                        selectedAttributes[attributeKey] = itemAttributes[attributeKey];
                    }
                } else {
                    // Try to get from first available item
                    const $firstItem = $section.find('[data-attributes]').not('[data-unavailable="true"]').first();
                    if ($firstItem.length > 0) {
                        const itemAttributes = $firstItem.data('attributes');
                        if (itemAttributes && itemAttributes[attributeKey]) {
                            selectedAttributes[attributeKey] = itemAttributes[attributeKey];
                            $firstItem.addClass('active');
                            // Update selected value display
                            let displayName = $firstItem.attr('data-attribute-display-name') ||
                                              $firstItem.find('.wcvip-text-box-content').text().trim() ||
                                              $firstItem.find('.wcvip-button-text').text().trim() ||
                                              $firstItem.find('.wcvip-variation-name-label').text().trim() ||
                                              $firstItem.find('.wcvip-secondary-label').text().trim() ||
                                              $firstItem.attr('title') ||
                                              $firstItem.attr('data-variation-name') ||
                                              itemAttributes[attributeKey];
                            // Remove stock status text from display name
                            displayName = stripStockStatus(displayName);
                            $selectedValue.text(displayName);
                        }
                    }
                }
            });

            // Update global selection display with initial selections
            updateGlobalSelectionDisplay($container, selectedAttributes);

            // Handle clicks on attribute values (only within attribute sections)
            $container.on('click', '.wcvip-attribute-section [data-attributes]', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                const $item = $(this);
                const $section = $item.closest('.wcvip-attribute-section');
                
                // Only handle if within attribute sections container
                if ($section.length === 0 || !$section.closest('.wcvip-attribute-sections-container').length) {
                    return;
                }
                
                const attributeKey = $section.data('attribute-key');
                const itemAttributes = $item.data('attributes');
                
                if (!itemAttributes || !itemAttributes[attributeKey]) {
                    return;
                }

                const selectedValue = itemAttributes[attributeKey];
                
                // Skip if already selected
                if (selectedAttributes[attributeKey] === selectedValue) {
                    return;
                }

                // Skip if unavailable
                if ($item.data('unavailable') === true || $item.hasClass('wcvip-unavailable')) {
                    return;
                }

                // Update selected attribute
                selectedAttributes[attributeKey] = selectedValue;

                // Update UI
                updateAttributeSectionUI($section, selectedValue, $item);
                
                // Restore active states in other sections based on selectedAttributes
                restoreActiveStatesInOtherSections($container, $section, selectedAttributes);
                
                // Update global selection display
                updateGlobalSelectionDisplay($container, selectedAttributes);
                
                // Filter available options in other sections
                filterAvailableOptions($container, selectedAttributes, variationsData);
                
                // Restore active states again after filtering (in case filtering affected them)
                restoreActiveStatesInOtherSections($container, $section, selectedAttributes);
                
                // Try to find matching variation
                const matchingVariation = findMatchingVariation(selectedAttributes, variationsData);
                
                if (matchingVariation) {
                    // Set WooCommerce variation
                    setWooCommerceVariation(matchingVariation.attributes);
                    
                    // Trigger variation change
                    triggerVariationChange(matchingVariation.variation_id);
                } else {
                    // Partial selection - update form with current selections
                    setWooCommerceVariation(selectedAttributes);
                }
            });

            /**
             * Update attribute section UI
             */
            function updateAttributeSectionUI($section, selectedValue, $selectedItem) {
                const attributeKey = $section.data('attribute-key');
                const $selectedValueSpan = $section.find('.wcvip-attribute-selected-value');
                
                // Update selected value display - use data-attribute-display-name if available
                let displayName = $selectedItem.attr('data-attribute-display-name');
                if (!displayName) {
                    // Try different selectors for different styles
                    displayName = $selectedItem.find('.wcvip-text-box-content').text().trim() ||
                                  $selectedItem.find('.wcvip-button-text').text().trim() ||
                                  $selectedItem.find('.wcvip-variation-name-label').text().trim() ||
                                  $selectedItem.find('.wcvip-secondary-label').text().trim() ||
                                  $selectedItem.attr('title') ||
                                  $selectedItem.attr('data-variation-name') ||
                                  $selectedItem.find('img').attr('alt') ||
                                  selectedValue;
                }
                // Remove stock status text from display name
                displayName = stripStockStatus(displayName);
                $selectedValueSpan.text(displayName);

                // Update active states in this section
                $section.find('[data-attributes]').removeClass('active');
                $selectedItem.addClass('active');
            }

            /**
             * Restore active states in other sections based on selectedAttributes
             */
            function restoreActiveStatesInOtherSections($container, $currentSection, selectedAttributes) {
                const $allSections = $container.find('.wcvip-attribute-section');
                
                $allSections.each(function() {
                    const $otherSection = $(this);
                    
                    // Skip the current section (already updated)
                    if ($otherSection[0] === $currentSection[0]) {
                        return;
                    }
                    
                    const attributeKey = $otherSection.data('attribute-key');
                    const selectedValue = selectedAttributes[attributeKey];
                    
                    if (selectedValue) {
                        // Find the item that matches the selected value
                        const $items = $otherSection.find('[data-attributes]');
                        $items.each(function() {
                            const $item = $(this);
                            const itemAttributes = $item.data('attributes');
                            
                            if (itemAttributes && itemAttributes[attributeKey] === selectedValue) {
                                // Restore active state
                                $otherSection.find('[data-attributes]').removeClass('active');
                                $item.addClass('active');
                                return false; // break
                            }
                        });
                    }
                });
            }

            /**
             * Update global selection display with both selected attributes
             */
            function updateGlobalSelectionDisplay($container, selectedAttributes) {
                // Find the global selection display at the container level
                const $globalLabel = $container.find('> .wcvip-selected-variation-global').first();
                if ($globalLabel.length === 0) {
                    return;
                }
                
                // Build display text from all selected attributes
                const selectedParts = [];
                const $sections = $container.find('.wcvip-attribute-section');
                
                $sections.each(function() {
                    const $section = $(this);
                    const attributeKey = $section.data('attribute-key');
                    const selectedValue = selectedAttributes[attributeKey];
                    
                    if (selectedValue) {
                        // Get the display name from the selected value span
                        const $selectedValueSpan = $section.find('.wcvip-attribute-selected-value');
                        let displayName = $selectedValueSpan.text().trim();
                        
                        // Remove stock status text from display name
                        displayName = stripStockStatus(displayName);
                        
                        if (displayName && displayName !== 'Select') {
                            selectedParts.push(displayName);
                        }
                    }
                });
                
                // Update the global display
                if (selectedParts.length > 0) {
                    const $valueSpan = $globalLabel.find('.wcvip-selected-value');
                    $valueSpan.text(selectedParts.join(', '));
                    $globalLabel.show();
                } else {
                    $globalLabel.hide();
                }
            }

            /**
             * Filter available options based on selected attributes
             */
            function filterAvailableOptions($container, selectedAttributes, variationsData) {
                const $allSections = $container.find('.wcvip-attribute-section');
                
                $allSections.each(function() {
                    const $section = $(this);
                    const currentAttributeKey = $section.data('attribute-key');
                    const $items = $section.find('[data-attributes]');
                    
                    $items.each(function() {
                        const $item = $(this);
                        const itemAttributes = $item.data('attributes');
                        const itemValue = itemAttributes[currentAttributeKey];
                        
                        // Check if this value is available with current selections
                        const isAvailable = isValueAvailable(
                            currentAttributeKey, 
                            itemValue, 
                            selectedAttributes, 
                            variationsData
                        );
                        
                        if (isAvailable) {
                            $item.removeClass('wcvip-unavailable').removeAttr('data-unavailable');
                            $item.css('opacity', '1').css('pointer-events', 'auto');
                        } else {
                            $item.addClass('wcvip-unavailable').attr('data-unavailable', 'true');
                            $item.css('opacity', '0.5').css('pointer-events', 'none');
                        }
                    });
                });
            }

            /**
             * Check if an attribute value is available with current selections
             */
            function isValueAvailable(attributeKey, value, selectedAttributes, variationsData) {
                // Build test attributes object
                const testAttributes = $.extend({}, selectedAttributes);
                testAttributes[attributeKey] = value;
                
                // Check if any variation matches these attributes
                for (let i = 0; i < variationsData.length; i++) {
                    const variation = variationsData[i];
                    if (!variation.attributes) {
                        continue;
                    }
                    
                    let matches = true;
                    $.each(testAttributes, function(key, val) {
                        if (variation.attributes[key] !== val) {
                            matches = false;
                            return false; // break
                        }
                    });
                    
                    if (matches) {
                        // Check if variation is available
                        return variation.available !== false;
                    }
                }
                
                return false;
            }

            /**
             * Find matching variation from selected attributes
             */
            function findMatchingVariation(selectedAttributes, variationsData) {
                const attributeKeys = Object.keys(selectedAttributes);
                
                // Need all attributes selected to match a variation
                const $sections = $container.find('.wcvip-attribute-section');
                if (attributeKeys.length < $sections.length) {
                    return null; // Not all attributes selected yet
                }
                
                // Find matching variation
                for (let i = 0; i < variationsData.length; i++) {
                    const variation = variationsData[i];
                    if (!variation.attributes) {
                        continue;
                    }
                    
                    let matches = true;
                    $.each(selectedAttributes, function(key, value) {
                        if (variation.attributes[key] !== value) {
                            matches = false;
                            return false; // break
                        }
                    });
                    
                    if (matches) {
                        return variation;
                    }
                }
                
                return null;
            }

            // Initial filtering based on defaults
            if (Object.keys(selectedAttributes).length > 0) {
                filterAvailableOptions($container, selectedAttributes, variationsData);
                // Update global selection display on initial load
                updateGlobalSelectionDisplay($container, selectedAttributes);
            }
        }

            // Initialize lazy loading
            initLazyLoading();
        }); // End of $allSelectors.each()
    }
    
    // Multiple initialization strategies to ensure it runs
    // Strategy 1: DOM ready
    $(document).ready(function() {
        initWCVIPVariationSelector();
    });
    
    // Strategy 2: jQuery ready shorthand
    $(function() {
        setTimeout(function() {
            initWCVIPVariationSelector();
        }, 100);
    });
    
    // Strategy 3: Window load
    $(window).on('load', function() {
        setTimeout(function() {
            const $selectors = $('.wcvip-variation-selector');
            if ($selectors.length > 0) {
                const needsInit = $selectors.filter(function() {
                    return !$(this).data('wcvip-initialized');
                }).length > 0;
                if (needsInit) {
                    initWCVIPVariationSelector();
                }
            }
        }, 500);
    });
    
    // Strategy 4: WooCommerce variations loaded
    $(document).on('woocommerce_variations_loaded', function() {
        initWCVIPVariationSelector();
    });
    
    // Strategy 5: Immediate check (if DOM already ready)
    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        setTimeout(function() {
            initWCVIPVariationSelector();
        }, 50);
    }

})(jQuery);

