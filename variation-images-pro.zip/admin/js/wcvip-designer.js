/**
 * Visual Designer JavaScript
 */

(function($) {
    'use strict';

    function initializeDesigner() {
        const $designer = $('.wcvip-visual-designer:not(.wcvip-designer-initialized)');
        
        if ($designer.length === 0) {
            return;
        }
        
        // Mark as initialized to prevent double initialization
        $designer.addClass('wcvip-designer-initialized');

        const productId = $designer.data('product-id');
        let variations = [];
        let currentVariationId = null;
        let uploadedImages = [];
        let lastSelectedMainStyle = null;

        // Initialize
        init();
        
        /**
         * Show notification
         */
        function showNotification(message, type) {
            type = type || 'warning';
            
            const icons = {
                success: '✓',
                error: '✕',
                warning: '⚠',
                info: 'ℹ'
            };
            
            const notification = $('<div>')
                .addClass('wcvip-notification wcvip-notice-' + type)
                .html(`
                    <div class="wcvip-notification-content">
                        <span class="wcvip-notification-icon">${icons[type] || icons.warning}</span>
                        <span class="wcvip-notification-message">${message}</span>
                    </div>
                    <button type="button" class="wcvip-notification-close" aria-label="Dismiss">×</button>
                `);
            
            const container = $('#wcvip-notification-container');
            if (container.length === 0) {
                $('body').append('<div id="wcvip-notification-container" class="wcvip-notification-container"></div>');
            }
            
            // Remove existing notifications to prevent duplicates
            $('#wcvip-notification-container .wcvip-notification').remove();
            
            $('#wcvip-notification-container').append(notification);
            
            // Auto-dismiss after 5 seconds
            const autoDismiss = setTimeout(function() {
                dismissNotification(notification);
            }, 5000);
            
            // Manual dismiss
            notification.find('.wcvip-notification-close').on('click', function() {
                clearTimeout(autoDismiss);
                dismissNotification(notification);
            });
        }
        
        /**
         * Dismiss notification
         */
        function dismissNotification($notification) {
            $notification.addClass('hiding');
            setTimeout(function() {
                $notification.remove();
            }, 300);
        }

        /**
         * Initialize upgrade banner dismiss functionality
         */
        function initUpgradeBanner() {
            const $banner = $('#wcvip-upgrade-banner');
            if ($banner.length === 0) {
                return;
            }

            // Check if banner was previously dismissed
            const bannerDismissed = localStorage.getItem('wcvip_upgrade_banner_dismissed');
            if (bannerDismissed === 'true') {
                $banner.addClass('hidden');
                return;
            }

            // Handle dismiss button click
            $banner.on('click', '.wcvip-upgrade-banner-dismiss', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                // Hide banner
                $banner.addClass('hidden');
                
                // Store dismissal in localStorage
                localStorage.setItem('wcvip_upgrade_banner_dismissed', 'true');
            });
        }

        function init() {
            // Initialize last selected main style from currently active style card
            const $activeStyle = $('.wcvip-style-card.active, .wcvip-style-option.active');
            if ($activeStyle.length > 0) {
                lastSelectedMainStyle = $activeStyle.data('style');
            }
            
            loadVariations();
            setupPreview();
            setupActions();
            setupStyleSelection();
        }

        /**
         * Load variations for designer
         */
        function loadVariations() {
            $.ajax({
                url: wcvipDesigner.ajaxurl,
                type: 'POST',
                data: {
                    action: 'wcvip_get_product_variations_designer',
                    nonce: wcvipDesigner.nonce,
                    product_id: productId
                },
                success: function(response) {
                    if (response.success) {
                        variations = response.data;
                        renderVariations();
                    }
                },
                error: function() {
                    console.error('Failed to load variations');
                }
            });
        }

        /**
         * Render variations list
         */
        function renderVariations() {
            const $container = $('#wcvip-variations-list');
            $container.empty();

            variations.forEach(function(variation) {
                const imageCount = variation.image_count || 0;
                const previewImage = variation.images && variation.images[0] && variation.images[0].thumbnail ? variation.images[0].thumbnail : '';

                const $item = $(
                    '<div class="wcvip-variation-item" data-variation-id="' + variation.id + '">' +
                    '<div class="wcvip-variation-item-preview">' +
                    (previewImage ? '<img src="' + previewImage + '" alt="">' : '<div class="wcvip-no-image-preview">No image</div>') +
                    '</div>' +
                    '<div class="wcvip-variation-item-content">' +
                    '<div class="wcvip-variation-item-header">' +
                    '<span class="wcvip-variation-name" title="' + $('<div>').text(variation.name).html() + '">' + variation.name + '</span>' +
                    '</div>' +
                    '<div class="wcvip-variation-item-footer">' +
                    (typeof wcvipDesigner !== 'undefined' && wcvipDesigner.isPro ?
                        '<span class="wcvip-variation-image-count">' + imageCount + '</span>' +
                        '<button type="button" class="button button-small wcvip-edit-variation-images" data-variation-id="' + variation.id + '">Manage</button>'
                        :
                        '<button type="button" class="button button-small wcvip-upgrade-required" disabled>Upgrade</button>'
                    ) +
                    '</div>' +
                    '</div>' +
                    '</div>'
                );

                $container.append($item);
            });
        }


        /**
         * Open WordPress media uploader
         */
        function openMediaUploader() {
            const mediaUploader = wp.media({
                title: 'Select Images',
                button: {
                    text: 'Add to Variation'
                },
                multiple: true,
                library: {
                    type: 'image'
                }
            });

            mediaUploader.on('select', function() {
                const selection = mediaUploader.state().get('selection');
                const images = [];

                selection.forEach(function(attachment) {
                    const att = attachment.toJSON();
                    images.push({
                        id: att.id,
                        url: att.url,
                        thumbnail: att.sizes && att.sizes.thumbnail ? att.sizes.thumbnail.url : att.url,
                        alt: att.alt || ''
                    });
                });

                // Assign to selected variation or show assignment dialog
                assignImagesToVariation(images);
            });

            mediaUploader.open();
        }

        /**
         * Assign images to variation
         */
        function assignImagesToVariation(images, variationId = null) {
            if (!variationId) {
                // Show dialog to select variation
                showVariationSelector(images);
                return;
            }

            // Save images to variation
            saveVariationImages(variationId, images);
        }

        /**
         * Show variation selector dialog
         */
        function showVariationSelector(images) {
            // Create modal for variation selection
            const modal = $(
                '<div class="wcvip-modal-overlay">' +
                '<div class="wcvip-modal">' +
                '<div class="wcvip-modal-header">' +
                '<h2>Select Variation</h2>' +
                '<span class="wcvip-close">&times;</span>' +
                '</div>' +
                '<div class="wcvip-modal-body">' +
                '<p>Select a variation to assign these images to:</p>' +
                '<div class="wcvip-variation-selector-list"></div>' +
                '</div>' +
                '</div>' +
                '</div>'
            );

            const $list = modal.find('.wcvip-variation-selector-list');
            
            variations.forEach(function(variation) {
                $list.append(
                    '<div class="wcvip-variation-selector-item" data-variation-id="' + variation.id + '">' +
                    '<strong>' + variation.name + '</strong>' +
                    '</div>'
                );
            });

            $('body').append(modal);

            modal.find('.wcvip-variation-selector-item').on('click', function() {
                const varId = $(this).data('variation-id');
                assignImagesToVariation(images, varId);
                modal.remove();
            });

            modal.find('.wcvip-close').on('click', function() {
                modal.remove();
            });
        }

        /**
         * Save variation images
         */
        function saveVariationImages(variationId, images) {
            $.ajax({
                url: wcvipDesigner.ajaxurl,
                type: 'POST',
                data: {
                    action: 'wcvip_save_images',
                    nonce: wcvipDesigner.nonce_images || wcvipDesigner.nonce,
                    variation_id: variationId,
                    images: JSON.stringify(images)
                },
                success: function(response) {
                    if (response.success) {
                        // Reload variations
                        loadVariations();
                        // Update preview
                        updatePreview(variationId);
                    }
                }
            });
        }

        /**
         * Setup preview
         */
        function setupPreview() {
            $(document).on('click', '.wcvip-variation-item', function() {
                const variationId = $(this).data('variation-id');
                updatePreview(variationId);
            });

            // Gallery thumbnail click to change main image
            $(document).on('click', '.wcvip-preview-thumbnail', function() {
                const $thumbnail = $(this);
                const $thumbnailImg = $thumbnail.find('img');
                const $mainImage = $('.wcvip-preview-featured-image');
                
                if ($thumbnailImg.length && $mainImage.length) {
                    const newSrc = $thumbnailImg.attr('src');
                    const newSrcset = $thumbnailImg.attr('srcset');
                    const newSizes = $thumbnailImg.attr('sizes');
                    
                    $mainImage.attr('src', newSrc);
                    if (newSrcset) {
                        $mainImage.attr('srcset', newSrcset);
                    }
                    if (newSizes) {
                        $mainImage.attr('sizes', newSizes);
                    }
                    
                    // Update active thumbnail
                    $('.wcvip-preview-thumbnail').removeClass('active');
                    $thumbnail.addClass('active');
                }
            });
        }

        /**
         * Update preview
         */
        function updatePreview(variationId) {
            $.ajax({
                url: wcvipDesigner.ajaxurl,
                type: 'POST',
                data: {
                    action: 'wcvip_preview_variation',
                    nonce: wcvipDesigner.nonce,
                    variation_id: variationId
                },
                success: function(response) {
                    if (response.success) {
                        renderPreview(response.data);
                    }
                }
            });
        }

        /**
         * Render preview
         */
        function renderPreview(images) {
            const $preview = $('.wcvip-preview-images');
            $preview.empty();

            if (images.length === 0) {
                $preview.html('<p>No images to preview</p>');
                return;
            }

            images.forEach(function(image) {
                $preview.append(
                    '<img src="' + (image.thumbnail || image.url) + '" alt="' + (image.alt || '') + '">'
                );
            });
        }

        /**
         * Show confirmation modal
         */
        function showConfirmModal(title, message, onConfirm, onCancel) {
            const overlay = $('<div class="wcvip-modal-overlay"></div>');
            const modal = $('<div class="wcvip-modal"></div>');
            
            modal.html(`
                <div class="wcvip-modal-header">
                    <h2>${title}</h2>
                </div>
                <div class="wcvip-modal-body">
                    <p>${message}</p>
                </div>
                <div class="wcvip-modal-footer">
                    <button type="button" class="button wcvip-modal-cancel">Cancel</button>
                    <button type="button" class="button button-primary wcvip-modal-confirm">Confirm</button>
                </div>
            `);
            
            overlay.append(modal);
            $('body').append(overlay);
            
            // Handle confirm
            modal.find('.wcvip-modal-confirm').on('click', function() {
                overlay.remove();
                if (typeof onConfirm === 'function') {
                    onConfirm();
                }
            });
            
            // Handle cancel
            modal.find('.wcvip-modal-cancel').on('click', function() {
                overlay.remove();
                if (typeof onCancel === 'function') {
                    onCancel();
                }
            });
            
            // Close on overlay click
            overlay.on('click', function(e) {
                if ($(e.target).hasClass('wcvip-modal-overlay')) {
                    overlay.remove();
                    if (typeof onCancel === 'function') {
                        onCancel();
                    }
                }
            });
        }

        /**
         * Setup action buttons
         */
        function setupActions() {
            $('#wcvip-save-designer').on('click', function() {
                saveDesign();
            });

            $('#wcvip-reset-designer').on('click', function() {
                // Hide View Product button on reset (if visible)
                $('#wcvip-view-product').fadeOut(200);
                
                showConfirmModal(
                    'Reset Designer',
                    'Reset designer? This will clear unsaved changes.',
                    function() {
                        showNotification('Resetting designer...', 'info');
                        setTimeout(function() {
                            location.reload();
                        }, 500);
                    },
                    function() {
                        // User cancelled
                    }
                );
            });

            // Handle "View on Frontend" button - reuse same tab instead of opening multiple tabs
            $(document).on('click', '.wcvip-view-frontend-header', function(e) {
                e.preventDefault();
                const url = $(this).attr('href');
                if (url) {
                    // Use a specific window name to reuse the same tab
                    // If a window with this name already exists, it will be reused
                    const previewWindow = window.open(url, 'wcvip-frontend-preview');
                    // Focus the window if it already existed
                    if (previewWindow) {
                        previewWindow.focus();
                    }
                }
            });

            // Handle card preview button - reuse same tab instead of opening multiple tabs
            $(document).on('click', '.wcvip-card-preview-btn', function(e) {
                e.preventDefault();
                e.stopPropagation(); // Prevent card selection
                const url = $(this).attr('href');
                if (url) {
                    // Use a specific window name to reuse the same tab
                    const previewWindow = window.open(url, 'wcvip-frontend-preview');
                    // Focus the window if it already existed
                    if (previewWindow) {
                        previewWindow.focus();
                    }
                }
            });

            // Handle card save button - call the same save function as bottom save button
            $(document).on('click', '.wcvip-card-save-btn', function(e) {
                e.preventDefault();
                e.stopPropagation(); // Prevent card selection
                saveDesign();
            });

            // Handle attribute preview button - update URL with attribute styles
            $(document).on('click', '.wcvip-attribute-preview-btn', function(e) {
                e.preventDefault();
                updateAttributePreviewButton($(this));
            });

            // Update attribute preview button URL when attribute styles change
            function updateAttributePreviewButton($button) {
                const baseUrl = $button.data('base-url');
                const productId = $button.data('product-id');
                const nonce = $button.data('preview-nonce');
                const defaultStyle = $button.data('default-style') || '';
                
                if (!baseUrl || !nonce) {
                    return;
                }
                
                // Get the default display style (from active style card)
                const $activeStyle = $('.wcvip-style-card.active, .wcvip-style-option.active');
                const displayStyle = $activeStyle.length > 0 ? $activeStyle.data('style') : defaultStyle;
                
                // Collect all attribute styles
                const attributeStyles = {};
                $('#wcvip-attribute-styles-section .wcvip-attribute-style-select').each(function() {
                    const $select = $(this);
                    const attrKey = $select.data('attribute-key');
                    const style = $select.val();
                    if (attrKey && style) {
                        attributeStyles[attrKey] = style;
                    }
                });
                
                // Build preview URL
                let previewUrl = baseUrl + (baseUrl.indexOf('?') !== -1 ? '&' : '?') +
                    'wcvip_preview=true' +
                    '&wcvip_style=' + encodeURIComponent(displayStyle) +
                    '&wcvip_nonce=' + encodeURIComponent(nonce);
                
                // Add attribute styles as query parameters
                if (Object.keys(attributeStyles).length > 0) {
                    previewUrl += '&wcvip_attr_styles=' + encodeURIComponent(JSON.stringify(attributeStyles));
                }
                
                // Open preview in same tab (reuse if exists)
                const previewWindow = window.open(previewUrl, 'wcvip-frontend-preview');
                if (previewWindow) {
                    previewWindow.focus();
                }
            }


            // Remove existing handler to prevent duplicates
            $(document).off('click', '.wcvip-edit-variation-images');
            
            $(document).on('click', '.wcvip-edit-variation-images', function(e) {
                e.stopPropagation();
                e.preventDefault();
                
                // Safety check: Only allow for Pro users
                const isPro = typeof wcvipDesigner !== 'undefined' && Boolean(wcvipDesigner.isPro);
                if (!isPro) {
                    showNotification('This feature is only available in the Pro version. Please upgrade to manage variation images.', 'warning');
                    return;
                }
                
                // Prevent opening multiple modals
                if ($('#wcvip-image-modal').length > 0) {
                    return;
                }
                
                const variationId = $(this).data('variation-id');
                // Open image manager for this variation
                openImageManager(variationId);
            });
        }

        /**
         * Save design
         */
        function saveDesign() {
            const $saveButton = $('#wcvip-save-designer');
            
            // Prevent multiple clicks - if already saving, return early
            if ($saveButton.prop('disabled')) {
                return;
            }
            
            // Get original text from data attribute or use fallback
            let originalText = $saveButton.data('original-text');
            if (!originalText) {
                // Store the current text as original (should be "Save Design")
                originalText = $saveButton.text().trim();
                $saveButton.data('original-text', originalText);
            }
            
            // Disable button and show loading state
            $saveButton.prop('disabled', true).text('Saving...');
            
            const layout = {
                variations: variations.map(v => ({
                    id: v.id,
                    position: null // Will be set based on canvas position
                }))
            };

            // Collect attribute styles (include all, even empty ones to allow clearing)
            const attributeStyles = {};
            $('#wcvip-attribute-styles-section .wcvip-attribute-style-select').each(function() {
                const $select = $(this);
                const attrKey = $select.data('attribute-key');
                const style = $select.val();
                if (attrKey) {
                    attributeStyles[attrKey] = style || ''; // Include empty values to allow clearing
                }
            });
            
            $.ajax({
                url: wcvipDesigner.ajaxurl,
                type: 'POST',
                data: {
                    action: 'wcvip_save_designer_layout',
                    nonce: wcvipDesigner.nonce,
                    product_id: productId,
                    layout: JSON.stringify(layout),
                    attribute_styles: attributeStyles
                },
                success: function(response) {
                    if (response.success) {
                        showNotification('Design saved successfully!', 'success');
                        
                        // Restore button state - use stored original text or fallback
                        const restoreText = $saveButton.data('original-text') || 'Save Design';
                        $saveButton.prop('disabled', false).text(restoreText);
                        
                        // Show View Product button after successful save
                        const $viewProductButton = $('#wcvip-view-product');
                        if ($viewProductButton.length > 0) {
                            $viewProductButton.fadeIn(300);
                        }
                    } else {
                        const errorMessage = response.data && response.data.message ? response.data.message : 'Failed to save design.';
                        showNotification(errorMessage, 'error');
                        
                        // Restore button state
                        const restoreText = $saveButton.data('original-text') || 'Save Design';
                        $saveButton.prop('disabled', false).text(restoreText);
                    }
                },
                error: function(xhr, status, error) {
                    showNotification('Error saving design. Please try again.', 'error');
                    
                    // Restore button state
                    const restoreText = $saveButton.data('original-text') || 'Save Design';
                    $saveButton.prop('disabled', false).text(restoreText);
                }
            });
        }

        /**
         * Open image manager modal
         */
        function openImageManager(variationId) {
            currentVariationId = variationId;
            
            // Get variation name
            const variation = variations.find(v => v.id === variationId);
            const variationName = variation ? variation.name || 'Variation ' + variationId : 'Variation';
            
            // Load existing images
            loadVariationImages(variationId, function(images) {
                uploadedImages = images || [];
                showImageModal(variationId, variationName);
            });
        }
        
        /**
         * Load existing variation images via AJAX
         */
        function loadVariationImages(variationId, callback) {
            $.ajax({
                url: wcvipDesigner.ajaxurl,
                type: 'POST',
                data: {
                    action: 'wcvip_get_images',
                    nonce: wcvipDesigner.nonce_images || wcvipDesigner.nonce,
                    variation_id: variationId
                },
                success: function(response) {
                    if (response.success && response.data) {
                        callback(response.data);
                    } else {
                        callback([]);
                    }
                },
                error: function() {
                    callback([]);
                }
            });
        }
        
        /**
         * Show image management modal
         */
        function showImageModal(variationId, variationName) {
            // Close existing modal if any
            $('#wcvip-image-modal').remove();
            
            const modalHTML = `
                <div class="wcvip-modal-overlay" id="wcvip-image-modal">
                    <div class="wcvip-modal">
                        <div class="wcvip-modal-header">
                            <h2>Manage Images: ${variationName}</h2>
                            <span class="wcvip-close">&times;</span>
                        </div>
                        <div class="wcvip-modal-body">
                            <div class="wcvip-image-uploader" id="wcvip-upload-area">
                                <p><strong>📤 Click to Upload Images</strong></p>
                                <p>or drag and drop images here</p>
                                <p style="font-size: 12px; color: #666;">Free version: 1 image per variation</p>
                            </div>
                            
                            <div id="wcvip-gallery-container">
                                <h3>Current Images</h3>
                                <div class="wcvip-gallery-grid" id="wcvip-gallery">
                                    ${renderImageGallery()}
                                </div>
                            </div>
                        </div>
                        <div class="wcvip-modal-footer">
                            <button class="button button-secondary" id="wcvip-modal-cancel">Cancel</button>
                            <button class="button button-primary" id="wcvip-modal-save">Save Changes</button>
                        </div>
                    </div>
                </div>
            `;
            
            $('body').append(modalHTML);
            setupModalListeners();
        }
        
        /**
         * Render image gallery
         */
        function renderImageGallery() {
            if (uploadedImages.length === 0) {
                return '<p style="grid-column: 1/-1; text-align: center; color: #666;">No images uploaded yet.</p>';
            }
            
            let html = '';
            uploadedImages.forEach((image, index) => {
                const imageUrl = image.thumbnail || image.url || image.src || '';
                html += `
                    <div class="wcvip-gallery-item" data-index="${index}">
                        <img src="${imageUrl}" alt="">
                        <div class="wcvip-gallery-overlay">
                            <button class="wcvip-icon-btn wcvip-set-primary" data-index="${index}" title="Set as primary">⭐</button>
                            <button class="wcvip-icon-btn wcvip-icon-btn-danger wcvip-remove-image" data-index="${index}" title="Remove">🗑️</button>
                        </div>
                        ${image.is_primary ? '<span class="wcvip-primary-badge">Primary</span>' : ''}
                    </div>
                `;
            });
            return html;
        }
        
        /**
         * Setup modal event listeners
         */
        function setupModalListeners() {
            // Remove existing handlers to prevent duplicates
            $('.wcvip-close, #wcvip-modal-cancel').off('click');
            $('#wcvip-image-modal').off('click');
            $('#wcvip-upload-area').off('click');
            $('#wcvip-modal-save').off('click');
            $(document).off('click', '.wcvip-remove-image');
            $(document).off('click', '.wcvip-set-primary');
            
            // Close modal
            $('.wcvip-close, #wcvip-modal-cancel').on('click', function() {
                closeImageModal();
            });
            
            // Close on overlay click
            $('#wcvip-image-modal').on('click', function(e) {
                if (e.target === this) {
                    closeImageModal();
                }
            });
            
            // Upload images - click
            $('#wcvip-upload-area').on('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                if (typeof wp !== 'undefined' && typeof wp.media !== 'undefined') {
                    openMediaUploader();
                } else {
                    showNotification('WordPress media uploader is not available. Please refresh the page.', 'error');
                }
            });
            
            // Drag and drop upload
            const $uploadArea = $('#wcvip-upload-area');
            
            $uploadArea.on('dragover', function(e) {
                e.preventDefault();
                e.stopPropagation();
                $(this).addClass('wcvip-drag-over');
            });
            
            $uploadArea.on('dragleave', function(e) {
                e.preventDefault();
                e.stopPropagation();
                $(this).removeClass('wcvip-drag-over');
            });
            
            $uploadArea.on('drop', function(e) {
                e.preventDefault();
                e.stopPropagation();
                $(this).removeClass('wcvip-drag-over');
                
                const files = e.originalEvent.dataTransfer.files;
                if (files.length === 0) {
                    return;
                }
                
                // Check limit for free version
                const isPro = typeof wcvipDesigner !== 'undefined' && Boolean(wcvipDesigner.isPro);
                if (!isPro && uploadedImages.length >= 1) {
                    showNotification('Free version is limited to 1 image per variation. Please remove existing images first.', 'warning');
                    return;
                }
                
                // Handle file uploads
                handleFileUpload(files);
            });
            
            // Save images
            $('#wcvip-modal-save').on('click', function() {
                saveVariationImages();
            });
            
            // Remove image
            $(document).on('click', '.wcvip-remove-image', function() {
                const index = $(this).data('index');
                removeImage(index);
            });
            
            // Set primary image
            $(document).on('click', '.wcvip-set-primary', function() {
                const index = $(this).data('index');
                setPrimaryImage(index);
            });
        }
        
        /**
         * Close image modal
         */
        function closeImageModal() {
            $('#wcvip-image-modal').remove();
            currentVariationId = null;
            uploadedImages = [];
        }
        
        /**
         * Open WordPress media uploader
         */
        function openMediaUploader() {
            // Check limit for free version
            const isPro = typeof wcvipDesigner !== 'undefined' && Boolean(wcvipDesigner.isPro);
            if (!isPro && uploadedImages.length >= 1) {
                showNotification('Free version is limited to 1 image per variation. Upgrade to Pro for unlimited images!', 'warning');
                return;
            }
            
            // Create media uploader
            const mediaUploader = wp.media({
                title: 'Select Images',
                button: {
                    text: 'Add to Variation'
                },
                multiple: Boolean(isPro),
                library: {
                    type: 'image'
                }
            });
            
            // When images are selected
            mediaUploader.on('select', function() {
                const selection = mediaUploader.state().get('selection');
                const currentCount = uploadedImages.length;
                const isProCheck = typeof wcvipDesigner !== 'undefined' && Boolean(wcvipDesigner.isPro);
                
                selection.forEach(function(attachment) {
                    attachment = attachment.toJSON();
                    
                    // Check limit for free version
                    if (!isProCheck) {
                        if (currentCount >= 1) {
                            showNotification('Free version is limited to 1 image per variation. Please remove existing images first.', 'warning');
                            return;
                        }
                    }
                    
                    // Add image
                    uploadedImages.push({
                        id: attachment.id,
                        url: attachment.url,
                        thumbnail: attachment.sizes && attachment.sizes.thumbnail ? attachment.sizes.thumbnail.url : attachment.url,
                        alt: attachment.alt || '',
                        is_primary: uploadedImages.length === 0 // First image is primary
                    });
                });
                
                // Re-render gallery
                $('#wcvip-gallery').html(renderImageGallery());
            });
            
            // Open uploader
            mediaUploader.open();
        }
        
        /**
         * Handle file upload via drag and drop
         */
        function handleFileUpload(files) {
            const isPro = typeof wcvipDesigner !== 'undefined' && Boolean(wcvipDesigner.isPro);
            const maxFiles = isPro ? files.length : 1;
            const filesToUpload = Array.from(files).slice(0, maxFiles);
            
            // Filter only image files
            const imageFiles = filesToUpload.filter(file => file.type.startsWith('image/'));
            
            if (imageFiles.length === 0) {
                showNotification('Please drop image files only.', 'warning');
                return;
            }
            
            // Show loading state
            const $uploadArea = $('#wcvip-upload-area');
            const originalHTML = $uploadArea.html();
            $uploadArea.html('<p>Uploading...</p>');
            
            // Upload each file
            let uploadCount = 0;
            let successCount = 0;
            const totalFiles = imageFiles.length;
            let completed = false; // Prevent duplicate notifications
            
            // Get WordPress media uploader nonce
            let uploadNonce = '';
            if (typeof wp !== 'undefined' && wp.media && wp.media.view && wp.media.view.settings && wp.media.view.settings.nonce) {
                uploadNonce = wp.media.view.settings.nonce;
            } else {
                // Fallback: try to get from localized data
                uploadNonce = wcvipDesigner.nonce_images || wcvipDesigner.nonce || '';
            }
            
            if (!uploadNonce) {
                $uploadArea.html(originalHTML);
                showNotification('Upload nonce not available. Please refresh the page.', 'error');
                return;
            }
            
            imageFiles.forEach(function(file) {
                // Use custom AJAX upload endpoint
                const formData = new FormData();
                formData.append('action', 'wcvip_upload_image');
                formData.append('nonce', wcvipDesigner.nonce_images || wcvipDesigner.nonce);
                formData.append('file', file);
                
                $.ajax({
                    url: wcvipDesigner.ajaxurl,
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        uploadCount++;
                        if (response.success && response.data) {
                            const att = response.data;
                            uploadedImages.push({
                                id: att.id,
                                url: att.url || '',
                                thumbnail: att.thumbnail || att.url || '',
                                alt: att.alt || '',
                                is_primary: uploadedImages.length === 0
                            });
                            successCount++;
                        } else {
                            console.error('Upload error:', response.data?.message || 'Unknown error');
                        }
                        checkUploadComplete();
                    },
                    error: function(xhr, status, error) {
                        uploadCount++;
                        console.error('Upload error:', xhr.responseJSON?.data?.message || xhr.responseText || error);
                        checkUploadComplete();
                    }
                });
            });
            
            function checkUploadComplete() {
                // Only show notification once
                if (completed) {
                    return;
                }
                
                if (uploadCount === totalFiles) {
                    completed = true;
                    $uploadArea.html(originalHTML);
                    $('#wcvip-gallery').html(renderImageGallery());
                    setupModalListeners(); // Re-attach listeners for new gallery items
                    
                    if (successCount > 0 && uploadedImages.length > 0) {
                        showNotification('Images uploaded successfully!', 'success');
                    } else {
                        showNotification('Error uploading images. Please check console for details.', 'error');
                    }
                }
            }
        }
        
        /**
         * Remove image from gallery
         */
        function removeImage(index) {
            if (confirm('Are you sure you want to remove this image?')) {
                uploadedImages.splice(index, 1);
                $('#wcvip-gallery').html(renderImageGallery());
            }
        }
        
        /**
         * Set primary image
         */
        function setPrimaryImage(index) {
            uploadedImages.forEach(function(img, i) {
                img.is_primary = (i === index);
            });
            $('#wcvip-gallery').html(renderImageGallery());
        }
        
        /**
         * Save variation images via AJAX
         */
        function saveVariationImages() {
            if (!currentVariationId) {
                return;
            }
            
            $.ajax({
                url: wcvipDesigner.ajaxurl,
                type: 'POST',
                data: {
                    action: 'wcvip_save_images',
                    nonce: wcvipDesigner.nonce_images || wcvipDesigner.nonce,
                    variation_id: currentVariationId,
                    images: JSON.stringify(uploadedImages)
                },
                success: function(response) {
                    if (response.success) {
                        // Refresh variations list
                        loadVariations();
                        closeImageModal();
                    } else {
                        alert('Error saving images: ' + (response.data || 'Unknown error'));
                    }
                },
                error: function() {
                    alert('Error saving images. Please try again.');
                }
            });
        }

        /**
         * Setup style selection
         */
        function setupStyleSelection() {
            // Handle both old style-option and new style-card elements
            $(document).on('click', '.wcvip-style-option, .wcvip-style-card', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                const $option = $(this);
                const style = $option.data('style');
                
                // Skip if disabled (Pro features for free users)
                if ($option.hasClass('wcvip-pro-disabled') || $option.attr('aria-disabled') === 'true') {
                    if ($option.find('.wcvip-pro-badge').length > 0 && !wcvipDesigner.isPro) {
                        showUpgradePrompt('This display style is available in the Pro version. Upgrade to unlock circular thumbnails and all advanced layouts!');
                    }
                    return;
                }
                
                // Check if it's a Pro feature and user is on free version
                if ($option.find('.wcvip-pro-badge').length > 0 && !wcvipDesigner.isPro) {
                    showUpgradePrompt('This display style is available in the Pro version. Upgrade to unlock circular thumbnails and all advanced layouts!');
                    return;
                }

                // Store as last selected main style first (before clearing attribute styles)
                lastSelectedMainStyle = style;

                // Check if any per-attribute styles are set, and clear them if so
                const $attributeSection = $('#wcvip-attribute-styles-section');
                if ($attributeSection.length > 0) {
                    $attributeSection.find('.wcvip-attribute-style-select').each(function() {
                        if ($(this).val() && $(this).val() !== '') {
                            // Clear this attribute style
                            $(this).val('').trigger('change');
                        }
                    });
                }

                // Remove active class from all options
                $('.wcvip-style-option, .wcvip-style-card').removeClass('active');
                
                // Add active class to selected option
                $option.addClass('active');
                
                // Save style selection - pass the clicked element to find correct designer
                saveStyleSelection(style, $option);
                
                // Update preview
                updateStylePreview(style);
                
                // Update "View on Frontend" button URL with selected style
                updateViewFrontendButton(style);
            });
            
            // Handle per-attribute style selection changes
            $(document).on('change', '.wcvip-attribute-style-select', function() {
                // Check if any per-attribute styles are selected
                const $attributeSection = $('#wcvip-attribute-styles-section');
                let hasAnyAttributeStyle = false;
                
                if ($attributeSection.length > 0) {
                    $attributeSection.find('.wcvip-attribute-style-select').each(function() {
                        const val = $(this).val();
                        if (val && val !== '') {
                            hasAnyAttributeStyle = true;
                            return false; // break loop
                        }
                    });
                }
                
                if (hasAnyAttributeStyle) {
                    // Store current active main style before deselecting
                    const $activeStyle = $('.wcvip-style-card.active, .wcvip-style-option.active');
                    if ($activeStyle.length > 0 && !lastSelectedMainStyle) {
                        lastSelectedMainStyle = $activeStyle.data('style');
                    }
                    // Deselect all main style cards
                    $('.wcvip-style-option, .wcvip-style-card').removeClass('active');
                } else {
                    // All per-attribute styles are cleared, restore last selected main style
                    if (lastSelectedMainStyle) {
                        $('.wcvip-style-option[data-style="' + lastSelectedMainStyle + '"], .wcvip-style-card[data-style="' + lastSelectedMainStyle + '"]').addClass('active');
                    }
                }
                
                refreshAttributeStylesPreview();
            });
        }
        
        /**
         * Update "View on Frontend" button URL with selected style
         */
        function updateViewFrontendButton(style) {
            const $button = $('.wcvip-view-frontend-header');
            if ($button.length === 0) {
                return;
            }
            
            const baseUrl = $button.data('base-url');
            const productId = $button.data('product-id');
            const nonce = $button.data('preview-nonce');
            
            if (!baseUrl || !nonce) {
                return;
            }
            
            // Build preview URL with selected style
            const previewUrl = baseUrl + 
                (baseUrl.indexOf('?') !== -1 ? '&' : '?') +
                'wcvip_preview=true' +
                '&wcvip_style=' + encodeURIComponent(style) +
                '&wcvip_nonce=' + encodeURIComponent(nonce);
            
            // Update button href
            $button.attr('href', previewUrl);
            $button.data('current-style', style);
        }

        /**
         * Save style selection
         * @param {string} style - The style to save
         * @param {jQuery} $clickedElement - The clicked style card/option element
         */
        function saveStyleSelection(style, $clickedElement) {
            // Find the designer element by traversing up from the clicked element
            // This ensures we always get the correct, current designer element
            const $currentDesigner = $clickedElement.closest('.wcvip-visual-designer');
            const currentProductId = $currentDesigner.data('product-id');
            
            if (!$currentDesigner.length) {
                console.error('Designer element not found. Cannot save style.');
                console.error('Clicked element:', $clickedElement);
                return;
            }
            
            if (!currentProductId) {
                console.error('Product ID is missing. Cannot save style.');
                console.error('Designer element:', $currentDesigner);
                console.error('Data attribute:', $currentDesigner.data('product-id'));
                return;
            }
            
            if (!style) {
                console.error('Style is missing. Cannot save.');
                return;
            }
            
            const ajaxData = {
                    action: 'wcvip_save_display_style',
                nonce: wcvipDesigner.nonce_images || wcvipDesigner.nonce,
                    style: style,
                product_id: currentProductId
            };
            
            $.ajax({
                url: wcvipDesigner.ajaxurl,
                type: 'POST',
                data: ajaxData,
                success: function(response) {
                    if (response.success) {
                        // Update active state in UI
                        updateActiveStyleInUI(style);
                    } else {
                        console.error('❌ Failed to save style:', response.data?.message || 'Unknown error');
                        console.error('Full response:', response);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('❌ AJAX error saving style:', error);
                    console.error('Status:', status);
                    console.error('Response Text:', xhr.responseText);
                    console.error('Status Code:', xhr.status);
                    console.error('Full XHR object:', xhr);
                }
            });
        }
        
        /**
         * Update active style in UI after save
         */
        function updateActiveStyleInUI(style) {
            // Remove active class from all style options
            $('.wcvip-style-option, .wcvip-style-card').removeClass('active');
            
            // Add active class to selected style
            $('.wcvip-style-option[data-style="' + style + '"], .wcvip-style-card[data-style="' + style + '"]').addClass('active');
        }

        /**
         * Update style preview
         */
        function updateStylePreview(style) {
            // Update preview area to show selected style
            const $preview = $('.wcvip-preview-variations');
            $preview.attr('data-style', style);
            
            // Add visual indication of style
            $preview.removeClass('wcvip-style-square wcvip-style-circular wcvip-style-dropdown wcvip-style-buttons wcvip-style-grid wcvip-style-vertical wcvip-style-rectangular wcvip-style-strip wcvip-style-radio wcvip-style-custom');
            $preview.addClass('wcvip-style-' + style);
            
            // Update preview content based on style
            updatePreviewContent(style);
        }

        /**
         * Update preview content
         */
        function updatePreviewContent(style) {
            const $preview = $('.wcvip-preview-variations');
            
            // Get preview HTML based on style (similar to PHP get_style_preview_html)
            let previewHTML = '';
            
            switch(style) {
                case 'square':
                    previewHTML = '<div class="wcvip-preview-square-thumbs"><div class="wcvip-preview-thumb active"></div><div class="wcvip-preview-thumb"></div><div class="wcvip-preview-thumb"></div></div>';
                    break;
                case 'circular':
                    previewHTML = '<div class="wcvip-preview-circular-thumbs"><div class="wcvip-preview-circle active"></div><div class="wcvip-preview-circle"></div><div class="wcvip-preview-circle"></div></div>';
                    break;
                case 'dropdown':
                    previewHTML = '<div class="wcvip-preview-dropdown"><div class="wcvip-preview-dropdown-select"><span>Choose option</span><span class="wcvip-preview-dropdown-arrow">▼</span></div><div class="wcvip-preview-dropdown-thumb"></div></div>';
                    break;
                case 'buttons':
                    previewHTML = '<div class="wcvip-preview-buttons"><div class="wcvip-preview-button active"><div class="wcvip-preview-button-thumb"></div><span>Small</span></div><div class="wcvip-preview-button"><div class="wcvip-preview-button-thumb"></div><span>Large</span></div></div>';
                    break;
                case 'vertical':
                    previewHTML = '<div class="wcvip-preview-vertical"><div class="wcvip-preview-vertical-item active"></div><div class="wcvip-preview-vertical-item"></div><div class="wcvip-preview-vertical-item"></div></div>';
                    break;
                case 'grid':
                    previewHTML = '<div class="wcvip-preview-grid"><div class="wcvip-preview-grid-item active"></div><div class="wcvip-preview-grid-item"></div><div class="wcvip-preview-grid-item"></div><div class="wcvip-preview-grid-item"></div></div>';
                    break;
                default:
                    previewHTML = '<p>Preview for ' + style + '</p>';
            }
            
            $preview.html(previewHTML);
        }

        /**
         * Refresh preview when per-attribute styles change
         */
        function refreshAttributeStylesPreview() {
            // Check if attribute styles section exists
            const $attributeSection = $('#wcvip-attribute-styles-section');
            if ($attributeSection.length === 0) {
                return;
            }
            
            // Get the default display style (from active style card)
            const $activeStyle = $('.wcvip-style-card.active, .wcvip-style-option.active');
            const defaultStyle = $activeStyle.length > 0 ? $activeStyle.data('style') : '';
            
            // Collect all attribute styles
            const attributeStyles = {};
            $attributeSection.find('.wcvip-attribute-style-select').each(function() {
                const $select = $(this);
                const attrKey = $select.data('attribute-key');
                const style = $select.val();
                if (attrKey) {
                    attributeStyles[attrKey] = style || '';
                }
            });
            
            // Get product ID
            const $designer = $('.wcvip-visual-designer');
            const currentProductId = $designer.data('product-id');
            
            if (!currentProductId) {
                return;
            }
            
            // Call AJAX to refresh preview
            $.ajax({
                url: wcvipDesigner.ajaxurl,
                type: 'POST',
                data: {
                    action: 'wcvip_refresh_selector_preview',
                    nonce: wcvipDesigner.nonce,
                    product_id: currentProductId,
                    display_style: defaultStyle,
                    attribute_styles: attributeStyles
                },
                success: function(response) {
                    if (response.success && response.data && response.data.html) {
                        // Update the preview selector
                        const $previewSelector = $('#wcvip-live-preview-selector');
                        if ($previewSelector.length > 0) {
                            $previewSelector.html(response.data.html);
                        }
                    }
                },
                error: function() {
                    console.error('Failed to refresh preview');
                }
            });
        }
        
        /**
         * Show upgrade prompt
         */
        function showUpgradePrompt(message) {
            const modal = $(
                '<div class="wcvip-modal-overlay wcvip-upgrade-modal">' +
                '<div class="wcvip-modal">' +
                '<div class="wcvip-modal-header">' +
                '<h2>⭐ Upgrade to Pro</h2>' +
                '<span class="wcvip-close">&times;</span>' +
                '</div>' +
                '<div class="wcvip-modal-body">' +
                '<p>' + message + '</p>' +
                '<ul style="text-align: left; margin: 20px 0;">' +
                '<li>✅ Circular thumbnails (like your example)</li>' +
                '<li>✅ Grid layouts</li>' +
                '<li>✅ Advanced customization options</li>' +
                '<li>✅ Unlimited images per variation</li>' +
                '<li>✅ Video support</li>' +
                '<li>✅ All page locations</li>' +
                '</ul>' +
                '</div>' +
                '<div class="wcvip-modal-footer">' +
                '<button class="wcvip-btn wcvip-btn-secondary wcvip-modal-close">Maybe Later</button>' +
                '<button class="wcvip-btn wcvip-btn-primary wcvip-upgrade-button">Upgrade Now</button>' +
                '</div>' +
                '</div>' +
                '</div>'
            );

            $('body').append(modal);

            modal.find('.wcvip-close, .wcvip-modal-close').on('click', function() {
                modal.remove();
            });

            modal.find('.wcvip-upgrade-button').on('click', function() {
                // Redirect to upgrade page
                const upgradeUrl = wcvipDesigner.upgradeUrl || 'https://shalconnects.com/services/wordpress/plugins/variation-images-pro';
                window.open(upgradeUrl, '_blank');
                modal.remove();
            });
        }
        
        // Call init to set up event handlers
        init();
        
        // Initialize upgrade banner
        initUpgradeBanner();
    }
    
    // Initialize on document ready
    $(document).ready(function() {
        initializeDesigner();
    });
    
    // Also expose for manual initialization
    window.wcvipDesignerInit = initializeDesigner;
    
    // Listen for custom event to re-initialize
    $(document).on('wcvip-designer-loaded', function() {
        initializeDesigner();
    });

})(jQuery);

