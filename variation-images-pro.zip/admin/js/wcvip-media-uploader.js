/**
 * Media uploader integration
 */

(function($) {
    'use strict';

    window.WCVIPMediaUploader = {
        /**
         * Open WordPress media uploader
         */
        open: function(options) {
            options = options || {};
            
            const defaults = {
                title: 'Select Images',
                button: {
                    text: 'Add to Variation'
                },
                multiple: wcvipData.isPro ? true : false,
                library: {
                    type: 'image'
                }
            };

            const settings = $.extend({}, defaults, options);

            // Check limit for free version
            if (!wcvipData.isPro && options.currentCount >= 1) {
                alert('Free version is limited to 1 image per variation. Upgrade to Pro for unlimited images!');
                return null;
            }

            // Create media uploader
            const mediaUploader = wp.media(settings);

            return mediaUploader;
        },

        /**
         * Handle selected images
         */
        processSelection: function(selection, callback) {
            const images = [];

            selection.forEach(function(attachment) {
                attachment = attachment.toJSON();

                // Check limit again
                if (!wcvipData.isPro && images.length >= 1) {
                    alert('Free version is limited to 1 image per variation.');
                    return;
                }

                // Add image
                images.push({
                    id: attachment.id,
                    url: attachment.url,
                    thumbnail: attachment.sizes && attachment.sizes.thumbnail ? attachment.sizes.thumbnail.url : attachment.url,
                    alt: attachment.alt || '',
                    is_primary: images.length === 0 // First image is primary
                });
            });

            if (callback && typeof callback === 'function') {
                callback(images);
            }

            return images;
        }
    };

})(jQuery);

