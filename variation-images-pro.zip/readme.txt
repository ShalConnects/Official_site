=== Variation Images Pro for WooCommerce ===
Contributors: shalconnects
Tags: woocommerce, variations, variation images, swatches, product gallery
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add unlimited custom images and videos to WooCommerce product variations with advanced gallery layouts.

== Description ==

WooCommerce Variation Images Pro allows you to add custom images (and optionally videos) to each product variation, giving your customers a better visual experience when selecting product options.

= Features =

* **Free Version:**
  * Add 1 image per variation
  * Basic image swap on variation change
  * Works on product pages
  * Compatible with all major page builders

* **Pro Version:**
  * Unlimited images per variation
  * Optional video support (YouTube, Vimeo, self-hosted)
  * Multiple display styles: slider, carousel, gallery, hover swap, zoom
  * Works on product, shop, archive, quick view, cart, and checkout pages
  * Bulk image upload & assignment
  * Drag-and-drop image sorting
  * CSV import/export
  * Lazy loading & image optimization
  * Optional CDN integration
  * REST API endpoints
  * Multi-vendor support (Dokan, WCFM)
  * Dedicated widgets for Elementor, Bricks, Divi
  * White-label mode
  * Priority support

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/wc-variation-images-pro/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Make sure WooCommerce is installed and activated
4. Go to 'Variation Images' in the admin menu to start managing variation images

== Frequently Asked Questions ==

= Does this work with all themes? =

Yes, the plugin is designed to work with all WordPress themes and major page builders.

= Can I use multiple images per variation in the free version? =

No, the free version is limited to 1 image per variation. Upgrade to Pro for unlimited images.

= Does it work with Elementor/Bricks/Divi? =

Yes, the plugin works with all page builders. The Pro version includes dedicated widgets for Elementor, Bricks, and Divi.

= Is there multi-vendor support? =

Multi-vendor support (Dokan, WCFM) is available in the Pro version.

== Changelog ==

= 1.0.0 =
* Initial release
* Free version: 1 image per variation, basic image swap
* Pro version: Unlimited images, advanced gallery layouts, video support, bulk operations, CSV import/export, REST API, multi-vendor support

== Upgrade Notice ==

= 1.0.0 =
Initial release. Upgrade to Pro for unlimited images, advanced layouts, and premium features.

== Upgrade to Pro ==

Want more features? Upgrade to Pro and get:

* Unlimited images per variation
* Advanced display styles (circular, grid, slider, carousel, hover, zoom)
* Video support (YouTube, Vimeo, self-hosted)
* Works on shop, archive, cart, and checkout pages
* Bulk image upload & assignment
* Drag-and-drop image sorting
* CSV import/export
* Lazy loading & image optimization
* CDN integration
* REST API endpoints
* Multi-vendor support (Dokan, WCFM)
* Dedicated widgets for Elementor, Bricks, Divi
* Gutenberg blocks
* Priority support

[Get Pro Version →](https://shalconnects.com/services/wordpress/plugins/variation-images-pro)

