<?php
/**
 * Plugin Name: Variation Images Pro for WooCommerce
 * Plugin URI: http://shalconnects.com/
 * Description: Add unlimited custom images and videos to WooCommerce product variations with advanced gallery layouts
 * Version: 1.0.0
 * Author: ShalConnects
 * Author URI: http://shalconnects.com/
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: wc-variation-images-pro
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * WC requires at least: 6.0
 * WC tested up to: 8.5
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

// Plugin version
define( 'WCVIP_VERSION', '1.0.0' );
define( 'WCVIP_PLUGIN_FILE', __FILE__ );
define( 'WCVIP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WCVIP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WCVIP_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

// Check if Pro version
define( 'WCVIP_IS_PRO', true ); // Set to true for Pro version

/**
 * Check WooCommerce is active
 */
function wcvip_check_woocommerce() {
    if ( ! class_exists( 'WooCommerce' ) ) {
        add_action( 'admin_notices', 'wcvip_woocommerce_missing_notice' );
        return false;
    }
    return true;
}

function wcvip_woocommerce_missing_notice() {
    ?>
    <div class="error">
        <p><?php esc_html_e( 'Variation Images Pro for WooCommerce requires WooCommerce to be installed and activated.', 'wc-variation-images-pro' ); ?></p>
    </div>
    <?php
}

/**
 * Activation hook
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedFunctionFound -- Hook callback function
function activate_wcvip() {
	require_once WCVIP_PLUGIN_DIR . 'includes/class-wcvip-activator.php';
	WCVIP_Activator::activate();
}

/**
 * Deactivation hook
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedFunctionFound -- Hook callback function
function deactivate_wcvip() {
	require_once WCVIP_PLUGIN_DIR . 'includes/class-wcvip-deactivator.php';
	WCVIP_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_wcvip' );
register_deactivation_hook( __FILE__, 'deactivate_wcvip' );
// Uninstall hook is handled by uninstall.php file

/**
 * Declare WooCommerce compatibility
 */
function wcvip_declare_woocommerce_compatibility() {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
	}
}
add_action( 'before_woocommerce_init', 'wcvip_declare_woocommerce_compatibility' );

/**
 * Set default upgrade URL for Pro version
 * This can be filtered by themes or other plugins
 */
add_filter( 'wcvip_upgrade_url', function( $url ) {
	return 'https://shalconnects.com/services/wordpress/plugins/variation-images-pro';
} );

/**
 * Initialize the plugin
 */
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedFunctionFound -- Hook callback function
function run_wcvip() {
    if ( ! wcvip_check_woocommerce() ) {
        return;
    }

    require_once WCVIP_PLUGIN_DIR . 'includes/class-wcvip-core.php';
    $plugin = new WCVIP_Core();
    $plugin->run();
}

add_action( 'plugins_loaded', 'run_wcvip' );