<?php
/**
 * Pro display styles
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pro styles class
 */
class WCVIP_Pro_Styles {

	/**
	 * Get Pro display styles
	 *
	 * @return array Pro styles array
	 */
	public static function get_pro_styles() {
		return array(
			'buttons'           => __( 'Button Style (Image First)', 'wc-variation-images-pro' ),
			'buttons_text_first' => __( 'Button Style (Text First)', 'wc-variation-images-pro' ),
			'square'            => __( 'Square Thumbnails', 'wc-variation-images-pro' ),
			'circular'          => __( 'Circular Thumbnails', 'wc-variation-images-pro' ),
		);
	}

	/**
	 * Check if Pro styles are available
	 *
	 * @return bool
	 */
	public static function is_available() {
		return WCVIP_IS_PRO && class_exists( __CLASS__ );
	}
}

