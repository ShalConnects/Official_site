<?php
/**
 * Compatibility handler for themes and plugins
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Compatibility class
 */
class WCVIP_Compatibility {

	/**
	 * Initialize compatibility checks
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'check_theme_compatibility' ) );
		add_action( 'init', array( __CLASS__, 'check_plugin_compatibility' ) );
	}

	/**
	 * Check theme compatibility
	 */
	public static function check_theme_compatibility() {
		$theme = wp_get_theme();

		// Known compatible themes
		$compatible_themes = array(
			'Astra',
			'GeneratePress',
			'Storefront',
			'Flatsome',
			'Woodmart',
			'Kadence',
		);

		$theme_name = $theme->get( 'Name' );

		// Apply compatibility fixes for specific themes
		if ( in_array( $theme_name, $compatible_themes, true ) ) {
			add_filter( 'wcvip_gallery_wrapper_class', array( __CLASS__, 'add_theme_wrapper_class' ) );
		}
	}

	/**
	 * Check plugin compatibility
	 */
	public static function check_plugin_compatibility() {
		// WooCommerce Product Gallery
		if ( class_exists( 'WC_Product_Gallery' ) ) {
			add_filter( 'woocommerce_single_product_image_gallery_classes', array( __CLASS__, 'add_gallery_classes' ) );
		}

		// WooCommerce Zoom/Magnifier plugins
		if ( class_exists( 'WC_Product_Zoom' ) ) {
			add_action( 'wp_enqueue_scripts', array( __CLASS__, 'disable_zoom_conflicts' ), 999 );
		}
	}

	/**
	 * Add theme wrapper class
	 */
	public static function add_theme_wrapper_class( $classes ) {
		$theme = wp_get_theme();
		$classes[] = 'wcvip-theme-' . strtolower( str_replace( ' ', '-', $theme->get( 'Name' ) ) );
		return $classes;
	}

	/**
	 * Add gallery classes
	 */
	public static function add_gallery_classes( $classes ) {
		$classes[] = 'wcvip-compatible';
		return $classes;
	}

	/**
	 * Disable zoom conflicts
	 */
	public static function disable_zoom_conflicts() {
		// Disable conflicting zoom scripts if needed
	}
}

