# Deploy Pro Version to Downloads Folder

$ErrorActionPreference = "Stop"

Write-Host "Deploying Pro Version..." -ForegroundColor Green

# Paths
$sourceZip = "variation-images-pro.zip"
$targetDir = "C:\Users\salau\Downloads\Projects\ShalConnects\public\downloads"
$targetFile = "wc-variation-images-pro-pro-v1.0.0.zip"

# Check if source exists
if (-not (Test-Path $sourceZip)) {
    Write-Host "ERROR: Source file not found: $sourceZip" -ForegroundColor Red
    Write-Host "Please build the Pro version first using build-zips.ps1" -ForegroundColor Yellow
    exit 1
}

# Check if target directory exists
if (-not (Test-Path $targetDir)) {
    Write-Host "Creating target directory: $targetDir" -ForegroundColor Yellow
    New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
}

# Remove old file if exists
$targetPath = Join-Path $targetDir $targetFile
if (Test-Path $targetPath) {
    Write-Host "Removing old file..." -ForegroundColor Yellow
    Remove-Item $targetPath -Force
}

# Copy new file
Write-Host "Copying Pro ZIP to downloads folder..." -ForegroundColor Cyan
Copy-Item $sourceZip $targetPath -Force

# Verify
if (Test-Path $targetPath) {
    $fileSize = (Get-Item $targetPath).Length / 1KB
    Write-Host "✓ Pro ZIP deployed successfully!" -ForegroundColor Green
    Write-Host "  Location: $targetPath" -ForegroundColor Gray
    Write-Host "  Size: $([math]::Round($fileSize, 2)) KB" -ForegroundColor Gray
} else {
    Write-Host "ERROR: Deployment failed!" -ForegroundColor Red
    exit 1
}

Write-Host "`nDeployment complete!" -ForegroundColor Cyan

