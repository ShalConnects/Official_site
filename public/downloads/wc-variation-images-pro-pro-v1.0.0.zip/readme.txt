=== Dynamic Variation Images for WooCommerce ===
Contributors: shalconnects
Tags: woocommerce, variations, variation images, swatches, product gallery
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add custom images to WooCommerce product variations with advanced gallery layouts and multiple display styles.

== Description ==

Dynamic Variation Images for WooCommerce allows you to add custom images to each product variation, giving your customers a better visual experience when selecting product options.

= Features =

* Add images to product variations
* Multiple display styles: horizontal text, vertical text, color swatches, square thumbnails, circular thumbnails, and button styles
* Visual Designer for customizing variation selectors per product
* Works on product pages
* Compatible with all major page builders (Elementor, Bricks, Divi, Gutenberg)
* Multi-attribute support with grouped or separate sections
* Lazy loading for improved performance
* REST API endpoints for headless WooCommerce
* Multi-vendor support (Dokan, WCFM)

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/wc-variation-images-pro/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Make sure WooCommerce is installed and activated
4. Go to 'Variation Images' in the admin menu to start managing variation images

== Frequently Asked Questions ==

= Does this work with all themes? =

Yes, the plugin is designed to work with all WordPress themes and major page builders.

= Can I use multiple images per variation? =

Yes, you can add multiple images to each variation.

= Does it work with Elementor/Bricks/Divi? =

Yes, the plugin works with all page builders and includes dedicated widgets for Elementor, Bricks, and Divi.

= Is there multi-vendor support? =

Yes, multi-vendor support (Dokan, WCFM) is available.

== Changelog ==

= 1.0.0 =
* Initial release
* Add images to product variations
* Multiple display styles and layouts
* Visual Designer for custom variation selectors
* REST API endpoints
* Multi-vendor support

== Upgrade Notice ==

= 1.0.0 =
Initial release. A Pro version with priority support and additional features is available at [store.shalconnects.com](https://store.shalconnects.com/variation-images-pro).

Try the free version: [WordPress.org Plugin Directory](https://wordpress.org/plugins/dynamic-variation-images)

