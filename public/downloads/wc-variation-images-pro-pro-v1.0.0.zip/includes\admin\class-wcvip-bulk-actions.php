<?php
/**
 * Bulk actions for variation images (Pro feature)
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bulk actions class
 */
class WCVIP_Bulk_Actions {

	/**
	 * Initialize
	 */
	public function init() {
		add_action( 'admin_post_wcvip_bulk_upload', array( $this, 'handle_bulk_upload' ) );
		add_action( 'admin_post_wcvip_bulk_assign', array( $this, 'handle_bulk_assign' ) );
	}

	/**
	 * Handle bulk upload
	 */
	public function handle_bulk_upload() {
		check_admin_referer( 'wcvip-bulk-upload' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'wc-variation-images-pro' ) );
		}

		// Handle bulk upload logic
		wp_safe_redirect( admin_url( 'admin.php?page=wcvip-dashboard&bulk_uploaded=1' ) );
		exit;
	}

	/**
	 * Handle bulk assign
	 */
	public function handle_bulk_assign() {
		check_admin_referer( 'wcvip-bulk-assign' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'wc-variation-images-pro' ) );
		}

		// Handle bulk assign logic
		wp_safe_redirect( admin_url( 'admin.php?page=wcvip-dashboard&bulk_assigned=1' ) );
		exit;
	}
}

