<?php
/**
 * Variations REST API endpoint (Pro feature)
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Variations endpoint class
 */
class WCVIP_Variations_Endpoint {

	/**
	 * Extend WooCommerce variations endpoint
	 */
	public function __construct() {
		add_filter( 'woocommerce_rest_product_variation_response', array( $this, 'add_images_to_variation_response' ), 10, 2 );
	}

	/**
	 * Add custom images to variation response
	 */
	public function add_images_to_variation_response( $response, $variation ) {
		$variation_id = $variation->get_id();
		$custom_images = get_post_meta( $variation_id, '_wcvip_images', true );

		if ( is_array( $custom_images ) && ! empty( $custom_images ) ) {
			$response->data['wcvip_images'] = $custom_images;
		}

		return $response;
	}
}

