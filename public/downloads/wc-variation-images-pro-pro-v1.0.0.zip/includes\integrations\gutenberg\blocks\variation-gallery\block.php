<?php
/**
 * Gutenberg block for variation gallery (Pro feature)
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register Gutenberg block
 */
function wcvip_register_gutenberg_block() {
	register_block_type(
		'wcvip/variation-gallery',
		array(
			'editor_script' => 'wcvip-gutenberg-block',
			'render_callback' => 'wcvip_render_gutenberg_block',
			'attributes' => array(
				'productId' => array(
					'type' => 'number',
					'default' => 0,
				),
				'style' => array(
					'type' => 'string',
					'default' => '',
				),
			),
		)
	);
}
add_action( 'init', 'wcvip_register_gutenberg_block' );

/**
 * Render Gutenberg block
 */
function wcvip_render_gutenberg_block( $attributes ) {
	$product_id = isset( $attributes['productId'] ) ? absint( $attributes['productId'] ) : 0;
	$style = isset( $attributes['style'] ) ? sanitize_text_field( $attributes['style'] ) : '';

	// If no product_id, try to get from global product
	if ( ! $product_id && is_product() ) {
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce global $product is standard
		global $product;
		if ( $product ) {
			$product_id = $product->get_id();
		}
	}

	if ( ! $product_id ) {
		return '<p class="wcvip-block-error">' . esc_html__( 'Please select a product.', 'wc-variation-images-pro' ) . '</p>';
	}

	$block_product = wc_get_product( $product_id );
	if ( ! $block_product || ! $block_product->is_type( 'variable' ) ) {
		return '<p class="wcvip-block-error">' . esc_html__( 'Invalid product or product is not variable.', 'wc-variation-images-pro' ) . '</p>';
	}

	// Temporarily override display style if specified
	$original_style = null;
	if ( ! empty( $style ) ) {
		$original_style = get_option( 'wcvip_display_style', 'none' );
		update_option( 'wcvip_display_style', $style );
	}

	// Temporarily set global product for frontend renderer
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce global $product is standard
	global $product;
	$original_global_product = isset( $product ) ? $product : null;
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce global $product is standard
	$product = $block_product;

	// Use the frontend product page class to render selector
	$product_page = new WCVIP_Product_Page();
	
	// Capture output
	ob_start();
	$product_page->render_custom_variation_selector();
	$selector_html = ob_get_clean();

	// Restore original product and style
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce global $product is standard
	$product = $original_global_product;
	if ( $original_style !== null ) {
		update_option( 'wcvip_display_style', $original_style );
	}

	return $selector_html;
}

