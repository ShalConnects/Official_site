<?php
/**
 * License management (Pro feature)
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * License class
 */
class WCVIP_License {

	/**
	 * License key option name
	 */
	const LICENSE_KEY_OPTION = 'wcvip_license_key';

	/**
	 * License status option name
	 */
	const LICENSE_STATUS_OPTION = 'wcvip_license_status';

	/**
	 * Get license key
	 */
	public static function get_license_key() {
		return get_option( self::LICENSE_KEY_OPTION, '' );
	}

	/**
	 * Get license status
	 */
	public static function get_license_status() {
		return get_option( self::LICENSE_STATUS_OPTION, 'invalid' );
	}

	/**
	 * Activate license
	 */
	public static function activate_license( $license_key ) {
		// License activation logic
		// This would typically connect to your license server
		update_option( self::LICENSE_KEY_OPTION, sanitize_text_field( $license_key ) );
		update_option( self::LICENSE_STATUS_OPTION, 'valid' );

		return array(
			'success' => true,
			'message' => __( 'License activated successfully', 'wc-variation-images-pro' ),
		);
	}

	/**
	 * Deactivate license
	 */
	public static function deactivate_license() {
		delete_option( self::LICENSE_KEY_OPTION );
		delete_option( self::LICENSE_STATUS_OPTION );

		return array(
			'success' => true,
			'message' => __( 'License deactivated successfully', 'wc-variation-images-pro' ),
		);
	}

	/**
	 * Check if license is valid
	 */
	public static function is_valid() {
		return 'valid' === self::get_license_status();
	}
}

