<?php
/**
 * CDN handler for image optimization (Pro feature)
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CDN handler class
 */
class WCVIP_CDN_Handler {

	/**
	 * Check if CDN is enabled
	 */
	public static function is_enabled() {
		return 'yes' === get_option( 'wcvip_cdn_enabled', 'no' );
	}

	/**
	 * Get CDN URL
	 */
	public static function get_cdn_url() {
		return get_option( 'wcvip_cdn_url', '' );
	}

	/**
	 * Replace URL with CDN URL
	 */
	public static function replace_url( $url ) {
		if ( ! self::is_enabled() ) {
			return $url;
		}

		$cdn_url = self::get_cdn_url();
		if ( empty( $cdn_url ) ) {
			return $url;
		}

		$site_url = site_url();
		$url = str_replace( $site_url, $cdn_url, $url );

		return $url;
	}

	/**
	 * Process images array for CDN
	 */
	public static function process_images( $images ) {
		if ( ! is_array( $images ) ) {
			return $images;
		}

		foreach ( $images as &$image ) {
			if ( isset( $image['url'] ) ) {
				$image['url'] = self::replace_url( $image['url'] );
			}
			if ( isset( $image['thumbnail'] ) ) {
				$image['thumbnail'] = self::replace_url( $image['thumbnail'] );
			}
		}

		return $images;
	}
}

