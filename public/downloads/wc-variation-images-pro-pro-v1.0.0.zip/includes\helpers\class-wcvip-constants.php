<?php
/**
 * Plugin constants and URLs
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WordPress.org plugin directory URL
 * Update this after plugin is approved with the final slug
 */
if ( ! defined( 'WCVIP_WPORG_URL' ) ) {
	// Update this to the final WordPress.org plugin URL after approval
	// Options: 
	// - https://wordpress.org/plugins/dynamic-variation-images
	// - https://wordpress.org/plugins/shalconnects-variation-images
	define( 'WCVIP_WPORG_URL', 'https://wordpress.org/plugins/dynamic-variation-images' );
}

