<?php
/**
 * Elementor integration (Pro feature)
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Elementor integration class
 */
class WCVIP_Elementor {

	/**
	 * Register Elementor widgets
	 */
	public function register_widgets( $widgets_manager ) {
		require_once WCVIP_PLUGIN_DIR . 'includes/integrations/elementor/widgets/class-variation-gallery-widget.php';
		$widgets_manager->register( new WCVIP_Elementor_Variation_Gallery_Widget() );
	}
}

