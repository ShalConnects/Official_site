<?php
/**
 * Meta boxes for product variations
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Meta boxes class
 */
class WCVIP_Meta_Boxes {

	/**
	 * Add meta boxes
	 */
	public function add_meta_boxes() {
		add_meta_box(
			'wcvip-variation-images',
			__( 'Variation Images', 'wc-variation-images-pro' ),
			array( $this, 'render_variation_images_meta_box' ),
			'product',
			'side',
			'default'
		);
	}

	/**
	 * Render variation images meta box
	 */
	public function render_variation_images_meta_box( $post ) {
		if ( ! $post || 'product' !== $post->post_type ) {
			return;
		}

		$product = wc_get_product( $post->ID );
		if ( ! $product || ! $product->is_type( 'variable' ) ) {
			echo '<p>' . esc_html__( 'This is not a variable product. Add variations to use custom images.', 'wc-variation-images-pro' ) . '</p>';
			return;
		}

		?>
		<div class="wcvip-meta-box">
			<p>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=wcvip-dashboard&product_id=' . $post->ID ) ); ?>" class="button button-primary">
					<?php esc_html_e( 'Manage Variation Images', 'wc-variation-images-pro' ); ?>
				</a>
			</p>
			<p class="description">
				<?php esc_html_e( 'Manage custom images for each product variation.', 'wc-variation-images-pro' ); ?>
			</p>
		</div>
		<?php
	}

	/**
	 * Save meta box data
	 */
	public function save_meta_box_data( $post_id ) {
		// Handled by AJAX, no need to save here
	}
}

