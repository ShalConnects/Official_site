<?php
/**
 * Cart preview functionality (Pro feature)
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Cart class
 */
class WCVIP_Cart {

	/**
	 * Display cart item image with variation
	 */
	public function display_cart_item_image( $image, $cart_item, $cart_item_key ) {
		$variation_id = isset( $cart_item['variation_id'] ) ? absint( $cart_item['variation_id'] ) : 0;

		if ( ! $variation_id ) {
			return $image;
		}

		$custom_images = get_post_meta( $variation_id, '_wcvip_images', true );

		if ( ! empty( $custom_images ) && is_array( $custom_images ) ) {
			$primary_image = null;
			foreach ( $custom_images as $img ) {
				if ( ! empty( $img['is_primary'] ) ) {
					$primary_image = $img;
					break;
				}
			}

			if ( ! $primary_image && ! empty( $custom_images[0] ) ) {
				$primary_image = $custom_images[0];
			}

			if ( $primary_image && isset( $primary_image['id'] ) ) {
				$image_id = absint( $primary_image['id'] );
				return wp_get_attachment_image( $image_id, 'woocommerce_thumbnail', false, array( 'class' => 'wcvip-cart-image' ) );
			}
		}

		return $image;
	}
}

