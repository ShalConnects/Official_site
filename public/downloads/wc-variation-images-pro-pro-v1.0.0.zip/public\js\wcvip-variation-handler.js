/**
 * Variation handler for frontend
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        const $variationsForm = $('.variations_form');

        if ($variationsForm.length === 0) {
            return; // Not a variable product
        }

        // Store original images
        let originalImages = [];
        let currentVariationImages = [];

        // Get original product gallery images
        function storeOriginalImages() {
            originalImages = [];
            $('.woocommerce-product-gallery__image').each(function() {
                const $img = $(this).find('img');
                originalImages.push({
                    src: $img.attr('src'),
                    srcset: $img.attr('srcset'),
                    sizes: $img.attr('sizes')
                });
            });
        }

        // Initialize
        storeOriginalImages();

        // Listen for variation changes
        $variationsForm.on('found_variation', function(event, variation) {
            // Check if this variation has custom images
            if (variation.wcvip_images && variation.wcvip_images.length > 0) {
                currentVariationImages = variation.wcvip_images;
                updateGalleryImages(variation.wcvip_images);
            } else if (variation.image && variation.image.src) {
                // Fall back to WooCommerce default variation image
                currentVariationImages = [];
                updateSingleImage(variation.image);
            }
        });

        // Listen for variation reset
        $variationsForm.on('reset_data', function() {
            currentVariationImages = [];
            restoreOriginalImages();
        });

        /**
         * Update gallery with custom images
         */
        function updateGalleryImages(images) {
            const $gallery = $('.woocommerce-product-gallery__wrapper');
            const $mainImage = $('.woocommerce-product-gallery__image:first img');

            if ($mainImage.length === 0) {
                return;
            }

            // Get primary image or first image
            let primaryImage = images.find(img => img.is_primary);
            if (!primaryImage) {
                primaryImage = images[0];
            }

            // Update main image with fade effect
            $mainImage.addClass('wcvip-fade');
            $mainImage.attr('src', primaryImage.src || primaryImage.url);
            if (primaryImage.srcset) {
                $mainImage.attr('srcset', primaryImage.srcset);
            }
            if (primaryImage.sizes) {
                $mainImage.attr('sizes', primaryImage.sizes);
            }

            // Remove fade class after animation
            setTimeout(function() {
                $mainImage.removeClass('wcvip-fade');
            }, 300);

            // Create thumbnails if enabled
            if (images.length > 1 && wcvipFrontend.displayThumbnails === 'yes') {
                createThumbnails(images);
            }
        }

        /**
         * Update with single image (fallback)
         */
        function updateSingleImage(image) {
            const $mainImage = $('.woocommerce-product-gallery__image:first img');

            if ($mainImage.length === 0) {
                return;
            }

            $mainImage.addClass('wcvip-fade');
            $mainImage.attr('src', image.src);

            if (image.srcset) {
                $mainImage.attr('srcset', image.srcset);
            }

            if (image.sizes) {
                $mainImage.attr('sizes', image.sizes);
            }

            setTimeout(function() {
                $mainImage.removeClass('wcvip-fade');
            }, 300);

            // Remove thumbnails if they exist
            $('.wcvip-thumbnails').remove();
        }

        /**
         * Restore original product images
         */
        function restoreOriginalImages() {
            if (originalImages.length === 0) {
                return;
            }

            const $mainImage = $('.woocommerce-product-gallery__image:first img');
            const original = originalImages[0];

            $mainImage.addClass('wcvip-fade');
            $mainImage.attr('src', original.src);
            $mainImage.attr('srcset', original.srcset || '');
            $mainImage.attr('sizes', original.sizes || '');

            setTimeout(function() {
                $mainImage.removeClass('wcvip-fade');
            }, 300);

            // Remove thumbnails
            $('.wcvip-thumbnails').remove();
        }

        /**
         * Create thumbnail navigation (Pro feature)
         */
        function createThumbnails(images) {
            // Remove existing thumbnails
            $('.wcvip-thumbnails').remove();

            // Create thumbnails container
            const $thumbnailsContainer = $('<div class="wcvip-thumbnails"></div>');

            images.forEach(function(image, index) {
                const $thumb = $(
                    '<div class="wcvip-thumbnail' + (index === 0 ? ' active' : '') + '" data-index="' + index + '">' +
                    '<img src="' + (image.thumbnail || image.url) + '" alt="' + (image.alt || '') + '">' +
                    '</div>'
                );

                $thumbnailsContainer.append($thumb);
            });

            // Add thumbnails after main image
            $('.woocommerce-product-gallery').append($thumbnailsContainer);

            // Handle thumbnail clicks
            $('.wcvip-thumbnail').on('click', function() {
                const index = $(this).data('index');
                const image = images[index];

                // Update main image
                const $mainImage = $('.woocommerce-product-gallery__image:first img');
                $mainImage.addClass('wcvip-fade');
                $mainImage.attr('src', image.src || image.url);

                if (image.srcset) {
                    $mainImage.attr('srcset', image.srcset);
                }

                if (image.sizes) {
                    $mainImage.attr('sizes', image.sizes);
                }

                setTimeout(function() {
                    $mainImage.removeClass('wcvip-fade');
                }, 300);

                // Update active state
                $('.wcvip-thumbnail').removeClass('active');
                $(this).addClass('active');
            });
        }
    });

})(jQuery);

