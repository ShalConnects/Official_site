<?php
/**
 * The admin-specific functionality of the plugin
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The admin-specific functionality of the plugin
 */
class WCVIP_Admin {

	/**
	 * The ID of this plugin
	 */
	private $plugin_name;

	/**
	 * The version of this plugin
	 */
	private $version;

	/**
	 * Initialize the class and set its properties
	 */
	public function __construct( $plugin_name, $version ) {
		$this->plugin_name = $plugin_name;
		$this->version     = $version;
		
		// Run migration on admin init
		add_action( 'admin_init', array( $this, 'migrate_display_style_default' ), 5 );
	}
	
	/**
	 * Migrate old 'square' default to 'none'
	 */
	public function migrate_display_style_default() {
		// Only run once
		if ( get_option( 'wcvip_display_style_migrated', false ) ) {
			return;
		}
		
		$current_style = get_option( 'wcvip_display_style', false );
		
		// Migrate 'square' to 'none' (old default)
		if ( 'square' === $current_style ) {
			update_option( 'wcvip_display_style', 'none' );
		}
		
		// Also migrate 'basic' to 'none' (very old default)
		if ( 'basic' === $current_style ) {
			update_option( 'wcvip_display_style', 'none' );
		}
		
		// Mark as migrated
		update_option( 'wcvip_display_style_migrated', true );
	}

	/**
	 * Register the stylesheets for the admin area
	 */
	public function enqueue_styles( $hook ) {
		// Load on our plugin pages
		if ( strpos( $hook, 'wcvip' ) === false && $hook !== 'toplevel_page_wcvip-dashboard' ) {
			return;
		}

		// Try to load from admin/css, fallback to assets/css
		$css_file = WCVIP_PLUGIN_DIR . 'admin/css/wcvip-admin.css';
		if ( ! file_exists( $css_file ) ) {
			$css_file = WCVIP_PLUGIN_DIR . 'assets/css/admin.css';
		}

		if ( file_exists( $css_file ) ) {
			$css_url = str_replace( WCVIP_PLUGIN_DIR, WCVIP_PLUGIN_URL, $css_file );
			wp_enqueue_style(
				$this->plugin_name,
				$css_url,
				array(),
				$this->version,
				'all'
			);
		}
	}

	/**
	 * Register the JavaScript for the admin area
	 */
	public function enqueue_scripts( $hook ) {
		// Load on our plugin pages
		if ( strpos( $hook, 'wcvip' ) === false && $hook !== 'toplevel_page_wcvip-dashboard' ) {
			return;
		}

		wp_enqueue_media();

		// Try to load from admin/js, fallback to assets/js
		$js_file = WCVIP_PLUGIN_DIR . 'admin/js/wcvip-admin.js';
		if ( ! file_exists( $js_file ) ) {
			$js_file = WCVIP_PLUGIN_DIR . 'assets/js/admin.js';
		}

		if ( file_exists( $js_file ) ) {
			$js_url = str_replace( WCVIP_PLUGIN_DIR, WCVIP_PLUGIN_URL, $js_file );
			wp_enqueue_script(
				$this->plugin_name,
				$js_url,
				array( 'jquery', 'jquery-ui-sortable' ),
				$this->version,
				false
			);
		}

		wp_localize_script(
			$this->plugin_name,
			'wcvipData',
			array(
				'ajaxurl'     => admin_url( 'admin-ajax.php' ),
				'nonce'       => wp_create_nonce( 'wcvip-nonce' ),
				'isPro'       => WCVIP_IS_PRO,
				'imageLimit'  => WCVIP_IS_PRO ? 0 : 1,
				'restApiUrl'  => rest_url( 'wcvip/v1/' ),
				'restNonce'   => wp_create_nonce( 'wp_rest' ),
			)
		);
	}

	/**
	 * Add admin menu
	 */
	public function add_admin_menu() {
		add_menu_page(
			__( 'WooCommerce Variation Images Pro', 'wc-variation-images-pro' ),
			__( 'Variation Images', 'wc-variation-images-pro' ),
			'manage_woocommerce',
			'wcvip-dashboard',
			array( $this, 'render_dashboard' ),
			'dashicons-images-alt2',
			56
		);

		add_submenu_page(
			'wcvip-dashboard',
			__( 'Settings', 'wc-variation-images-pro' ),
			__( 'Settings', 'wc-variation-images-pro' ),
			'manage_woocommerce',
			'wcvip-settings',
			array( $this, 'render_settings_page' )
		);
	}

	/**
	 * Render admin dashboard
	 */
	public function render_dashboard() {
		// Verify nonce for GET parameters (recommended for security)
		if ( isset( $_GET['product_id'] ) || isset( $_GET['view'] ) ) {
			if ( ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'wcvip_dashboard' ) ) {
				// Nonce verification failed, but allow display with sanitized values for backward compatibility
			}
		}
		$product_id = isset( $_GET['product_id'] ) ? absint( $_GET['product_id'] ) : 0;
		$view = isset( $_GET['view'] ) ? sanitize_text_field( wp_unslash( $_GET['view'] ) ) : 'list';
		
		// If product_id and view=designer, show visual designer
		if ( $product_id && 'designer' === $view ) {
			$designer = new WCVIP_Visual_Designer();
			$designer->render_designer( $product_id );
			return;
		}
		
		?>
		<div class="wrap">
			<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
			<p class="wcvip-intro-description">
				<?php esc_html_e( 'Manage variation images for your WooCommerce products. Add images to variations and customize display styles.', 'wc-variation-images-pro' ); ?>
				<a href="#" target="_blank" class="wcvip-help-link"><?php esc_html_e( 'View Documentation', 'wc-variation-images-pro' ); ?></a> | 
				<a href="#" target="_blank" class="wcvip-help-link"><?php esc_html_e( 'Get Support', 'wc-variation-images-pro' ); ?></a>
			</p>
			
			<!-- jQuery interface -->
			<div class="wcvip-dashboard">
				<div class="wcvip-products-list">
					<div id="wcvip-products-container">
						<div class="wcvip-initial-loading">
							<div class="wcvip-spinner"></div>
						<p><?php esc_html_e( 'Loading products...', 'wc-variation-images-pro' ); ?></p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render settings page
	 */
	public function render_settings_page() {
		// Settings page will be handled by WCVIP_Settings class
		// This is a placeholder
		?>
		<div class="wrap">
			<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
			<form method="post" action="options.php">
				<?php
				settings_fields( 'wcvip_settings' );
				do_settings_sections( 'wcvip_settings' );
				submit_button();
				?>
			</form>
		</div>
		<?php
	}

	/**
	 * AJAX: Get products
	 */
	public function ajax_get_products() {
		// Rate limiting check (higher limit for read operations)
		$rate_limit = WCVIP_Rate_Limiter::check_rate_limit( 'wcvip_get_products', 30, 60 );
		if ( is_wp_error( $rate_limit ) ) {
			WCVIP_Security_Logger::log(
				'rate_limit_exceeded',
				'Rate limit exceeded for wcvip_get_products',
				array(
					'action' => 'wcvip_get_products',
					'user_id' => get_current_user_id(),
				)
			);
			wp_send_json_error( array(
				'message' => $rate_limit->get_error_message(),
				'retry_after' => $rate_limit->get_error_data()['retry_after'],
			) );
		}

		// Check nonce and log failures
		if ( ! check_ajax_referer( 'wcvip-nonce', 'nonce', false ) ) {
			WCVIP_Security_Logger::log(
				'nonce_failed',
				'Failed nonce verification for wcvip_get_products',
				array(
					'action' => 'wcvip_get_products',
					'nonce' => isset( $_POST['nonce'] ) ? 'present' : 'missing',
				)
			);
			wp_send_json_error( array( 'message' => __( 'Security check failed', 'wc-variation-images-pro' ) ) );
		}

		$args = array(
			'type'   => 'variable',
			'limit'  => 100,
			'status' => 'publish',
			'return' => 'ids',
		);

		$product_ids = wc_get_products( $args );
		$products    = array();

		foreach ( $product_ids as $product_id ) {
			$product = wc_get_product( $product_id );
			if ( ! $product ) {
				continue;
			}

			$variation_ids = $product->get_children();
			$image_id      = $product->get_image_id();

			// Count variations with images configured
			$variations_with_images = 0;
			foreach ( $variation_ids as $variation_id ) {
				$custom_images = get_post_meta( $variation_id, '_wcvip_images', true );
				if ( is_array( $custom_images ) && ! empty( $custom_images ) ) {
					$variations_with_images++;
				}
			}

			$products[] = array(
				'id'                      => $product->get_id(),
				'name'                    => $product->get_name(),
				'sku'                     => $product->get_sku(),
				'image'                   => $image_id ? wp_get_attachment_image_url( $image_id, 'thumbnail' ) : '',
				'permalink'               => $product->get_permalink(),
				'variation_count'          => count( $variation_ids ),
				'variations_with_images'   => $variations_with_images,
			);
		}

		wp_send_json_success( $products );
	}

	/**
	 * AJAX: Get variations for a product
	 */
	public function ajax_get_variations() {
		// Rate limiting check (higher limit for read operations)
		$rate_limit = WCVIP_Rate_Limiter::check_rate_limit( 'wcvip_get_variations', 30, 60 );
		if ( is_wp_error( $rate_limit ) ) {
			WCVIP_Security_Logger::log(
				'rate_limit_exceeded',
				'Rate limit exceeded for wcvip_get_variations',
				array(
					'action' => 'wcvip_get_variations',
					'user_id' => get_current_user_id(),
				)
			);
			wp_send_json_error( array(
				'message' => $rate_limit->get_error_message(),
				'retry_after' => $rate_limit->get_error_data()['retry_after'],
			) );
		}

		// Check nonce and log failures
		if ( ! check_ajax_referer( 'wcvip-nonce', 'nonce', false ) ) {
			WCVIP_Security_Logger::log(
				'nonce_failed',
				'Failed nonce verification for wcvip_get_variations',
				array(
					'action' => 'wcvip_get_variations',
					'nonce' => isset( $_POST['nonce'] ) ? 'present' : 'missing',
				)
			);
			wp_send_json_error( array( 'message' => __( 'Security check failed', 'wc-variation-images-pro' ) ) );
		}

		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;

		if ( ! $product_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid product ID', 'wc-variation-images-pro' ) ) );
		}

		$product = wc_get_product( $product_id );

		if ( ! $product || ! $product->is_type( 'variable' ) ) {
			wp_send_json_error( array( 'message' => __( 'Product not found or not variable', 'wc-variation-images-pro' ) ) );
		}

		$variation_ids = $product->get_children();
		$variations    = array();

		foreach ( $variation_ids as $variation_id ) {
			$variation = wc_get_product( $variation_id );
			if ( ! $variation ) {
				continue;
			}

			$custom_images = get_post_meta( $variation_id, '_wcvip_images', true );
			if ( ! is_array( $custom_images ) ) {
				$custom_images = array();
			}

			$image_id = $variation->get_image_id();

			$variations[] = array(
				'id'               => $variation->get_id(),
				'attributes'       => $variation->get_variation_attributes(),
				'attributes_display' => wc_get_formatted_variation( $variation, true ),
				'image'            => $image_id ? wp_get_attachment_image_url( $image_id, 'thumbnail' ) : '',
				'image_id'         => $image_id,
				'sku'              => $variation->get_sku(),
				'price'            => $variation->get_price_html(),
				'custom_images'    => $custom_images,
				'image_count'      => count( $custom_images ),
			);
		}

		wp_send_json_success( $variations );
	}

	/**
	 * AJAX: Save variation images
	 */
	public function ajax_save_images() {
		// Rate limiting check
		$rate_limit = WCVIP_Rate_Limiter::check_rate_limit( 'wcvip_save_images', 20, 60 );
		if ( is_wp_error( $rate_limit ) ) {
			WCVIP_Security_Logger::log(
				'rate_limit_exceeded',
				'Rate limit exceeded for wcvip_save_images',
				array(
					'action' => 'wcvip_save_images',
					'user_id' => get_current_user_id(),
				)
			);
			wp_send_json_error( array(
				'message' => $rate_limit->get_error_message(),
				'retry_after' => $rate_limit->get_error_data()['retry_after'],
			) );
		}

		// Check nonce and log failures
		if ( ! check_ajax_referer( 'wcvip-nonce', 'nonce', false ) ) {
			WCVIP_Security_Logger::log(
				'nonce_failed',
				'Failed nonce verification for wcvip_save_images',
				array(
					'action' => 'wcvip_save_images',
					'nonce' => isset( $_POST['nonce'] ) ? 'present' : 'missing',
				)
			);
			wp_send_json_error( array( 'message' => __( 'Security check failed', 'wc-variation-images-pro' ) ) );
		}

		$variation_id = isset( $_POST['variation_id'] ) ? absint( $_POST['variation_id'] ) : 0;

		if ( ! $variation_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid variation ID', 'wc-variation-images-pro' ) ) );
		}

		// Verify variation exists and user can edit it
		$variation = wc_get_product( $variation_id );
		if ( ! $variation || ! current_user_can( 'edit_product', $variation_id ) ) {
			WCVIP_Security_Logger::log(
				'permission_denied',
				'User attempted to save images for variation without permission',
				array(
					'variation_id' => $variation_id,
					'user_id' => get_current_user_id(),
				)
			);
			wp_send_json_error( array( 'message' => __( 'Invalid variation or insufficient permissions', 'wc-variation-images-pro' ) ) );
		}

		// Decode and validate images JSON
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON data must be decoded before sanitization
		$images_raw = isset( $_POST['images'] ) ? wp_unslash( $_POST['images'] ) : '';
		$images = json_decode( $images_raw, true );

		// Validate JSON structure
		if ( json_last_error() !== JSON_ERROR_NONE ) {
			wp_send_json_error( array( 'message' => __( 'Invalid image data format', 'wc-variation-images-pro' ) ) );
		}

		// Validate images array
		if ( ! is_array( $images ) ) {
			$images = array();
		}

		// Sanitize images array elements
		$images = array_map( function( $image ) {
			if ( is_array( $image ) ) {
				return array(
					'id'        => isset( $image['id'] ) ? absint( $image['id'] ) : 0,
					'url'       => isset( $image['url'] ) ? esc_url_raw( $image['url'] ) : '',
					'thumbnail' => isset( $image['thumbnail'] ) ? esc_url_raw( $image['thumbnail'] ) : '',
					'alt'       => isset( $image['alt'] ) ? sanitize_text_field( $image['alt'] ) : '',
				);
			}
			return $image;
		}, $images );

		// Sanitize image data
		$sanitized_images = array();
		foreach ( $images as $image ) {
			if ( isset( $image['id'] ) && is_numeric( $image['id'] ) ) {
				$sanitized_images[] = array(
					'id'         => absint( $image['id'] ),
					'url'        => esc_url_raw( $image['url'] ),
					'thumbnail'  => isset( $image['thumbnail'] ) ? esc_url_raw( $image['thumbnail'] ) : '',
					'alt'        => isset( $image['alt'] ) ? sanitize_text_field( $image['alt'] ) : '',
					'is_primary' => isset( $image['is_primary'] ) ? (bool) $image['is_primary'] : false,
				);
			}
		}

		// Save images
		update_post_meta( $variation_id, '_wcvip_images', $sanitized_images );

		// Update variation's primary image if set
		if ( ! empty( $sanitized_images ) ) {
			$primary_image = null;
			foreach ( $sanitized_images as $image ) {
				if ( ! empty( $image['is_primary'] ) ) {
					$primary_image = $image;
					break;
				}
			}

			// If no primary set, use first image
			if ( ! $primary_image && ! empty( $sanitized_images[0] ) ) {
				$primary_image = $sanitized_images[0];
			}

			if ( $primary_image ) {
				update_post_meta( $variation_id, '_thumbnail_id', $primary_image['id'] );
			}
		}

		wp_send_json_success( array( 'message' => __( 'Images saved successfully', 'wc-variation-images-pro' ) ) );
	}

	/**
	 * AJAX: Get variation images
	 */
	public function ajax_get_images() {
		// Rate limiting check (higher limit for read operations)
		$rate_limit = WCVIP_Rate_Limiter::check_rate_limit( 'wcvip_get_images', 30, 60 );
		if ( is_wp_error( $rate_limit ) ) {
			WCVIP_Security_Logger::log(
				'rate_limit_exceeded',
				'Rate limit exceeded for wcvip_get_images',
				array(
					'action' => 'wcvip_get_images',
					'user_id' => get_current_user_id(),
				)
			);
			wp_send_json_error( array(
				'message' => $rate_limit->get_error_message(),
				'retry_after' => $rate_limit->get_error_data()['retry_after'],
			) );
		}

		// Check nonce and log failures
		if ( ! check_ajax_referer( 'wcvip-nonce', 'nonce', false ) ) {
			WCVIP_Security_Logger::log(
				'nonce_failed',
				'Failed nonce verification for wcvip_get_images',
				array(
					'action' => 'wcvip_get_images',
					'nonce' => isset( $_POST['nonce'] ) ? 'present' : 'missing',
				)
			);
			wp_send_json_error( array( 'message' => __( 'Security check failed', 'wc-variation-images-pro' ) ) );
		}

		$variation_id = isset( $_POST['variation_id'] ) ? absint( $_POST['variation_id'] ) : 0;

		if ( ! $variation_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid variation ID', 'wc-variation-images-pro' ) ) );
		}

		$custom_images = get_post_meta( $variation_id, '_wcvip_images', true );
		if ( ! is_array( $custom_images ) ) {
			$custom_images = array();
		}

		wp_send_json_success( $custom_images );
	}

	/**
	 * AJAX: Upload image file
	 */
	public function ajax_upload_image() {
		// Rate limiting check (lower limit for resource-intensive operation)
		$rate_limit = WCVIP_Rate_Limiter::check_rate_limit( 'wcvip_upload_image', 10, 60 );
		if ( is_wp_error( $rate_limit ) ) {
			WCVIP_Security_Logger::log(
				'rate_limit_exceeded',
				'Rate limit exceeded for wcvip_upload_image',
				array(
					'action' => 'wcvip_upload_image',
					'user_id' => get_current_user_id(),
				)
			);
			wp_send_json_error( array(
				'message' => $rate_limit->get_error_message(),
				'retry_after' => $rate_limit->get_error_data()['retry_after'],
			) );
		}

		// Check nonce and log failures
		if ( ! check_ajax_referer( 'wcvip-nonce', 'nonce', false ) ) {
			WCVIP_Security_Logger::log(
				'nonce_failed',
				'Failed nonce verification for wcvip_upload_image',
				array(
					'action' => 'wcvip_upload_image',
					'nonce' => isset( $_POST['nonce'] ) ? 'present' : 'missing',
				)
			);
			wp_send_json_error( array( 'message' => __( 'Security check failed', 'wc-variation-images-pro' ) ) );
		}

		// Check user capability
		if ( ! current_user_can( 'upload_files' ) ) {
			WCVIP_Security_Logger::log(
				'permission_denied',
				'User attempted to upload image without upload_files permission',
				array(
					'user_id' => get_current_user_id(),
				)
			);
			wp_send_json_error( array( 'message' => __( 'You do not have permission to upload files.', 'wc-variation-images-pro' ) ) );
		}

		// Check if file was uploaded
		if ( empty( $_FILES['file'] ) || ! isset( $_FILES['file']['name'] ) ) {
			wp_send_json_error( array( 'message' => __( 'No file uploaded.', 'wc-variation-images-pro' ) ) );
		}

		// Validate file type
		$file_name = sanitize_file_name( wp_unslash( $_FILES['file']['name'] ) );
		$file_type = wp_check_filetype( $file_name );
		if ( ! in_array( $file_type['type'], array( 'image/jpeg', 'image/png', 'image/gif', 'image/webp' ), true ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid file type. Only images are allowed.', 'wc-variation-images-pro' ) ) );
		}

		// Include WordPress file handling functions
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		// Handle file upload
		$attachment_id = media_handle_upload( 'file', 0 );

		if ( is_wp_error( $attachment_id ) ) {
			wp_send_json_error( array( 'message' => $attachment_id->get_error_message() ) );
		}

		// Get attachment data
		$attachment = wp_prepare_attachment_for_js( $attachment_id );

		if ( ! $attachment ) {
			wp_send_json_error( array( 'message' => __( 'Failed to process uploaded image.', 'wc-variation-images-pro' ) ) );
		}

		// Return attachment data in expected format
		wp_send_json_success( array(
			'id'        => $attachment_id,
			'url'       => $attachment['url'],
			'thumbnail' => isset( $attachment['sizes']['thumbnail'] ) ? $attachment['sizes']['thumbnail']['url'] : $attachment['url'],
			'alt'       => isset( $attachment['alt'] ) ? $attachment['alt'] : '',
			'sizes'     => isset( $attachment['sizes'] ) ? $attachment['sizes'] : array(),
		) );
	}

	/**
	 * AJAX: Get Visual Designer HTML
	 */
	public function ajax_get_designer_html() {
		// Rate limiting check (higher limit for read operations)
		$rate_limit = WCVIP_Rate_Limiter::check_rate_limit( 'wcvip_get_designer_html', 30, 60 );
		if ( is_wp_error( $rate_limit ) ) {
			WCVIP_Security_Logger::log(
				'rate_limit_exceeded',
				'Rate limit exceeded for wcvip_get_designer_html',
				array(
					'action' => 'wcvip_get_designer_html',
					'user_id' => get_current_user_id(),
				)
			);
			wp_send_json_error( array(
				'message' => $rate_limit->get_error_message(),
				'retry_after' => $rate_limit->get_error_data()['retry_after'],
			) );
		}

		// Check nonce and log failures
		if ( ! check_ajax_referer( 'wcvip-nonce', 'nonce', false ) ) {
			WCVIP_Security_Logger::log(
				'nonce_failed',
				'Failed nonce verification for wcvip_get_designer_html',
				array(
					'action' => 'wcvip_get_designer_html',
					'nonce' => isset( $_POST['nonce'] ) ? 'present' : 'missing',
				)
			);
			wp_send_json_error( array( 'message' => __( 'Security check failed', 'wc-variation-images-pro' ) ) );
		}

		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;

		if ( ! $product_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid product ID', 'wc-variation-images-pro' ) ) );
		}

		$product = wc_get_product( $product_id );
		if ( ! $product || ! $product->is_type( 'variable' ) ) {
			wp_send_json_error( array( 'message' => __( 'Product not found or not variable', 'wc-variation-images-pro' ) ) );
		}

		// Capture the Visual Designer HTML output
		ob_start();
		$designer = new WCVIP_Visual_Designer();
		$designer->render_designer( $product_id );
		$html = ob_get_clean();

		wp_send_json_success( array( 'html' => $html ) );
	}

	/**
	 * AJAX: Reset product to original state
	 */
	public function ajax_reset_product() {
		// Rate limiting check
		$rate_limit = WCVIP_Rate_Limiter::check_rate_limit( 'wcvip_reset_product', 10, 60 );
		if ( is_wp_error( $rate_limit ) ) {
			WCVIP_Security_Logger::log(
				'rate_limit_exceeded',
				'Rate limit exceeded for wcvip_reset_product',
				array(
					'action' => 'wcvip_reset_product',
					'user_id' => get_current_user_id(),
				)
			);
			wp_send_json_error( array(
				'message' => $rate_limit->get_error_message(),
				'retry_after' => $rate_limit->get_error_data()['retry_after'],
			) );
		}

		// Check nonce and log failures
		if ( ! check_ajax_referer( 'wcvip-nonce', 'nonce', false ) ) {
			WCVIP_Security_Logger::log(
				'nonce_failed',
				'Failed nonce verification for wcvip_reset_product',
				array(
					'action' => 'wcvip_reset_product',
					'nonce' => isset( $_POST['nonce'] ) ? 'present' : 'missing',
				)
			);
			wp_send_json_error( array( 'message' => __( 'Security check failed', 'wc-variation-images-pro' ) ) );
		}

		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;

		if ( ! $product_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid product ID', 'wc-variation-images-pro' ) ) );
		}

		$product = wc_get_product( $product_id );
		if ( ! $product || ! $product->is_type( 'variable' ) ) {
			wp_send_json_error( array( 'message' => __( 'Product not found or not variable', 'wc-variation-images-pro' ) ) );
		}

		// Verify user can edit this product
		if ( ! current_user_can( 'edit_product', $product_id ) ) {
			WCVIP_Security_Logger::log(
				'permission_denied',
				'User attempted to reset product without permission',
				array(
					'product_id' => $product_id,
					'user_id' => get_current_user_id(),
				)
			);
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions', 'wc-variation-images-pro' ) ) );
		}

		$variation_ids = $product->get_children();
		$reset_count = 0;

		// Remove custom images from all variations
		foreach ( $variation_ids as $variation_id ) {
			// Delete custom variation images meta
			delete_post_meta( $variation_id, '_wcvip_images' );
			$reset_count++;
		}

		// Reset product-level display style (if set)
		delete_post_meta( $product_id, '_wcvip_display_style' );
		
		// Reset designer layout (if set)
		delete_post_meta( $product_id, '_wcvip_designer_layout' );

		wp_send_json_success( array( 
			'message' => sprintf( 
				// translators: %d is the number of variations
				__( 'Product reset successfully. Removed custom images from %d variation(s).', 'wc-variation-images-pro' ), 
				$reset_count 
			) 
		) );
	}

	/**
	 * AJAX: Save display style
	 */
	public function ajax_save_display_style() {
		// Rate limiting check
		$rate_limit = WCVIP_Rate_Limiter::check_rate_limit( 'wcvip_save_display_style', 20, 60 );
		if ( is_wp_error( $rate_limit ) ) {
			WCVIP_Security_Logger::log(
				'rate_limit_exceeded',
				'Rate limit exceeded for wcvip_save_display_style',
				array(
					'action' => 'wcvip_save_display_style',
					'user_id' => get_current_user_id(),
				)
			);
			wp_send_json_error( array(
				'message' => $rate_limit->get_error_message(),
				'retry_after' => $rate_limit->get_error_data()['retry_after'],
			) );
		}

		// Check nonce and log failures
		if ( ! check_ajax_referer( 'wcvip-nonce', 'nonce', false ) ) {
			WCVIP_Security_Logger::log(
				'nonce_failed',
				'Failed nonce verification for wcvip_save_display_style',
				array(
					'action' => 'wcvip_save_display_style',
					'nonce' => isset( $_POST['nonce'] ) ? 'present' : 'missing',
				)
			);
			wp_send_json_error( array( 'message' => __( 'Security check failed', 'wc-variation-images-pro' ) ) );
		}

		$style = isset( $_POST['style'] ) ? sanitize_text_field( wp_unslash( $_POST['style'] ) ) : '';
		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;

		if ( empty( $style ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid style', 'wc-variation-images-pro' ) ) );
		}

		// Check if style is Pro-only for free users (Pro version only - testing option removed for free version)
		$pro_enabled = WCVIP_IS_PRO;
		
		$pro_styles = array( 'circular', 'rectangular', 'grid', 'strip', 'radio', 'custom', 'slider', 'carousel', 'gallery', 'hover', 'zoom' );
		if ( ! $pro_enabled && in_array( $style, $pro_styles, true ) ) {
			wp_send_json_error( array( 'message' => __( 'This style is available in Pro version only', 'wc-variation-images-pro' ) ) );
		}

		// Save style globally or per product
		if ( $product_id ) {
			$saved = update_post_meta( $product_id, '_wcvip_display_style', $style );
			wp_send_json_success( array( 
				'message' => __( 'Display style saved to product', 'wc-variation-images-pro' ),
				'product_id' => $product_id,
				'style' => $style,
				'saved' => $saved
			) );
		} else {
			update_option( 'wcvip_display_style', $style );
			wp_send_json_success( array( 
				'message' => __( 'Display style saved globally', 'wc-variation-images-pro' ),
				'style' => $style
			) );
		}
	}

	/**
	 * Add color field to attribute term add form
	 */
	public function add_attribute_term_color_field( $taxonomy ) {
		// Only show on WooCommerce attribute taxonomies
		if ( ! $this->is_wc_attribute_taxonomy( $taxonomy ) ) {
			return;
		}
		?>
		<div class="form-field">
			<label for="wcvip_color"><?php esc_html_e( 'Color (Hex)', 'wc-variation-images-pro' ); ?></label>
			<input type="text" name="wcvip_color" id="wcvip_color" value="" class="wcvip-color-picker" />
			<p class="description"><?php esc_html_e( 'Color hex code (e.g., #ff0000) for color swatches display. Leave empty to auto-detect from name.', 'wc-variation-images-pro' ); ?></p>
		</div>
		<?php
	}

	/**
	 * Add color field to attribute term edit form
	 */
	public function edit_attribute_term_color_field( $term, $taxonomy ) {
		// Only show on WooCommerce attribute taxonomies
		if ( ! $this->is_wc_attribute_taxonomy( $taxonomy ) ) {
			return;
		}

		$color_value = get_term_meta( $term->term_id, 'wcvip_color', true );
		?>
		<tr class="form-field">
			<th scope="row">
				<label for="wcvip_color"><?php esc_html_e( 'Color (Hex)', 'wc-variation-images-pro' ); ?></label>
			</th>
			<td>
				<input type="text" name="wcvip_color" id="wcvip_color" value="<?php echo esc_attr( $color_value ); ?>" class="wcvip-color-picker" />
				<p class="description"><?php esc_html_e( 'Color hex code (e.g., #ff0000) for color swatches display. Leave empty to auto-detect from name.', 'wc-variation-images-pro' ); ?></p>
			</td>
		</tr>
		<?php
	}

	/**
	 * Save attribute term color
	 */
	public function save_attribute_term_color( $term_id ) {
		// Verify nonce for term edit/create form
		if ( isset( $_POST['wcvip_color'] ) ) {
			// Check nonce for both term creation and editing
			$action = isset( $_POST['action'] ) ? sanitize_text_field( wp_unslash( $_POST['action'] ) ) : '';
			$nonce_action = 'add-tag' === $action ? 'add-tag' : 'update-tag_' . $term_id;
			check_admin_referer( $nonce_action );
			$color = sanitize_text_field( wp_unslash( $_POST['wcvip_color'] ) );
			// Validate hex color format
			if ( ! empty( $color ) && ! preg_match( '/^#[a-f0-9]{6}$/i', $color ) ) {
				// Try to add # if missing
				if ( preg_match( '/^[a-f0-9]{6}$/i', $color ) ) {
					$color = '#' . $color;
				} else {
					$color = ''; // Invalid format, clear it
				}
			}
			update_term_meta( $term_id, 'wcvip_color', $color );
		}
	}

	/**
	 * Check if taxonomy is a WooCommerce attribute taxonomy
	 */
	private function is_wc_attribute_taxonomy( $taxonomy ) {
		return strpos( $taxonomy, 'pa_' ) === 0;
	}

	/**
	 * Register attribute term color field hooks for all WC attribute taxonomies
	 */
	public function register_attribute_term_color_hooks() {
		$attribute_taxonomies = wc_get_attribute_taxonomies();
		
		if ( empty( $attribute_taxonomies ) ) {
			return;
		}

		foreach ( $attribute_taxonomies as $attribute ) {
			$taxonomy = wc_attribute_taxonomy_name( $attribute->attribute_name );
			
			// Add form fields
			add_action( $taxonomy . '_add_form_fields', array( $this, 'add_attribute_term_color_field' ) );
			add_action( $taxonomy . '_edit_form_fields', array( $this, 'edit_attribute_term_color_field' ), 10, 2 );
			
			// Save handlers
			add_action( 'created_' . $taxonomy, array( $this, 'save_attribute_term_color' ) );
			add_action( 'edited_' . $taxonomy, array( $this, 'save_attribute_term_color' ) );
		}
	}
}


