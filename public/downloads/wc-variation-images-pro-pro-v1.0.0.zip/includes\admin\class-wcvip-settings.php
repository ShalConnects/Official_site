<?php
/**
 * Settings page for the plugin
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings class
 */
class WCVIP_Settings {

	/**
	 * Register settings
	 */
	public function register_settings() {
		register_setting( 'wcvip_settings', 'wcvip_display_style', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'wcvip_settings', 'wcvip_lazy_load', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'wcvip_settings', 'wcvip_show_badge', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'wcvip_settings', 'wcvip_image_limit', array( 'sanitize_callback' => 'absint' ) );
		
		// Multi-attribute display settings
		register_setting( 'wcvip_settings', 'wcvip_use_attribute_sections', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'wcvip_settings', 'wcvip_out_of_stock_action', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'wcvip_settings', 'wcvip_attribute_styles', array( 'sanitize_callback' => 'sanitize_textarea_field' ) );
		
		// Frontend display location settings
		register_setting( 'wcvip_settings', 'wcvip_display_in_dropdown', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'wcvip_settings', 'wcvip_display_thumbnails', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		
		if ( WCVIP_IS_PRO ) {
			register_setting( 'wcvip_settings', 'wcvip_cdn_enabled', array( 'sanitize_callback' => 'sanitize_text_field' ) );
			register_setting( 'wcvip_settings', 'wcvip_cdn_url', array( 'sanitize_callback' => 'esc_url_raw' ) );
		}

		add_settings_section(
			'wcvip_general_section',
			__( 'General Settings', 'wc-variation-images-pro' ),
			array( $this, 'render_general_section' ),
			'wcvip_settings'
		);

		add_settings_field(
			'wcvip_display_style',
			__( 'Display Style', 'wc-variation-images-pro' ),
			array( $this, 'render_display_style_field' ),
			'wcvip_settings',
			'wcvip_general_section'
		);


		add_settings_field(
			'wcvip_lazy_load',
			__( 'Lazy Loading', 'wc-variation-images-pro' ),
			array( $this, 'render_lazy_load_field' ),
			'wcvip_settings',
			'wcvip_general_section'
		);

		// Multi-attribute display section
		add_settings_section(
			'wcvip_multi_attribute_section',
			__( 'Multi-Attribute Display', 'wc-variation-images-pro' ),
			array( $this, 'render_multi_attribute_section' ),
			'wcvip_settings'
		);

		add_settings_field(
			'wcvip_use_attribute_sections',
			__( 'Display Format', 'wc-variation-images-pro' ),
			array( $this, 'render_use_attribute_sections_field' ),
			'wcvip_settings',
			'wcvip_multi_attribute_section'
		);

		add_settings_field(
			'wcvip_out_of_stock_action',
			__( 'Out of Stock Variations', 'wc-variation-images-pro' ),
			array( $this, 'render_out_of_stock_action_field' ),
			'wcvip_settings',
			'wcvip_multi_attribute_section'
		);

		// Hide per-attribute styles setting - functionality is in Visual Designer canvas area
		// add_settings_field(
		// 	'wcvip_attribute_styles',
		// 	__( 'Per-Attribute Styles', 'wc-variation-images-pro' ),
		// 	array( $this, 'render_attribute_styles_field' ),
		// 	'wcvip_settings',
		// 	'wcvip_multi_attribute_section'
		// );

		// Hide branding badge setting for now - can be enabled later
		// if ( ! WCVIP_IS_PRO ) {
		// 	add_settings_field(
		// 		'wcvip_show_badge',
		// 		__( 'Show Branding Badge', 'wc-variation-images-pro' ),
		// 		array( $this, 'render_show_badge_field' ),
		// 		'wcvip_settings',
		// 		'wcvip_general_section'
		// 	);
		// }

		// Hide Frontend Display Locations section for now - can be enabled later
		// Frontend display locations section
		// add_settings_section(
		// 	'wcvip_display_locations_section',
		// 	__( 'Frontend Display Locations', 'wc-variation-images-pro' ),
		// 	array( $this, 'render_display_locations_section' ),
		// 	'wcvip_settings'
		// );

		// add_settings_field(
		// 	'wcvip_display_locations',
		// 	__( 'Where to Display Images', 'wc-variation-images-pro' ),
		// 	array( $this, 'render_display_locations_field' ),
		// 	'wcvip_settings',
		// 	'wcvip_display_locations_section'
		// );
	}

	/**
	 * Add settings page
	 */
	public function add_settings_page() {
		// Already added as submenu in WCVIP_Admin
	}

	/**
	 * Render general section
	 */
	public function render_general_section() {
		echo '<p>' . esc_html__( 'Configure how variation images are displayed on the frontend.', 'wc-variation-images-pro' ) . '</p>';
	}

	/**
	 * Render display style field
	 */
	public function render_display_style_field() {
		$value = get_option( 'wcvip_display_style', 'none' );
		
		// Free styles always available (matching Visual Designer)
		$free_styles = array(
			'horizontal_text' => __( 'Horizontal Text Boxes', 'wc-variation-images-pro' ),
			'vertical_text'   => __( 'Vertical Text List', 'wc-variation-images-pro' ),
			'color_swatches'  => __( 'Color Swatches', 'wc-variation-images-pro' ),
		);

		// Pro styles: show as preview even in free version (non-functional)
		$pro_styles = array();
		if ( class_exists( 'WCVIP_Pro_Styles' ) ) {
			// Pro version - fully functional
			$pro_styles = WCVIP_Pro_Styles::get_pro_styles();
		} else {
			// Free version - show as preview only
			$pro_styles = array(
				'buttons'           => __( 'Button Style (Image First)', 'wc-variation-images-pro' ) . ' ⭐ Pro',
				'buttons_text_first' => __( 'Button Style (Text First)', 'wc-variation-images-pro' ) . ' ⭐ Pro',
				'square'            => __( 'Square Thumbnails', 'wc-variation-images-pro' ) . ' ⭐ Pro',
				'circular'          => __( 'Circular Thumbnails', 'wc-variation-images-pro' ) . ' ⭐ Pro',
			);
		}

		// Keep basic option for backward compatibility
		if ( 'basic' === $value ) {
			$value = 'square';
		}

		// Backward compatibility: convert old button style variants to new canvas style
		if ( in_array( $value, array( 'buttons_vertical', 'buttons_horizontal', 'buttons_text_first_vertical', 'buttons_text_first_horizontal' ), true ) ) {
			// Map old variants to new canvas styles
			if ( in_array( $value, array( 'buttons_vertical', 'buttons_horizontal' ), true ) ) {
				$value = 'buttons';
			} elseif ( in_array( $value, array( 'buttons_text_first_vertical', 'buttons_text_first_horizontal' ), true ) ) {
				$value = 'buttons_text_first';
			}
		}

		// Backward compatibility: if current value is not in new list, add it to preserve existing selections
		$legacy_styles = array(
			'buttons'     => __( 'Button Style', 'wc-variation-images-pro' ), // Will be converted above
			'dropdown'    => __( 'Dropdown with Images', 'wc-variation-images-pro' ),
			'vertical'     => __( 'Vertical List', 'wc-variation-images-pro' ),
			'rectangular' => __( 'Rectangular with Labels', 'wc-variation-images-pro' ),
			'grid'        => __( 'Grid Layout', 'wc-variation-images-pro' ),
			'strip'       => __( 'Horizontal Strip', 'wc-variation-images-pro' ),
			'radio'       => __( 'Radio Buttons with Images', 'wc-variation-images-pro' ),
			// Removed unused styles: custom, slider, carousel, gallery, hover, zoom (not implemented)
		);
		
		// If current value is a legacy style, add it to the appropriate group for backward compatibility
		if ( isset( $legacy_styles[ $value ] ) && $value !== 'buttons' ) {
			if ( ! isset( $free_styles[ $value ] ) && ! isset( $pro_styles[ $value ] ) ) {
				// Add to free group for backward compatibility
				$free_styles[ $value ] = $legacy_styles[ $value ];
			}
		}

		?>
		<select name="wcvip_display_style" id="wcvip_display_style">
			<option value="none" <?php selected( $value, 'none' ); ?>>
				<?php esc_html_e( 'No option (default)', 'wc-variation-images-pro' ); ?>
			</option>
			<?php if ( ! empty( $free_styles ) ) : ?>
				<optgroup label="<?php esc_attr_e( 'Available Styles', 'wc-variation-images-pro' ); ?>">
					<?php foreach ( $free_styles as $key => $label ) : ?>
						<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $value, $key ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</optgroup>
			<?php endif; ?>
			
			<?php if ( ! empty( $pro_styles ) ) : ?>
				<optgroup label="<?php esc_attr_e( 'Pro Styles (Preview)', 'wc-variation-images-pro' ); ?>">
					<?php foreach ( $pro_styles as $key => $label ) : ?>
						<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $value, $key ); ?> <?php disabled( ! class_exists( 'WCVIP_Pro_Styles' ) ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</optgroup>
			<?php endif; ?>
		</select>
		<p class="description">
			<?php esc_html_e( 'Default display style for all products. Select "No option (default)" to use WooCommerce default variation selector. Individual products can override this using the Visual Designer.', 'wc-variation-images-pro' ); ?>
			<?php if ( ! class_exists( 'WCVIP_Pro_Styles' ) ) : ?>
				<br><small><?php esc_html_e( 'Pro styles are shown for preview only. Upgrade to Pro to unlock all styles.', 'wc-variation-images-pro' ); ?></small>
			<?php endif; ?>
		</p>
		<?php
	}


	/**
	 * Render lazy load field
	 */
	public function render_lazy_load_field() {
		$value = get_option( 'wcvip_lazy_load', 'yes' );
		?>
		<label>
			<input type="checkbox" name="wcvip_lazy_load" value="yes" <?php checked( $value, 'yes' ); ?>>
			<?php esc_html_e( 'Enable lazy loading for variation images', 'wc-variation-images-pro' ); ?>
		</label>
		<p class="description">
			<?php esc_html_e( 'Images will load only when they are about to enter the viewport, improving page load performance.', 'wc-variation-images-pro' ); ?>
		</p>
		<?php
	}

	/**
	 * Render show badge field
	 */
	public function render_show_badge_field() {
		$value = get_option( 'wcvip_show_badge', 'yes' );
		?>
		<label>
			<input type="checkbox" name="wcvip_show_badge" value="yes" <?php checked( $value, 'yes' ); ?>>
			<?php esc_html_e( 'Show "Powered by" badge on product pages', 'wc-variation-images-pro' ); ?>
		</label>
		<?php
	}

	/**
	 * Render display locations section
	 */
	public function render_display_locations_section() {
		echo '<p>' . esc_html__( 'Choose where variation images should appear on the product page. These options work alongside the Visual Designer variation selector. You can select multiple locations.', 'wc-variation-images-pro' ) . '</p>';
	}

	/**
	 * Render display locations field
	 */
	public function render_display_locations_field() {
		$in_dropdown = get_option( 'wcvip_display_in_dropdown', 'no' );
		$thumbnails = get_option( 'wcvip_display_thumbnails', 'yes' );
		?>
		<fieldset>
			<label>
				<input type="checkbox" name="wcvip_display_in_dropdown" value="yes" <?php checked( $in_dropdown, 'yes' ); ?>>
				<strong><?php esc_html_e( 'In Variation Dropdown', 'wc-variation-images-pro' ); ?></strong>
				<p class="description"><?php esc_html_e( 'Show images inside the WooCommerce variation dropdown selector. This works alongside the main variation selector.', 'wc-variation-images-pro' ); ?></p>
			</label>
			<br><br>
			
			<label>
				<input type="checkbox" name="wcvip_display_thumbnails" value="yes" <?php checked( $thumbnails, 'yes' ); ?>>
				<strong><?php esc_html_e( 'Thumbnail Strip', 'wc-variation-images-pro' ); ?></strong>
				<p class="description"><?php esc_html_e( 'Display thumbnail navigation strip below the main product image gallery. Shows all images for the selected variation. Works alongside the variation selector.', 'wc-variation-images-pro' ); ?></p>
			</label>
			<p class="description" style="margin-top: 10px;">
				<em><?php esc_html_e( 'Note: Main gallery image swap is always enabled and cannot be disabled.', 'wc-variation-images-pro' ); ?></em>
			</p>
		</fieldset>
		<?php
	}

	/**
	 * Render multi-attribute section
	 */
	public function render_multi_attribute_section() {
		echo '<p>' . esc_html__( 'Configure how products with multiple attributes (e.g., Color + Size) are displayed on the frontend.', 'wc-variation-images-pro' ) . '</p>';
	}

	/**
	 * Render use attribute sections field
	 */
	public function render_use_attribute_sections_field() {
		$value = get_option( 'wcvip_use_attribute_sections', 'no' );
		?>
		<label>
			<input type="radio" name="wcvip_use_attribute_sections" value="no" <?php checked( $value, 'no' ); ?>>
			<strong><?php esc_html_e( 'Grouped Format (Default)', 'wc-variation-images-pro' ); ?></strong>
			<p class="description"><?php esc_html_e( 'Variations are grouped by primary attribute with collapsible sections. This is the current default behavior.', 'wc-variation-images-pro' ); ?></p>
		</label>
		<br><br>
		<label>
			<input type="radio" name="wcvip_use_attribute_sections" value="yes" <?php checked( $value, 'yes' ); ?>>
			<strong><?php esc_html_e( 'Separate Attribute Sections', 'wc-variation-images-pro' ); ?></strong>
			<p class="description"><?php esc_html_e( 'Each attribute gets its own section. Users select one value from each section to build the complete variation. Allows different display styles per attribute.', 'wc-variation-images-pro' ); ?></p>
		</label>
		<?php
	}

	/**
	 * Render out of stock action field
	 * Hidden for now - can be enabled later
	 */
	public function render_out_of_stock_action_field() {
		$value = get_option( 'wcvip_out_of_stock_action', 'disable' );
		?>
		<select name="wcvip_out_of_stock_action">
			<option value="disable" <?php selected( $value, 'disable' ); ?>><?php esc_html_e( 'Disable (Show but grayed out)', 'wc-variation-images-pro' ); ?></option>
			<option value="hide" <?php selected( $value, 'hide' ); ?>><?php esc_html_e( 'Hide (Completely remove)', 'wc-variation-images-pro' ); ?></option>
		</select>
		<p class="description"><?php esc_html_e( 'How to handle out of stock variations. "Disable" shows them but makes them unclickable. "Hide" completely removes them from view.', 'wc-variation-images-pro' ); ?></p>
		<?php
	}

	/**
	 * Render attribute styles field
	 */
	public function render_attribute_styles_field() {
		$attribute_styles = get_option( 'wcvip_attribute_styles', array() );
		// Pro features only available in Pro version (testing option removed for free version)
		$pro_enabled = WCVIP_IS_PRO;
		
		// Available styles
		$available_styles = array(
			'horizontal_text' => __( 'Horizontal Text Boxes', 'wc-variation-images-pro' ),
			'vertical_text'   => __( 'Vertical Text List', 'wc-variation-images-pro' ),
			'color_swatches'  => __( 'Color Swatches', 'wc-variation-images-pro' ),
		);
		
		if ( $pro_enabled ) {
			$available_styles['square'] = __( 'Square Thumbnails', 'wc-variation-images-pro' );
			$available_styles['circular'] = __( 'Circular Thumbnails', 'wc-variation-images-pro' );
			$available_styles['buttons_vertical'] = __( 'Button Style (Vertical)', 'wc-variation-images-pro' );
			$available_styles['buttons_horizontal'] = __( 'Button Style (Horizontal)', 'wc-variation-images-pro' );
		}
		
		$default_style = get_option( 'wcvip_display_style', 'horizontal_text' );
		?>
		<div id="wcvip-attribute-styles-container">
			<p class="description">
				<?php esc_html_e( 'Configure display style for each attribute. Leave empty to use the default display style. Styles are applied when "Separate Attribute Sections" format is enabled.', 'wc-variation-images-pro' ); ?>
			</p>
			<p class="description">
				<strong><?php esc_html_e( 'Note:', 'wc-variation-images-pro' ); ?></strong>
				<?php esc_html_e( 'Attribute styles are configured per product in the Visual Designer. Global defaults can be set here, but product-specific settings take precedence.', 'wc-variation-images-pro' ); ?>
			</p>
			<p class="description">
				<?php esc_html_e( 'Default style:', 'wc-variation-images-pro' ); ?>
				<strong><?php echo esc_html( isset( $available_styles[ $default_style ] ) ? $available_styles[ $default_style ] : $default_style ); ?></strong>
			</p>
		</div>
		<?php
	}
}

