<?php
/**
 * Product page functionality
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Product page class
 */
class WCVIP_Product_Page {

	/**
	 * Check if preview mode is active
	 */
	private function is_preview_mode() {
		if ( ! is_product() ) {
			return false;
		}

		// Check if preview parameters exist
		if ( ! isset( $_GET['wcvip_preview'] ) || 'true' !== $_GET['wcvip_preview'] ) {
			return false;
		}

		// Verify nonce
		if ( ! isset( $_GET['wcvip_nonce'] ) ) {
			return false;
		}

		global $product;
		if ( ! $product ) {
			return false;
		}

		$product_id = $product->get_id();
		$nonce = isset( $_GET['wcvip_nonce'] ) ? sanitize_text_field( wp_unslash( $_GET['wcvip_nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'wcvip-preview-' . $product_id ) ) {
			return false;
		}

		// Check user capabilities
		if ( ! current_user_can( 'edit_products' ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Display preview banner at top of product page
	 */
	public function render_preview_banner() {
		if ( ! $this->is_preview_mode() ) {
			return;
		}

		global $product;
		if ( ! $product ) {
			return;
		}

		$product_id = $product->get_id();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Preview mode is for admin users only, verified in is_preview_mode()
		$preview_style = isset( $_GET['wcvip_style'] ) ? sanitize_text_field( wp_unslash( $_GET['wcvip_style'] ) ) : 'square';
		$style_names = array(
			'square' => __( 'Square Thumbnails', 'wc-variation-images-pro' ),
			'circular' => __( 'Circular Thumbnails', 'wc-variation-images-pro' ),
			'buttons' => __( 'Button Style', 'wc-variation-images-pro' ),
		);
		$style_name = isset( $style_names[ $preview_style ] ) ? $style_names[ $preview_style ] : ucfirst( $preview_style );
		$clean_url = remove_query_arg( array( 'wcvip_preview', 'wcvip_style', 'wcvip_nonce' ), get_permalink( $product_id ) );

		?>
		<div class="wcvip-preview-banner">
			<div class="wcvip-preview-banner-content">
				<div class="wcvip-preview-banner-info">
					<span class="wcvip-preview-banner-info-item">
						<strong>
							<span class="wcvip-preview-banner-icon">👁</span>
							<?php esc_html_e( 'Preview Mode', 'wc-variation-images-pro' ); ?>
						</strong>
					</span>
					<span class="wcvip-preview-banner-separator">•</span>
					<span class="wcvip-preview-banner-info-item">
						<span class="wcvip-preview-banner-icon">🎨</span>
						<?php 
						// translators: %s is the display style name
						echo esc_html( sprintf( __( 'Display Style: %s', 'wc-variation-images-pro' ), $style_name ) ); 
						?>
					</span>
					<span class="wcvip-preview-banner-separator">•</span>
					<span class="wcvip-preview-banner-note"><?php esc_html_e( 'Design not saved yet', 'wc-variation-images-pro' ); ?></span>
				</div>
				<div class="wcvip-preview-banner-actions">
					<button type="button" class="button button-primary wcvip-save-design" data-product-id="<?php echo esc_attr( $product_id ); ?>" data-style="<?php echo esc_attr( $preview_style ); ?>">
						<?php esc_html_e( 'Save Design', 'wc-variation-images-pro' ); ?>
					</button>
					<button type="button" class="wcvip-preview-close" aria-label="<?php esc_attr_e( 'Close Preview', 'wc-variation-images-pro' ); ?>" data-clean-url="<?php echo esc_url( $clean_url ); ?>">
						<span class="wcvip-close-icon">×</span>
					</button>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Add variation images to JSON data
	 */
	public function add_variation_images_to_json( $variation_data, $product, $variation ) {
		$variation_id = $variation->get_id();

		// Get custom images
		$custom_images = get_post_meta( $variation_id, '_wcvip_images', true );

		if ( ! empty( $custom_images ) && is_array( $custom_images ) ) {
			// Process images for frontend
			$processed_images = array();

			foreach ( $custom_images as $image ) {
				$image_id = isset( $image['id'] ) ? absint( $image['id'] ) : 0;

				if ( $image_id && wp_attachment_is_image( $image_id ) ) {
					$processed_images[] = array(
						'id'         => $image_id,
						'url'        => isset( $image['url'] ) ? esc_url( $image['url'] ) : wp_get_attachment_image_url( $image_id, 'full' ),
						'src'        => wp_get_attachment_image_url( $image_id, 'woocommerce_single' ),
						'srcset'     => wp_get_attachment_image_srcset( $image_id, 'woocommerce_single' ),
						'sizes'      => wp_get_attachment_image_sizes( $image_id, 'woocommerce_single' ),
						'thumbnail'  => wp_get_attachment_image_url( $image_id, 'thumbnail' ),
						'alt'        => isset( $image['alt'] ) ? esc_attr( $image['alt'] ) : get_post_meta( $image_id, '_wp_attachment_image_alt', true ),
						'is_primary' => isset( $image['is_primary'] ) ? (bool) $image['is_primary'] : false,
					);
				}
			}

			if ( ! empty( $processed_images ) ) {
				$variation_data['wcvip_images'] = $processed_images;

				// Set primary image for variation
				$primary_image = null;
				foreach ( $processed_images as $image ) {
					if ( ! empty( $image['is_primary'] ) ) {
						$primary_image = $image;
						break;
					}
				}

				// If no primary set, use first image
				if ( ! $primary_image && ! empty( $processed_images[0] ) ) {
					$primary_image = $processed_images[0];
				}

				if ( $primary_image ) {
					$variation_data['image'] = array(
						'id'    => $primary_image['id'],
						'src'   => $primary_image['src'],
						'srcset' => $primary_image['srcset'],
						'sizes' => $primary_image['sizes'],
					);
				}
			}
		} else {
			// Fallback to WooCommerce default variation image
			$image_id = $variation->get_image_id();
			if ( $image_id ) {
				$variation_data['wcvip_images'] = array(
					array(
						'id'         => $image_id,
						'url'        => wp_get_attachment_image_url( $image_id, 'full' ),
						'src'        => wp_get_attachment_image_url( $image_id, 'woocommerce_single' ),
						'srcset'     => wp_get_attachment_image_srcset( $image_id, 'woocommerce_single' ),
						'sizes'      => wp_get_attachment_image_sizes( $image_id, 'woocommerce_single' ),
						'thumbnail'  => wp_get_attachment_image_url( $image_id, 'thumbnail' ),
						'alt'        => get_post_meta( $image_id, '_wp_attachment_image_alt', true ),
						'is_primary' => true,
					),
				);
			}
		}

		return $variation_data;
	}

	/**
	 * Display variation gallery (Pro feature)
	 */
	public function display_variation_gallery() {
		if ( ! WCVIP_IS_PRO ) {
			return;
		}

		// Pro gallery display logic
		$display_style = get_option( 'wcvip_display_style', 'basic' );

		if ( 'gallery' === $display_style ) {
			// Display gallery with thumbnails
		}
	}

	/**
	 * Render custom variation selector before variations form
	 * Uses WooCommerce hook for maximum compatibility
	 */
	public function render_custom_variation_selector() {
		global $product;

		if ( ! $product || ! $product->is_type( 'variable' ) ) {
			return;
		}

		$display_style = get_option( 'wcvip_display_style', 'none' );
		
		// Override style if in preview mode
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Preview mode is for admin users only, verified in is_preview_mode()
		if ( $this->is_preview_mode() && isset( $_GET['wcvip_style'] ) ) {
			$display_style = sanitize_text_field( wp_unslash( $_GET['wcvip_style'] ) );
		}
		
		// Get product-specific style if set (but not in preview mode)
		if ( ! $this->is_preview_mode() ) {
			$product_style = get_post_meta( $product->get_id(), '_wcvip_display_style', true );
			// Debug logging (remove after testing)
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug code properly guarded by WP_DEBUG
				error_log( 'WCVIP Frontend: Product ID = ' . $product->get_id() );
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug code properly guarded by WP_DEBUG
				error_log( 'WCVIP Frontend: Global style = ' . $display_style );
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log,WordPress.PHP.DevelopmentFunctions.error_log_var_export -- Debug code properly guarded by WP_DEBUG
				error_log( 'WCVIP Frontend: Product meta value = ' . var_export( $product_style, true ) );
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug code properly guarded by WP_DEBUG
				error_log( 'WCVIP Frontend: Product meta empty? = ' . ( empty( $product_style ) ? 'yes' : 'no' ) );
			}
			if ( ! empty( $product_style ) ) {
				$display_style = $product_style;
				if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
					// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug code properly guarded by WP_DEBUG
					error_log( 'WCVIP Frontend: Using product-specific style = ' . $display_style );
				}
			} else {
				if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
					// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug code properly guarded by WP_DEBUG
					error_log( 'WCVIP Frontend: Using global style = ' . $display_style );
				}
			}
		}

		// Don't render if style is 'none' or 'dropdown' (uses default WooCommerce dropdown)
		if ( 'none' === $display_style || 'dropdown' === $display_style ) {
			return;
		}
		
		// Pro features only available in Pro version (testing option removed for free version)
		$pro_enabled_for_render = WCVIP_IS_PRO;
		
		// Check if Pro style is selected but user is on free version
		$pro_styles = array( 'circular', 'rectangular', 'grid', 'strip', 'radio', 'custom', 'slider', 'carousel', 'gallery', 'hover', 'zoom' );
		if ( ! $pro_enabled_for_render && in_array( $display_style, $pro_styles, true ) ) {
			$display_style = 'square';
		}

		// Text-based styles don't require images
		$text_based_styles = array( 'horizontal_text', 'vertical_text' );
		$requires_images = ! in_array( $display_style, $text_based_styles, true );

		// Get all variations (with or without images depending on style)
		$variations_data = $this->get_variations_with_images( $product, $requires_images );

		if ( empty( $variations_data ) ) {
			return;
		}

		// Check if attribute sections format is enabled
		$use_attribute_sections = get_option( 'wcvip_use_attribute_sections', 'no' );
		$attribute_count = ! empty( $variations_data[0]['attribute_count'] ) ? $variations_data[0]['attribute_count'] : 1;
		
		// Use attribute sections format if enabled and product has multiple attributes
		if ( 'yes' === $use_attribute_sections && $attribute_count > 1 ) {
			?>
			<div class="wcvip-variation-selector wcvip-attribute-sections" data-style="<?php echo esc_attr( $display_style ); ?>" data-product-id="<?php echo esc_attr( $product->get_id() ); ?>" data-variations="<?php echo esc_attr( json_encode( $variations_data ) ); ?>">
				<?php $this->render_attribute_sections_selector( $variations_data, $display_style ); ?>
			</div>
			<?php
		} else {
		?>
		<div class="wcvip-variation-selector" data-style="<?php echo esc_attr( $display_style ); ?>" data-product-id="<?php echo esc_attr( $product->get_id() ); ?>">
			<?php $this->render_style_selector( $display_style, $variations_data ); ?>
		</div>
		<?php
		}
	}

	/**
	 * Get all variations with their images
	 * 
	 * @param WC_Product_Variable $product The variable product
	 * @param bool $requires_images Whether to skip variations without images
	 * @return array Array of variation data
	 */
	private function get_variations_with_images( $product, $requires_images = true ) {
		$variations_data = array();
		$variation_ids = $product->get_children();

		foreach ( $variation_ids as $variation_id ) {
			$variation = wc_get_product( $variation_id );
			if ( ! $variation ) {
				continue;
			}

			$custom_images = get_post_meta( $variation_id, '_wcvip_images', true );
			if ( ! is_array( $custom_images ) || empty( $custom_images ) ) {
				// Use default variation image if no custom images
				$image_id = $variation->get_image_id();
				if ( $image_id ) {
					$custom_images = array(
						array(
							'id'        => $image_id,
							'url'       => wp_get_attachment_image_url( $image_id, 'full' ),
							'thumbnail' => wp_get_attachment_image_url( $image_id, 'thumbnail' ),
							'alt'       => get_post_meta( $image_id, '_wp_attachment_image_alt', true ),
						),
					);
				} else {
					// If style requires images, skip variations without images
					if ( $requires_images ) {
						continue;
					}
					// Otherwise, use empty array for text-based styles
					$custom_images = array();
				}
			}

			$attributes = $variation->get_variation_attributes();
			$variation_name = wc_get_formatted_variation( $variation, true );

			$variations_data[] = array(
				'variation_id' => $variation_id,
				'attributes'  => $attributes,
				'name'        => $variation_name,
				'images'      => $custom_images,
				'price'       => $variation->get_price_html(),
				'available'   => $variation->is_in_stock(),
			);
		}

		// Filter out out-of-stock variations if setting is "hide"
		$out_of_stock_action = get_option( 'wcvip_out_of_stock_action', 'disable' );
		if ( 'hide' === $out_of_stock_action ) {
			$variations_data = array_filter( $variations_data, function( $variation ) {
				return $variation['available'];
			} );
			// Re-index array after filtering
			$variations_data = array_values( $variations_data );
		}

		// Add attribute metadata to each variation (after all variations are collected)
		if ( ! empty( $variations_data ) ) {
			$attribute_count = WCVIP_Attribute_Helper::count_attributes( $variations_data );
			$primary_attribute = WCVIP_Attribute_Helper::get_primary_attribute( $variations_data );
			$secondary_attributes = WCVIP_Attribute_Helper::get_secondary_attributes( $variations_data );
			$display_strategy = WCVIP_Attribute_Helper::get_display_strategy( $variations_data );

			foreach ( $variations_data as &$variation_data ) {
				$variation_data['attribute_count'] = $attribute_count;
				$variation_data['primary_attribute'] = $primary_attribute;
				$variation_data['secondary_attributes'] = $secondary_attributes;
				$variation_data['display_strategy'] = $display_strategy;
			}
			unset( $variation_data ); // Break reference
		}

		return $variations_data;
	}

	/**
	 * Get lazy loading attribute if enabled
	 */
	private function get_lazy_loading_attr() {
		// Pro features only available in Pro version (testing option removed for free version)
		$pro_enabled = WCVIP_IS_PRO;
		$lazy_load = get_option( 'wcvip_lazy_load', $pro_enabled ? 'yes' : 'no' );
		// Return safe HTML attribute string
		return 'yes' === $lazy_load ? ' loading="lazy"' : '';
	}

	/**
	 * Render style-specific selector
	 */
	private function render_style_selector( $style, $variations_data ) {
		switch ( $style ) {
			case 'circular':
				$this->render_circular_selector( $variations_data );
				break;
			case 'square':
				$this->render_square_selector( $variations_data );
				break;
			case 'rectangular':
				$this->render_rectangular_selector( $variations_data );
				break;
			case 'buttons':
			case 'buttons_vertical':
			case 'buttons_horizontal':
			case 'buttons_text_first':
			case 'buttons_text_first_vertical':
			case 'buttons_text_first_horizontal':
				$this->render_buttons_selector( $variations_data, $style );
				break;
			case 'vertical':
				$this->render_vertical_selector( $variations_data );
				break;
			case 'horizontal_text':
				$this->render_horizontal_text_selector( $variations_data );
				break;
			case 'vertical_text':
				$this->render_vertical_text_selector( $variations_data );
				break;
			case 'grid':
				$this->render_grid_selector( $variations_data );
				break;
			case 'strip':
				$this->render_strip_selector( $variations_data );
				break;
			case 'radio':
				$this->render_radio_selector( $variations_data );
				break;
			case 'color_swatches':
				$this->render_color_swatches_selector( $variations_data );
				break;
			default:
				$this->render_square_selector( $variations_data ); // Default fallback
		}
	}

	/**
	 * Render attribute sections selector (new format)
	 * Each attribute gets its own section with its own style
	 */
	private function render_attribute_sections_selector( $variations_data, $default_style ) {
		global $product;
		
		// Get all unique attributes and their values
		$attributes_data = $this->get_attributes_data( $variations_data );
		
		if ( empty( $attributes_data ) ) {
			// Fallback to regular selector
			$this->render_style_selector( $default_style, $variations_data );
			return;
		}
		
		// Get out of stock action setting
		$out_of_stock_action = get_option( 'wcvip_out_of_stock_action', 'disable' );
		
		// Get default attributes
		$default_attributes = $product->get_default_attributes();
		
		?>
		<div class="wcvip-attribute-sections-container">
			<div class="wcvip-selected-variation-global" style="display: none;">
				<span class="wcvip-selected-label"><?php esc_html_e( 'Selected:', 'wc-variation-images-pro' ); ?></span>
				<span class="wcvip-selected-value"></span>
			</div>
			<?php foreach ( $attributes_data as $attribute_key => $attribute_info ) : ?>
				<?php
				$attribute_name = $attribute_info['name'];
				$attribute_values = $attribute_info['values'];
				$attribute_style = $this->get_attribute_style( $attribute_key, $default_style );
				$default_value = ! empty( $default_attributes[ $attribute_key ] ) ? $default_attributes[ $attribute_key ] : '';
				
				// If no default, use first value
				if ( empty( $default_value ) && ! empty( $attribute_values ) ) {
					$default_value = key( $attribute_values );
				}
				?>
				<?php
				// Check if we need lazy loading and max-height wrapper (if >10 values)
				$value_count = count( $attribute_values );
				$needs_lazy_loading = $value_count > 10;
				$wrapper_class = $needs_lazy_loading ? 'wcvip-attribute-section-wrapper' : '';
				?>
				<div class="wcvip-attribute-section" data-attribute-key="<?php echo esc_attr( $attribute_key ); ?>" data-attribute-name="<?php echo esc_attr( $attribute_name ); ?>">
					<div class="wcvip-attribute-section-label">
						<span class="wcvip-attribute-label"><?php echo esc_html( $attribute_name ); ?>:</span>
						<span class="wcvip-attribute-selected-value" data-attribute-key="<?php echo esc_attr( $attribute_key ); ?>">
							<?php if ( ! empty( $default_value ) && isset( $attribute_values[ $default_value ] ) ) : ?>
								<?php echo esc_html( $attribute_values[ $default_value ]['display_name'] ); ?>
							<?php else : ?>
								<?php esc_html_e( 'Select', 'wc-variation-images-pro' ); ?>
							<?php endif; ?>
						</span>
					</div>
					<?php if ( $needs_lazy_loading ) : ?>
						<div class="<?php echo esc_attr( $wrapper_class ); ?>" data-attribute-key="<?php echo esc_attr( $attribute_key ); ?>">
					<?php endif; ?>
					<div class="wcvip-attribute-section-content" data-attribute-style="<?php echo esc_attr( $attribute_style ); ?>">
						<?php $this->render_attribute_values( $attribute_key, $attribute_values, $attribute_style, $variations_data, $out_of_stock_action, $default_value ); ?>
					</div>
					<?php if ( $needs_lazy_loading ) : ?>
						</div>
					<?php endif; ?>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}
	
	/**
	 * Get attributes data organized by attribute
	 */
	private function get_attributes_data( $variations_data ) {
		$attributes_data = array();
		
		if ( empty( $variations_data ) ) {
			return $attributes_data;
		}
		
		// Get attribute order (primary first, then secondary)
		$primary_attribute = ! empty( $variations_data[0]['primary_attribute'] ) ? $variations_data[0]['primary_attribute'] : null;
		$secondary_attributes = ! empty( $variations_data[0]['secondary_attributes'] ) ? $variations_data[0]['secondary_attributes'] : array();
		
		// Build ordered attribute list
		$ordered_attributes = array();
		if ( ! empty( $primary_attribute ) ) {
			$ordered_attributes[] = $primary_attribute;
		}
		foreach ( $secondary_attributes as $secondary_attr ) {
			if ( $secondary_attr !== $primary_attribute ) {
				$ordered_attributes[] = $secondary_attr;
			}
		}
		
		// If no order determined, get from first variation
		if ( empty( $ordered_attributes ) && ! empty( $variations_data[0]['attributes'] ) ) {
			$ordered_attributes = array_keys( $variations_data[0]['attributes'] );
		}
		
		// Extract unique values for each attribute
		foreach ( $ordered_attributes as $attr_key ) {
			$clean_attr_key = str_replace( 'attribute_', '', $attr_key );
			$display_name = WCVIP_Attribute_Helper::get_attribute_display_name( $attr_key );
			$values = array();
			
			foreach ( $variations_data as $variation ) {
				if ( ! isset( $variation['attributes'][ $attr_key ] ) ) {
					continue;
				}
				
				$value = $variation['attributes'][ $attr_key ];
				if ( empty( $value ) ) {
					continue;
				}
				
				if ( ! isset( $values[ $value ] ) ) {
					$values[ $value ] = array(
						'value' => $value,
						'display_name' => WCVIP_Attribute_Helper::get_attribute_value_display_name( $attr_key, $value ),
						'variations' => array(),
					);
				}
				
				// Track which variations have this attribute value
				$values[ $value ]['variations'][] = $variation['variation_id'];
			}
			
			if ( ! empty( $values ) ) {
				$attributes_data[ $attr_key ] = array(
					'name' => $display_name,
					'key' => $attr_key,
					'values' => $values,
				);
			}
		}
		
		return $attributes_data;
	}
	
	/**
	 * Get style for a specific attribute
	 */
	private function get_attribute_style( $attribute_key, $default_style ) {
		global $product;
		
		// In preview mode, check for attribute styles from query parameters first
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Preview mode is for admin users only, verified in is_preview_mode()
		if ( $this->is_preview_mode() && isset( $_GET['wcvip_attr_styles'] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON data must be decoded before sanitization
			$preview_attr_styles_raw = wp_unslash( $_GET['wcvip_attr_styles'] );
			$preview_attr_styles = json_decode( $preview_attr_styles_raw, true );
			if ( is_array( $preview_attr_styles ) && ! empty( $preview_attr_styles[ $attribute_key ] ) ) {
				// Sanitize the attribute style value
				return sanitize_text_field( $preview_attr_styles[ $attribute_key ] );
			}
		}
		
		// Check for product-specific attribute style
		if ( $product ) {
			$product_attribute_styles = get_post_meta( $product->get_id(), '_wcvip_attribute_styles', true );
			if ( is_array( $product_attribute_styles ) && ! empty( $product_attribute_styles[ $attribute_key ] ) ) {
				return $product_attribute_styles[ $attribute_key ];
			}
		}
		
		// Check for global per-attribute style setting
		$attribute_styles = get_option( 'wcvip_attribute_styles', array() );
		if ( ! empty( $attribute_styles[ $attribute_key ] ) ) {
			return $attribute_styles[ $attribute_key ];
		}
		
		// Use default style
		return $default_style;
	}
	
	/**
	 * Render attribute values using the specified style
	 */
	private function render_attribute_values( $attribute_key, $attribute_values, $style, $variations_data, $out_of_stock_action, $default_value ) {
		// Filter variations to only those with this attribute
		$filtered_variations = array();
		foreach ( $variations_data as $variation ) {
			if ( isset( $variation['attributes'][ $attribute_key ] ) ) {
				$filtered_variations[] = $variation;
			}
		}
		
		// Create simplified variations data for this attribute (one per unique value)
		$attribute_variations = array();
		foreach ( $attribute_values as $value => $value_info ) {
			// Find first available variation with this value, or first variation if none available
			$first_variation = null;
			$first_available_variation = null;
			
			foreach ( $filtered_variations as $variation ) {
				if ( isset( $variation['attributes'][ $attribute_key ] ) && $variation['attributes'][ $attribute_key ] === $value ) {
					if ( ! $first_variation ) {
						$first_variation = $variation;
					}
					if ( $variation['available'] && ! $first_available_variation ) {
						$first_available_variation = $variation;
					}
				}
			}
			
			// Use available variation if found, otherwise use first variation
			$selected_variation = $first_available_variation ? $first_available_variation : $first_variation;
			
			if ( $selected_variation ) {
				// Check if this value should be hidden (if all variations with this value are out of stock and action is 'hide')
				$all_out_of_stock = true;
				foreach ( $filtered_variations as $variation ) {
					if ( isset( $variation['attributes'][ $attribute_key ] ) && 
						 $variation['attributes'][ $attribute_key ] === $value && 
						 $variation['available'] ) {
						$all_out_of_stock = false;
						break;
					}
				}
				
				// Hide if all are out of stock and action is 'hide'
				if ( $all_out_of_stock && 'hide' === $out_of_stock_action ) {
					continue;
				}
				
				$is_default = ( $value === $default_value );
				
				$attribute_variations[] = array(
					'variation_id' => $selected_variation['variation_id'],
					'attributes' => array( $attribute_key => $value ),
					'name' => $value_info['display_name'],
					'images' => $selected_variation['images'],
					'price' => $selected_variation['price'],
					'available' => $selected_variation['available'],
					'attribute_value' => $value,
					'attribute_display_name' => $value_info['display_name'],
					'is_attribute_section' => true, // Flag to indicate this is for attribute sections
					'is_default' => $is_default, // Mark default value
				);
			}
		}
		
		// If style is color_swatches, check if current attribute is actually a color attribute
		// If not, fallback to horizontal_text to avoid showing random colors for non-color attributes
		if ( 'color_swatches' === $style ) {
			$is_color_attribute = $this->is_color_attribute( $attribute_key );
			if ( ! $is_color_attribute ) {
				$style = 'horizontal_text';
			}
		}
		
		// Render using the appropriate style
		// Note: The render methods will set data-attributes correctly
		// We'll enhance items with additional attributes via JavaScript if needed
		$this->render_style_selector( $style, $attribute_variations );
	}

	/**
	 * Render circular thumbnails selector
	 */
	private function render_circular_selector( $variations_data ) {
		global $product;
		$lazy_attr = $this->get_lazy_loading_attr();
		
		// Check attribute count from first variation (all variations have same metadata)
		$attribute_count = ! empty( $variations_data[0]['attribute_count'] ) ? $variations_data[0]['attribute_count'] : 1;
		$display_strategy = ! empty( $variations_data[0]['display_strategy'] ) ? $variations_data[0]['display_strategy'] : 'single';
		$primary_attribute = ! empty( $variations_data[0]['primary_attribute'] ) ? $variations_data[0]['primary_attribute'] : null;
		
		// Single attribute: Use original behavior (backward compatible)
		if ( $attribute_count === 1 || $display_strategy === 'single' ) {
			$this->render_circular_selector_single( $variations_data, $lazy_attr );
			return;
		}
		
		// Two attributes: Group by primary attribute
		if ( $attribute_count === 2 || $display_strategy === 'two_attributes' ) {
			$this->render_circular_selector_two_attributes( $variations_data, $lazy_attr, $primary_attribute );
			return;
		}
		
		// Three+ attributes: Show all variations with full names
		$this->render_circular_selector_multi( $variations_data, $lazy_attr );
	}
	
	/**
	 * Render circular selector for single attribute (original behavior)
	 */
	private function render_circular_selector_single( $variations_data, $lazy_attr ) {
		global $product;
		
		// Get default variation attributes
		$default_attributes = $product->get_default_attributes();
		
		// Find the default variation value
		$default_variation_value = '';
		$attribute_name = '';
		$default_variation_id = 0;
		
		if ( ! empty( $default_attributes ) && ! empty( $variations_data ) ) {
			// Get the first attribute name (single attribute)
			$attribute_name = key( $default_attributes );
			$default_value = $default_attributes[ $attribute_name ];
			
			// Find matching variation
			foreach ( $variations_data as $variation ) {
				if ( isset( $variation['attributes'][ 'attribute_' . $attribute_name ] ) && 
					 $variation['attributes'][ 'attribute_' . $attribute_name ] === $default_value ) {
					$default_variation_value = $default_value;
					$default_variation_id = $variation['variation_id'];
					break;
				}
			}
			
			// If no match found, use first variation as default
			if ( empty( $default_variation_value ) && ! empty( $variations_data[0] ) ) {
				$first_variation = $variations_data[0];
				if ( ! empty( $first_variation['attributes'] ) ) {
					$attribute_name = str_replace( 'attribute_', '', key( $first_variation['attributes'] ) );
					$default_variation_value = reset( $first_variation['attributes'] );
					$default_variation_id = $first_variation['variation_id'];
				}
			}
		} elseif ( ! empty( $variations_data[0] ) ) {
			// No default set, use first variation
			$first_variation = $variations_data[0];
			if ( ! empty( $first_variation['attributes'] ) ) {
				$attribute_name = str_replace( 'attribute_', '', key( $first_variation['attributes'] ) );
				$default_variation_value = reset( $first_variation['attributes'] );
				$default_variation_id = $first_variation['variation_id'];
			}
		}
		
		// Format attribute name for display
		$attribute_label = WCVIP_Attribute_Helper::get_attribute_display_name( $attribute_name );
		
		?>
		<div class="wcvip-circular-thumbnails-wrapper">
			<div class="wcvip-selected-variation-global" style="display: none;">
				<span class="wcvip-selected-label"><?php esc_html_e( 'Selected:', 'wc-variation-images-pro' ); ?></span>
				<span class="wcvip-selected-value"></span>
			</div>
			<div class="wcvip-circular-thumbnails" role="group" aria-label="<?php esc_attr_e( 'Product variation options', 'wc-variation-images-pro' ); ?>">
				<?php foreach ( $variations_data as $index => $variation ) : ?>
					<?php if ( ! empty( $variation['images'][0] ) ) : ?>
						<?php
						// Get the value for this variation
						$variation_value = '';
						if ( ! empty( $variation['attributes'] ) ) {
							$variation_value = reset( $variation['attributes'] );
						}
						$is_available = $variation['available'];
						$variation_id = $variation['variation_id'];
						$variation_name = $variation['name'];
						$stock_status = $is_available ? __( 'In Stock', 'wc-variation-images-pro' ) : __( 'Out of Stock', 'wc-variation-images-pro' );
						$tooltip_content = esc_attr( $variation_name ) . ' (' . esc_attr( $stock_status ) . ')';
						?>
						<button type="button"
								class="wcvip-circular-thumb wcvip-tooltip-trigger"
								data-variation-id="<?php echo esc_attr( $variation_id ); ?>"
							 data-attributes="<?php echo esc_attr( json_encode( $variation['attributes'] ) ); ?>"
							 data-variation-value="<?php echo esc_attr( $variation_value ); ?>"
								data-variation-name="<?php echo esc_attr( $variation_name ); ?>"
								data-stock-status="<?php echo esc_attr( $stock_status ); ?>"
								<?php echo ! $is_available ? 'data-unavailable="true" aria-disabled="true"' : ''; ?>
								aria-label="<?php 
								// translators: %s is the variation name
								echo esc_attr( sprintf( __( 'Select variation: %s', 'wc-variation-images-pro' ), $variation_name ) ); 
								?>"
								aria-pressed="false"
								role="radio"
								aria-checked="false"
								tabindex="<?php echo $index === 0 ? '0' : '-1'; ?>"
								title="<?php echo esc_attr( $tooltip_content ); ?>"
								<?php if ( ! $is_available ) : ?>
									aria-describedby="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>"
								<?php endif; ?>>
							<img src="<?php echo esc_url( $variation['images'][0]['thumbnail'] ); ?>" 
								 alt="<?php echo esc_attr( $variation['images'][0]['alt'] ?: $variation_name ); ?>"
								 <?php echo wp_kses_post( $lazy_attr ); ?>>
							<?php if ( ! $is_available ) : ?>
								<span class="wcvip-swatch-unavailable-overlay" id="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>" aria-hidden="true"></span>
							<?php endif; ?>
							<span class="wcvip-tooltip" role="tooltip" aria-hidden="true">
								<span class="wcvip-tooltip-content">
									<?php echo esc_html( $variation_name ); ?>
									<span class="wcvip-tooltip-status"><?php echo esc_html( $stock_status ); ?></span>
								</span>
							</span>
						</button>
					<?php endif; ?>
				<?php endforeach; ?>
						</div>
		</div>
		<?php
	}
	
	/**
	 * Render circular selector for two attributes (grouped by primary)
	 */
	private function render_circular_selector_two_attributes( $variations_data, $lazy_attr, $primary_attribute ) {
		global $product;
		
		if ( empty( $primary_attribute ) ) {
			// Fallback to single attribute display if no primary found
			$this->render_circular_selector_single( $variations_data, $lazy_attr );
			return;
		}
		
		// Group variations by primary attribute
		$grouped = WCVIP_Attribute_Helper::group_variations_by_primary( $variations_data );
		
		// Get default attributes
		$default_attributes = $product->get_default_attributes();
		$default_primary_value = ! empty( $default_attributes[ $primary_attribute ] ) ? $default_attributes[ $primary_attribute ] : '';
		
		// If no default, use first group
		if ( empty( $default_primary_value ) && ! empty( $grouped ) ) {
			$default_primary_value = key( $grouped );
		}
		
		$primary_label = WCVIP_Attribute_Helper::get_attribute_display_name( $primary_attribute );
		$primary_clean = str_replace( 'attribute_', '', $primary_attribute );
		
		?>
		<div class="wcvip-circular-thumbnails-wrapper wcvip-multi-attribute">
			<div class="wcvip-selected-variation-global" style="display: none;">
				<span class="wcvip-selected-label"><?php esc_html_e( 'Selected:', 'wc-variation-images-pro' ); ?></span>
				<span class="wcvip-selected-value"></span>
			</div>
			<?php foreach ( $grouped as $primary_value => $group_variations ) : ?>
				<?php
				$primary_display_value = WCVIP_Attribute_Helper::get_attribute_value_display_name( $primary_attribute, $primary_value );
				$is_default_group = ( $primary_value === $default_primary_value );
				?>
				<div class="wcvip-attribute-group wcvip-group-active<?php echo $is_default_group ? ' wcvip-default-group' : ''; ?>" 
					 data-primary-attribute="<?php echo esc_attr( $primary_attribute ); ?>"
					 data-primary-value="<?php echo esc_attr( $primary_value ); ?>"
					 <?php echo $is_default_group ? 'data-is-default-group="true"' : ''; ?>>
					<div class="wcvip-group-header">
						<div class="wcvip-circular-thumbnails-label">
							<span class="wcvip-label-attribute"><?php echo esc_html( $primary_label ); ?>:</span>
							<span class="wcvip-label-value"><?php echo esc_html( $primary_display_value ); ?></span>
							<span class="wcvip-group-count">(<?php echo count( $group_variations ); ?>)</span>
						</div>
					</div>
					<div class="wcvip-group-content">
						<div class="wcvip-circular-thumbnails" role="group" aria-label="<?php 
						// translators: %s is the primary attribute value
						echo esc_attr( sprintf( __( '%s options', 'wc-variation-images-pro' ), $primary_display_value ) ); 
						?>">
						<?php foreach ( $group_variations as $index => $variation ) : ?>
							<?php if ( ! empty( $variation['images'][0] ) ) : ?>
								<?php
								// Get secondary attribute value for label
								$secondary_value = '';
								$secondary_label = '';
								foreach ( $variation['attributes'] as $attr_key => $attr_val ) {
									if ( $attr_key !== $primary_attribute ) {
										$secondary_value = $attr_val;
										$secondary_label = WCVIP_Attribute_Helper::get_attribute_display_name( $attr_key );
										break;
									}
								}
								
								$is_available = $variation['available'];
								$variation_id = $variation['variation_id'];
								$variation_name = $variation['name'];
								$stock_status = $is_available ? __( 'In Stock', 'wc-variation-images-pro' ) : __( 'Out of Stock', 'wc-variation-images-pro' );
								$tooltip_content = esc_attr( $variation_name ) . ' (' . esc_attr( $stock_status ) . ')';
								
								// For default group, load images immediately (no lazy loading)
								// For other groups, use lazy loading with Intersection Observer
								$image_lazy_attr = $is_default_group ? '' : $lazy_attr;
								?>
								<button type="button"
										class="wcvip-circular-thumb wcvip-tooltip-trigger wcvip-image-container"
										data-variation-id="<?php echo esc_attr( $variation_id ); ?>"
										data-attributes="<?php echo esc_attr( json_encode( $variation['attributes'] ) ); ?>"
										data-variation-name="<?php echo esc_attr( $variation_name ); ?>"
										data-stock-status="<?php echo esc_attr( $stock_status ); ?>"
										data-image-src="<?php echo esc_url( $variation['images'][0]['thumbnail'] ); ?>"
										<?php echo ! $is_available ? 'data-unavailable="true" aria-disabled="true"' : ''; ?>
										aria-label="<?php 
										// translators: %s is the variation name
										echo esc_attr( sprintf( __( 'Select variation: %s', 'wc-variation-images-pro' ), $variation_name ) ); 
										?>"
										aria-pressed="false"
										role="radio"
										aria-checked="false"
										tabindex="<?php echo ( $is_default_group && $index === 0 ) ? '0' : '-1'; ?>"
										title="<?php echo esc_attr( $tooltip_content ); ?>"
										<?php if ( ! $is_available ) : ?>
											aria-describedby="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>"
										<?php endif; ?>>
									<span class="wcvip-image-loading-placeholder" aria-hidden="true"></span>
									<img src="<?php echo esc_url( $variation['images'][0]['thumbnail'] ); ?>" 
										 alt="<?php echo esc_attr( $variation['images'][0]['alt'] ?: $variation_name ); ?>"
										 class="wcvip-variation-image"
										 <?php echo wp_kses_post( $image_lazy_attr ); ?>
										 <?php if ( ! $is_default_group ) : ?>data-wcvip-lazy="true"<?php endif; ?>>
									<?php if ( ! empty( $secondary_value ) ) : ?>
										<span class="wcvip-secondary-label"><?php echo esc_html( WCVIP_Attribute_Helper::get_attribute_value_display_name( '', $secondary_value ) ); ?></span>
									<?php endif; ?>
									<?php if ( ! $is_available ) : ?>
										<span class="wcvip-swatch-unavailable-overlay" id="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>" aria-hidden="true"></span>
									<?php endif; ?>
									<span class="wcvip-tooltip" role="tooltip" aria-hidden="true">
										<span class="wcvip-tooltip-content">
											<?php echo esc_html( $variation_name ); ?>
											<span class="wcvip-tooltip-status"><?php echo esc_html( $stock_status ); ?></span>
										</span>
									</span>
								</button>
							<?php endif; ?>
						<?php endforeach; ?>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}
	
	/**
	 * Render circular selector for three+ attributes (show all)
	 */
	private function render_circular_selector_multi( $variations_data, $lazy_attr ) {
		?>
		<div class="wcvip-circular-thumbnails-wrapper wcvip-multi-attribute wcvip-all-variations">
			<div class="wcvip-circular-thumbnails" role="group" aria-label="<?php esc_attr_e( 'Product variation options', 'wc-variation-images-pro' ); ?>">
				<?php foreach ( $variations_data as $index => $variation ) : ?>
					<?php if ( ! empty( $variation['images'][0] ) ) : ?>
						<?php
						$is_available = $variation['available'];
						$variation_id = $variation['variation_id'];
						$variation_name = $variation['name'];
						$stock_status = $is_available ? __( 'In Stock', 'wc-variation-images-pro' ) : __( 'Out of Stock', 'wc-variation-images-pro' );
						$tooltip_content = esc_attr( $variation_name ) . ' (' . esc_attr( $stock_status ) . ')';
						?>
						<button type="button"
								class="wcvip-circular-thumb wcvip-tooltip-trigger"
								data-variation-id="<?php echo esc_attr( $variation_id ); ?>"
								data-attributes="<?php echo esc_attr( json_encode( $variation['attributes'] ) ); ?>"
								data-variation-name="<?php echo esc_attr( $variation_name ); ?>"
								data-stock-status="<?php echo esc_attr( $stock_status ); ?>"
								<?php echo ! $is_available ? 'data-unavailable="true" aria-disabled="true"' : ''; ?>
								aria-label="<?php 
								// translators: %s is the variation name
								echo esc_attr( sprintf( __( 'Select variation: %s', 'wc-variation-images-pro' ), $variation_name ) ); 
								?>"
								aria-pressed="false"
								role="radio"
								aria-checked="false"
								tabindex="<?php echo $index === 0 ? '0' : '-1'; ?>"
								title="<?php echo esc_attr( $tooltip_content ); ?>"
								<?php if ( ! $is_available ) : ?>
									aria-describedby="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>"
								<?php endif; ?>>
							<img src="<?php echo esc_url( $variation['images'][0]['thumbnail'] ); ?>" 
								 alt="<?php echo esc_attr( $variation['images'][0]['alt'] ?: $variation_name ); ?>"
								 <?php echo wp_kses_post( $lazy_attr ); ?>>
							<span class="wcvip-variation-name-label"><?php echo esc_html( $variation_name ); ?></span>
							<?php if ( ! $is_available ) : ?>
								<span class="wcvip-swatch-unavailable-overlay" id="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>" aria-hidden="true"></span>
							<?php endif; ?>
							<span class="wcvip-tooltip" role="tooltip" aria-hidden="true">
								<span class="wcvip-tooltip-content">
									<?php echo esc_html( $variation_name ); ?>
									<span class="wcvip-tooltip-status"><?php echo esc_html( $stock_status ); ?></span>
								</span>
							</span>
						</button>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Render square thumbnails selector
	 */
	private function render_square_selector( $variations_data ) {
		global $product;
		$lazy_attr = $this->get_lazy_loading_attr();
		
		// Check attribute count from first variation (all variations have same metadata)
		$attribute_count = ! empty( $variations_data[0]['attribute_count'] ) ? $variations_data[0]['attribute_count'] : 1;
		$display_strategy = ! empty( $variations_data[0]['display_strategy'] ) ? $variations_data[0]['display_strategy'] : 'single';
		$primary_attribute = ! empty( $variations_data[0]['primary_attribute'] ) ? $variations_data[0]['primary_attribute'] : null;
		
		// Single attribute: Use original behavior (backward compatible)
		if ( $attribute_count === 1 || $display_strategy === 'single' ) {
			$this->render_square_selector_single( $variations_data, $lazy_attr );
			return;
		}
		
		// Two attributes: Group by primary attribute
		if ( $attribute_count === 2 || $display_strategy === 'two_attributes' ) {
			$this->render_square_selector_two_attributes( $variations_data, $lazy_attr, $primary_attribute );
			return;
		}
		
		// Three+ attributes: Show all variations with full names
		$this->render_square_selector_multi( $variations_data, $lazy_attr );
	}
	
	/**
	 * Render square selector for single attribute (original behavior)
	 */
	private function render_square_selector_single( $variations_data, $lazy_attr ) {
		global $product;
		
		// Get default variation attributes
		$default_attributes = $product->get_default_attributes();
		
		// Find the default variation value
		$default_variation_value = '';
		$attribute_name = '';
		$default_variation_id = 0;
		
		if ( ! empty( $default_attributes ) && ! empty( $variations_data ) ) {
			// Get the first attribute name (single attribute)
			$attribute_name = key( $default_attributes );
			$default_value = $default_attributes[ $attribute_name ];
			
			// Find matching variation
			foreach ( $variations_data as $variation ) {
				if ( isset( $variation['attributes'][ 'attribute_' . $attribute_name ] ) && 
					 $variation['attributes'][ 'attribute_' . $attribute_name ] === $default_value ) {
					$default_variation_value = $default_value;
					$default_variation_id = $variation['variation_id'];
					break;
				}
			}
			
			// If no match found, use first variation as default
			if ( empty( $default_variation_value ) && ! empty( $variations_data[0] ) ) {
				$first_variation = $variations_data[0];
				if ( ! empty( $first_variation['attributes'] ) ) {
					$attribute_name = str_replace( 'attribute_', '', key( $first_variation['attributes'] ) );
					$default_variation_value = reset( $first_variation['attributes'] );
					$default_variation_id = $first_variation['variation_id'];
				}
			}
		} elseif ( ! empty( $variations_data[0] ) ) {
			// No default set, use first variation
			$first_variation = $variations_data[0];
			if ( ! empty( $first_variation['attributes'] ) ) {
				$attribute_name = str_replace( 'attribute_', '', key( $first_variation['attributes'] ) );
				$default_variation_value = reset( $first_variation['attributes'] );
				$default_variation_id = $first_variation['variation_id'];
			}
		}
		
		// Format attribute name for display
		$attribute_label = WCVIP_Attribute_Helper::get_attribute_display_name( $attribute_name );
		
		?>
		<div class="wcvip-square-thumbnails-wrapper">
			<div class="wcvip-selected-variation-global" style="display: none;">
				<span class="wcvip-selected-label"><?php esc_html_e( 'Selected:', 'wc-variation-images-pro' ); ?></span>
				<span class="wcvip-selected-value"></span>
			</div>
			<div class="wcvip-square-thumbnails" role="group" aria-label="<?php esc_attr_e( 'Product variation options', 'wc-variation-images-pro' ); ?>">
				<?php foreach ( $variations_data as $index => $variation ) : ?>
					<?php if ( ! empty( $variation['images'][0] ) ) : ?>
						<?php
						// Get the value for this variation
						$variation_value = '';
						if ( ! empty( $variation['attributes'] ) ) {
							$variation_value = reset( $variation['attributes'] );
						}
						$is_available = $variation['available'];
						$variation_id = $variation['variation_id'];
						$variation_name = $variation['name'];
						$stock_status = $is_available ? __( 'In Stock', 'wc-variation-images-pro' ) : __( 'Out of Stock', 'wc-variation-images-pro' );
						$tooltip_content = esc_attr( $variation_name ) . ' (' . esc_attr( $stock_status ) . ')';
						?>
						<button type="button"
								class="wcvip-square-thumb wcvip-tooltip-trigger"
								data-variation-id="<?php echo esc_attr( $variation_id ); ?>"
							 data-attributes="<?php echo esc_attr( json_encode( $variation['attributes'] ) ); ?>"
							 data-variation-value="<?php echo esc_attr( $variation_value ); ?>"
								data-variation-name="<?php echo esc_attr( $variation_name ); ?>"
								data-stock-status="<?php echo esc_attr( $stock_status ); ?>"
								<?php echo ! $is_available ? 'data-unavailable="true" aria-disabled="true"' : ''; ?>
								aria-label="<?php 
								// translators: %s is the variation name
								echo esc_attr( sprintf( __( 'Select variation: %s', 'wc-variation-images-pro' ), $variation_name ) ); 
								?>"
								aria-pressed="false"
								role="radio"
								aria-checked="false"
								tabindex="<?php echo $index === 0 ? '0' : '-1'; ?>"
								title="<?php echo esc_attr( $tooltip_content ); ?>"
								<?php if ( ! $is_available ) : ?>
									aria-describedby="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>"
								<?php endif; ?>>
							<div class="wcvip-square-thumb-image">
								<img src="<?php echo esc_url( $variation['images'][0]['thumbnail'] ); ?>" 
									 alt="<?php echo esc_attr( $variation['images'][0]['alt'] ?: $variation_name ); ?>"
									 <?php echo wp_kses_post( $lazy_attr ); ?>>
							</div>
							<?php if ( ! $is_available ) : ?>
								<span class="wcvip-swatch-unavailable-overlay" id="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>" aria-hidden="true"></span>
							<?php endif; ?>
							<span class="wcvip-tooltip" role="tooltip" aria-hidden="true">
								<span class="wcvip-tooltip-content">
									<?php echo esc_html( $variation_name ); ?>
									<span class="wcvip-tooltip-status"><?php echo esc_html( $stock_status ); ?></span>
								</span>
							</span>
						</button>
					<?php endif; ?>
				<?php endforeach; ?>
						</div>
		</div>
		<?php
	}
	
	/**
	 * Render square selector for two attributes (grouped by primary)
	 */
	private function render_square_selector_two_attributes( $variations_data, $lazy_attr, $primary_attribute ) {
		global $product;
		
		if ( empty( $primary_attribute ) ) {
			// Fallback to single attribute display if no primary found
			$this->render_square_selector_single( $variations_data, $lazy_attr );
			return;
		}
		
		// Group variations by primary attribute
		$grouped = WCVIP_Attribute_Helper::group_variations_by_primary( $variations_data );
		
		// Get default attributes
		$default_attributes = $product->get_default_attributes();
		$default_primary_value = ! empty( $default_attributes[ $primary_attribute ] ) ? $default_attributes[ $primary_attribute ] : '';
		
		// If no default, use first group
		if ( empty( $default_primary_value ) && ! empty( $grouped ) ) {
			$default_primary_value = key( $grouped );
		}
		
		$primary_label = WCVIP_Attribute_Helper::get_attribute_display_name( $primary_attribute );
		
		?>
		<div class="wcvip-square-thumbnails-wrapper wcvip-multi-attribute">
			<div class="wcvip-selected-variation-global" style="display: none;">
				<span class="wcvip-selected-label"><?php esc_html_e( 'Selected:', 'wc-variation-images-pro' ); ?></span>
				<span class="wcvip-selected-value"></span>
			</div>
			<?php foreach ( $grouped as $primary_value => $group_variations ) : ?>
				<?php
				$primary_display_value = WCVIP_Attribute_Helper::get_attribute_value_display_name( $primary_attribute, $primary_value );
				$is_default_group = ( $primary_value === $default_primary_value );
				?>
				<div class="wcvip-attribute-group wcvip-group-active<?php echo $is_default_group ? ' wcvip-default-group' : ''; ?>" 
					 data-primary-attribute="<?php echo esc_attr( $primary_attribute ); ?>"
					 data-primary-value="<?php echo esc_attr( $primary_value ); ?>"
					 <?php echo $is_default_group ? 'data-is-default-group="true"' : ''; ?>>
					<div class="wcvip-group-header">
						<div class="wcvip-square-thumbnails-label">
							<span class="wcvip-label-attribute"><?php echo esc_html( $primary_label ); ?>:</span>
							<span class="wcvip-label-value"><?php echo esc_html( $primary_display_value ); ?></span>
							<span class="wcvip-group-count">(<?php echo count( $group_variations ); ?>)</span>
						</div>
					</div>
					<div class="wcvip-group-content">
						<div class="wcvip-square-thumbnails" role="group" aria-label="<?php 
						// translators: %s is the primary attribute value
						echo esc_attr( sprintf( __( '%s options', 'wc-variation-images-pro' ), $primary_display_value ) ); 
						?>">
						<?php foreach ( $group_variations as $index => $variation ) : ?>
							<?php if ( ! empty( $variation['images'][0] ) ) : ?>
								<?php
								// Get secondary attribute value for label
								$secondary_value = '';
								foreach ( $variation['attributes'] as $attr_key => $attr_val ) {
									if ( $attr_key !== $primary_attribute ) {
										$secondary_value = $attr_val;
										break;
									}
								}
								
								$is_available = $variation['available'];
								$variation_id = $variation['variation_id'];
								$variation_name = $variation['name'];
								$stock_status = $is_available ? __( 'In Stock', 'wc-variation-images-pro' ) : __( 'Out of Stock', 'wc-variation-images-pro' );
								$tooltip_content = esc_attr( $variation_name ) . ' (' . esc_attr( $stock_status ) . ')';
								
								// For default group, load images immediately (no lazy loading)
								// For other groups, use lazy loading with Intersection Observer
								$image_lazy_attr = $is_default_group ? '' : $lazy_attr;
								?>
								<button type="button"
										class="wcvip-square-thumb wcvip-tooltip-trigger wcvip-image-container"
										data-variation-id="<?php echo esc_attr( $variation_id ); ?>"
										data-attributes="<?php echo esc_attr( json_encode( $variation['attributes'] ) ); ?>"
										data-variation-name="<?php echo esc_attr( $variation_name ); ?>"
										data-stock-status="<?php echo esc_attr( $stock_status ); ?>"
										data-image-src="<?php echo esc_url( $variation['images'][0]['thumbnail'] ); ?>"
										<?php echo ! $is_available ? 'data-unavailable="true" aria-disabled="true"' : ''; ?>
										aria-label="<?php 
										// translators: %s is the variation name
										echo esc_attr( sprintf( __( 'Select variation: %s', 'wc-variation-images-pro' ), $variation_name ) ); 
										?>"
										aria-pressed="false"
										role="radio"
										aria-checked="false"
										tabindex="<?php echo ( $is_default_group && $index === 0 ) ? '0' : '-1'; ?>"
										title="<?php echo esc_attr( $tooltip_content ); ?>"
										<?php if ( ! $is_available ) : ?>
											aria-describedby="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>"
										<?php endif; ?>>
									<div class="wcvip-square-thumb-image">
										<span class="wcvip-image-loading-placeholder" aria-hidden="true"></span>
										<img src="<?php echo esc_url( $variation['images'][0]['thumbnail'] ); ?>" 
											 alt="<?php echo esc_attr( $variation['images'][0]['alt'] ?: $variation_name ); ?>"
											 class="wcvip-variation-image"
											 <?php echo wp_kses_post( $image_lazy_attr ); ?>
											 <?php if ( ! $is_default_group ) : ?>data-wcvip-lazy="true"<?php endif; ?>>
									</div>
									<?php if ( ! empty( $secondary_value ) ) : ?>
										<span class="wcvip-secondary-label"><?php echo esc_html( WCVIP_Attribute_Helper::get_attribute_value_display_name( '', $secondary_value ) ); ?></span>
									<?php endif; ?>
									<?php if ( ! $is_available ) : ?>
										<span class="wcvip-swatch-unavailable-overlay" id="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>" aria-hidden="true"></span>
									<?php endif; ?>
									<span class="wcvip-tooltip" role="tooltip" aria-hidden="true">
										<span class="wcvip-tooltip-content">
											<?php echo esc_html( $variation_name ); ?>
											<span class="wcvip-tooltip-status"><?php echo esc_html( $stock_status ); ?></span>
										</span>
									</span>
								</button>
							<?php endif; ?>
						<?php endforeach; ?>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}
	
	/**
	 * Render square selector for three+ attributes (show all)
	 */
	private function render_square_selector_multi( $variations_data, $lazy_attr ) {
		?>
		<div class="wcvip-square-thumbnails-wrapper wcvip-multi-attribute wcvip-all-variations">
			<div class="wcvip-square-thumbnails" role="group" aria-label="<?php esc_attr_e( 'Product variation options', 'wc-variation-images-pro' ); ?>">
				<?php foreach ( $variations_data as $index => $variation ) : ?>
					<?php if ( ! empty( $variation['images'][0] ) ) : ?>
						<?php
						$is_available = $variation['available'];
						$variation_id = $variation['variation_id'];
						$variation_name = $variation['name'];
						$stock_status = $is_available ? __( 'In Stock', 'wc-variation-images-pro' ) : __( 'Out of Stock', 'wc-variation-images-pro' );
						$tooltip_content = esc_attr( $variation_name ) . ' (' . esc_attr( $stock_status ) . ')';
						?>
						<button type="button"
								class="wcvip-square-thumb wcvip-tooltip-trigger"
								data-variation-id="<?php echo esc_attr( $variation_id ); ?>"
								data-attributes="<?php echo esc_attr( json_encode( $variation['attributes'] ) ); ?>"
								data-variation-name="<?php echo esc_attr( $variation_name ); ?>"
								data-stock-status="<?php echo esc_attr( $stock_status ); ?>"
								<?php echo ! $is_available ? 'data-unavailable="true" aria-disabled="true"' : ''; ?>
								aria-label="<?php 
								// translators: %s is the variation name
								echo esc_attr( sprintf( __( 'Select variation: %s', 'wc-variation-images-pro' ), $variation_name ) ); 
								?>"
								aria-pressed="false"
								role="radio"
								aria-checked="false"
								tabindex="<?php echo $index === 0 ? '0' : '-1'; ?>"
								title="<?php echo esc_attr( $tooltip_content ); ?>"
								<?php if ( ! $is_available ) : ?>
									aria-describedby="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>"
								<?php endif; ?>>
							<div class="wcvip-square-thumb-image">
								<img src="<?php echo esc_url( $variation['images'][0]['thumbnail'] ); ?>" 
									 alt="<?php echo esc_attr( $variation['images'][0]['alt'] ?: $variation_name ); ?>"
									 <?php echo wp_kses_post( $lazy_attr ); ?>>
							</div>
							<span class="wcvip-variation-name-label"><?php echo esc_html( $variation_name ); ?></span>
							<?php if ( ! $is_available ) : ?>
								<span class="wcvip-swatch-unavailable-overlay" id="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>" aria-hidden="true"></span>
							<?php endif; ?>
							<span class="wcvip-tooltip" role="tooltip" aria-hidden="true">
								<span class="wcvip-tooltip-content">
									<?php echo esc_html( $variation_name ); ?>
									<span class="wcvip-tooltip-status"><?php echo esc_html( $stock_status ); ?></span>
								</span>
							</span>
						</button>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Render rectangular selector
	 * Enhanced with tooltips and multi-attribute support
	 */
	private function render_rectangular_selector( $variations_data ) {
		$lazy_attr = $this->get_lazy_loading_attr();
		
		// Check attribute count from first variation (all variations have same metadata)
		$attribute_count = ! empty( $variations_data[0]['attribute_count'] ) ? $variations_data[0]['attribute_count'] : 1;
		$display_strategy = ! empty( $variations_data[0]['display_strategy'] ) ? $variations_data[0]['display_strategy'] : 'single';
		$primary_attribute = ! empty( $variations_data[0]['primary_attribute'] ) ? $variations_data[0]['primary_attribute'] : null;
		
		// Single attribute or 3+: Show all variations (rectangular already shows labels)
		if ( $attribute_count === 1 || $attribute_count >= 3 || $display_strategy === 'single' || $display_strategy === 'multi_attributes' ) {
			$this->render_rectangular_selector_all( $variations_data, $lazy_attr );
			return;
		}
		
		// Two attributes: Group by primary attribute
		if ( $attribute_count === 2 || $display_strategy === 'two_attributes' ) {
			$this->render_rectangular_selector_two_attributes( $variations_data, $lazy_attr, $primary_attribute );
			return;
		}
		
		// Fallback
		$this->render_rectangular_selector_all( $variations_data, $lazy_attr );
	}
	
	/**
	 * Render rectangular selector showing all variations
	 */
	private function render_rectangular_selector_all( $variations_data, $lazy_attr ) {
		?>
		<div class="wcvip-rectangular-thumbnails">
			<?php foreach ( $variations_data as $index => $variation ) : ?>
				<?php if ( ! empty( $variation['images'][0] ) ) : ?>
					<?php
					$is_available = $variation['available'];
					$variation_id = $variation['variation_id'];
					$variation_name = $variation['name'];
					$stock_status = $is_available ? __( 'In Stock', 'wc-variation-images-pro' ) : __( 'Out of Stock', 'wc-variation-images-pro' );
					$tooltip_content = esc_attr( $variation_name ) . ' (' . esc_attr( $stock_status ) . ')';
					?>
					<div class="wcvip-rectangular-item wcvip-tooltip-trigger" 
						 data-variation-id="<?php echo esc_attr( $variation_id ); ?>"
						 data-attributes="<?php echo esc_attr( json_encode( $variation['attributes'] ) ); ?>"
						 title="<?php echo esc_attr( $tooltip_content ); ?>">
						<div class="wcvip-rect-image">
							<img src="<?php echo esc_url( $variation['images'][0]['thumbnail'] ); ?>" 
								 alt="<?php echo esc_attr( $variation['images'][0]['alt'] ?: $variation['name'] ); ?>"
								 <?php echo wp_kses_post( $lazy_attr ); ?>>
						</div>
						<div class="wcvip-rect-label"><?php echo esc_html( $variation['name'] ); ?></div>
						<span class="wcvip-tooltip" role="tooltip" aria-hidden="true">
							<span class="wcvip-tooltip-content">
								<?php echo esc_html( $variation_name ); ?>
								<span class="wcvip-tooltip-status"><?php echo esc_html( $stock_status ); ?></span>
							</span>
						</span>
					</div>
				<?php endif; ?>
			<?php endforeach; ?>
		</div>
		<?php
	}
	
	/**
	 * Render rectangular selector for two attributes (grouped by primary)
	 */
	private function render_rectangular_selector_two_attributes( $variations_data, $lazy_attr, $primary_attribute ) {
		global $product;
		
		if ( empty( $primary_attribute ) ) {
			// Fallback to showing all if no primary found
			$this->render_rectangular_selector_all( $variations_data, $lazy_attr );
			return;
		}
		
		// Group variations by primary attribute
		$grouped = WCVIP_Attribute_Helper::group_variations_by_primary( $variations_data );
		
		// Get default attributes
		$default_attributes = $product->get_default_attributes();
		$default_primary_value = ! empty( $default_attributes[ $primary_attribute ] ) ? $default_attributes[ $primary_attribute ] : '';
		
		// If no default, use first group
		if ( empty( $default_primary_value ) && ! empty( $grouped ) ) {
			$default_primary_value = key( $grouped );
		}
		
		$primary_label = WCVIP_Attribute_Helper::get_attribute_display_name( $primary_attribute );
		
		?>
		<div class="wcvip-rectangular-thumbnails wcvip-multi-attribute">
			<?php foreach ( $grouped as $primary_value => $group_variations ) : ?>
				<?php
				$primary_display_value = WCVIP_Attribute_Helper::get_attribute_value_display_name( $primary_attribute, $primary_value );
				$is_default_group = ( $primary_value === $default_primary_value );
				?>
				<div class="wcvip-attribute-group <?php echo $is_default_group ? 'wcvip-group-active' : 'wcvip-group-collapsed'; ?>" 
					 data-primary-attribute="<?php echo esc_attr( $primary_attribute ); ?>"
					 data-primary-value="<?php echo esc_attr( $primary_value ); ?>">
					<button type="button" class="wcvip-group-header wcvip-group-toggle" aria-expanded="<?php echo $is_default_group ? 'true' : 'false'; ?>">
						<div class="wcvip-rectangular-group-header">
							<span class="wcvip-label-attribute"><?php echo esc_html( $primary_label ); ?>:</span>
							<span class="wcvip-label-value"><?php echo esc_html( $primary_display_value ); ?></span>
							<span class="wcvip-group-count">(<?php echo count( $group_variations ); ?>)</span>
						</div>
						<span class="wcvip-group-toggle-icon" aria-hidden="true">▼</span>
					</button>
					<div class="wcvip-group-content" <?php echo ! $is_default_group ? 'style="display: none;"' : ''; ?>>
						<div class="wcvip-rectangular-group-items">
						<?php foreach ( $group_variations as $index => $variation ) : ?>
							<?php if ( ! empty( $variation['images'][0] ) ) : ?>
								<?php
								$is_available = $variation['available'];
								$variation_id = $variation['variation_id'];
								$variation_name = $variation['name'];
								$stock_status = $is_available ? __( 'In Stock', 'wc-variation-images-pro' ) : __( 'Out of Stock', 'wc-variation-images-pro' );
								$tooltip_content = esc_attr( $variation_name ) . ' (' . esc_attr( $stock_status ) . ')';
								?>
								<div class="wcvip-rectangular-item wcvip-tooltip-trigger" 
									 data-variation-id="<?php echo esc_attr( $variation_id ); ?>"
									 data-attributes="<?php echo esc_attr( json_encode( $variation['attributes'] ) ); ?>"
									 title="<?php echo esc_attr( $tooltip_content ); ?>">
									<div class="wcvip-rect-image">
										<img src="<?php echo esc_url( $variation['images'][0]['thumbnail'] ); ?>" 
											 alt="<?php echo esc_attr( $variation['images'][0]['alt'] ?: $variation['name'] ); ?>"
											 <?php echo wp_kses_post( $lazy_attr ); ?>>
									</div>
									<div class="wcvip-rect-label"><?php echo esc_html( $variation['name'] ); ?></div>
									<span class="wcvip-tooltip" role="tooltip" aria-hidden="true">
										<span class="wcvip-tooltip-content">
											<?php echo esc_html( $variation_name ); ?>
											<span class="wcvip-tooltip-status"><?php echo esc_html( $stock_status ); ?></span>
										</span>
									</span>
								</div>
							<?php endif; ?>
						<?php endforeach; ?>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Render buttons selector
	 * Enhanced with accessibility, tooltips, and improved UX
	 */
	private function render_buttons_selector( $variations_data, $style = 'buttons_vertical' ) {
		// Determine orientation from style name
		$orientation = 'vertical';
		if ( 'buttons_horizontal' === $style ) {
			$orientation = 'horizontal';
		} elseif ( 'buttons' === $style ) {
			// Backward compatibility: check old setting
			$orientation = get_option( 'wcvip_buttons_orientation', 'vertical' );
		}
		
		// Determine layout: image_first or text_first
		$layout = 'image_first';
		if ( 'buttons_text_first' === $style || 'buttons_text_first_vertical' === $style || 'buttons_text_first_horizontal' === $style ) {
			$layout = 'text_first';
		}
		
		// Check if we're in attribute sections mode (skip individual selected label)
		$is_attribute_section = ! empty( $variations_data ) && ! empty( $variations_data[0]['is_attribute_section'] );
		
		$lazy_attr = $this->get_lazy_loading_attr();
		?>
		<div class="wcvip-button-style <?php echo $orientation === 'horizontal' ? 'wcvip-orientation-horizontal' : 'wcvip-orientation-vertical'; ?> <?php echo $layout === 'text_first' ? 'wcvip-layout-text-first' : 'wcvip-layout-image-first'; ?>" role="group" aria-label="<?php esc_attr_e( 'Product variation options', 'wc-variation-images-pro' ); ?>">
			<?php if ( ! $is_attribute_section ) : ?>
			<div class="wcvip-selected-variation-global" style="display: none;">
				<span class="wcvip-selected-label"><?php esc_html_e( 'Selected:', 'wc-variation-images-pro' ); ?></span>
				<span class="wcvip-selected-value"></span>
			</div>
			<?php endif; ?>
			<?php foreach ( $variations_data as $index => $variation ) : ?>
				<?php if ( ! empty( $variation['images'][0] ) ) : ?>
					<?php
					$is_available = $variation['available'];
					$variation_id = $variation['variation_id'];
					$variation_name = $variation['name'];
					$variation_price = $variation['price'];
					$stock_status = $is_available ? __( 'In Stock', 'wc-variation-images-pro' ) : __( 'Out of Stock', 'wc-variation-images-pro' );
					
					// Build tooltip content
					$tooltip_content = esc_attr( $variation_name );
					if ( ! empty( $variation_price ) ) {
						$tooltip_content .= ' - ' . wp_strip_all_tags( $variation_price );
					}
					$tooltip_content .= ' (' . esc_attr( $stock_status ) . ')';
					?>
					<button type="button"
							class="wcvip-button-thumb wcvip-tooltip-trigger"
							data-variation-id="<?php echo esc_attr( $variation_id ); ?>"
							data-attributes="<?php echo esc_attr( json_encode( $variation['attributes'] ) ); ?>"
							data-variation-name="<?php echo esc_attr( $variation_name ); ?>"
							data-variation-price="<?php echo esc_attr( wp_strip_all_tags( $variation_price ) ); ?>"
							data-stock-status="<?php echo esc_attr( $stock_status ); ?>"
							<?php echo ! $is_available ? 'data-unavailable="true" aria-disabled="true"' : ''; ?>
							aria-label="<?php 
							// translators: %s is the variation name
							echo esc_attr( sprintf( __( 'Select variation: %s', 'wc-variation-images-pro' ), $variation_name ) ); 
							?>"
							aria-pressed="false"
							role="radio"
							aria-checked="false"
							tabindex="<?php echo $index === 0 ? '0' : '-1'; ?>"
							title="<?php echo esc_attr( $tooltip_content ); ?>"
							<?php if ( ! $is_available ) : ?>
								aria-describedby="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>"
							<?php endif; ?>>
						<?php if ( 'text_first' === $layout ) : ?>
							<span class="wcvip-button-text"><?php echo esc_html( $variation_name ); ?></span>
							<img src="<?php echo esc_url( $variation['images'][0]['thumbnail'] ); ?>" 
								 alt="<?php echo esc_attr( $variation['images'][0]['alt'] ?: $variation_name ); ?>"
								 <?php echo wp_kses_post( $lazy_attr ); ?>>
						<?php else : ?>
							<img src="<?php echo esc_url( $variation['images'][0]['thumbnail'] ); ?>" 
								 alt="<?php echo esc_attr( $variation['images'][0]['alt'] ?: $variation_name ); ?>"
								 <?php echo wp_kses_post( $lazy_attr ); ?>>
							<span class="wcvip-button-text"><?php echo esc_html( $variation_name ); ?></span>
						<?php endif; ?>
						<?php if ( ! $is_available ) : ?>
							<span class="wcvip-stock-badge" id="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>" aria-hidden="true">
								<?php esc_html_e( 'Out of Stock', 'wc-variation-images-pro' ); ?>
							</span>
						<?php endif; ?>
						<span class="wcvip-tooltip" role="tooltip" aria-hidden="true">
							<span class="wcvip-tooltip-content">
								<?php echo esc_html( $variation_name ); ?>
								<?php if ( ! empty( $variation_price ) ) : ?>
									<span class="wcvip-tooltip-price"><?php echo wp_kses_post( $variation_price ); ?></span>
								<?php endif; ?>
								<span class="wcvip-tooltip-status"><?php echo esc_html( $stock_status ); ?></span>
							</span>
						</span>
					</button>
				<?php endif; ?>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Render vertical list selector
	 * Enhanced with tooltips
	 */
	private function render_vertical_selector( $variations_data ) {
		$lazy_attr = $this->get_lazy_loading_attr();
		?>
		<div class="wcvip-vertical-list">
			<?php foreach ( $variations_data as $index => $variation ) : ?>
				<?php if ( ! empty( $variation['images'][0] ) ) : ?>
					<?php
					$is_available = $variation['available'];
					$variation_id = $variation['variation_id'];
					$variation_name = $variation['name'];
					$stock_status = $is_available ? __( 'In Stock', 'wc-variation-images-pro' ) : __( 'Out of Stock', 'wc-variation-images-pro' );
					$tooltip_content = esc_attr( $variation_name ) . ' (' . esc_attr( $stock_status ) . ')';
					?>
					<div class="wcvip-vertical-item wcvip-tooltip-trigger" 
						 data-variation-id="<?php echo esc_attr( $variation_id ); ?>"
						 data-attributes="<?php echo esc_attr( json_encode( $variation['attributes'] ) ); ?>"
						 title="<?php echo esc_attr( $tooltip_content ); ?>">
						<img src="<?php echo esc_url( $variation['images'][0]['thumbnail'] ); ?>" 
							 alt="<?php echo esc_attr( $variation['images'][0]['alt'] ?: $variation['name'] ); ?>"
									 <?php echo wp_kses_post( $lazy_attr ); ?>>
						<span class="wcvip-tooltip" role="tooltip" aria-hidden="true">
							<span class="wcvip-tooltip-content">
								<?php echo esc_html( $variation_name ); ?>
								<span class="wcvip-tooltip-status"><?php echo esc_html( $stock_status ); ?></span>
							</span>
						</span>
					</div>
				<?php endif; ?>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Render horizontal text boxes selector
	 * Enhanced with accessibility, tooltips, loading states, and multi-attribute support
	 */
	private function render_horizontal_text_selector( $variations_data ) {
		// Always show all variations in a single flat list without collapsible groups
		$this->render_horizontal_text_single( $variations_data );
	}
	
	/**
	 * Render horizontal text selector for single attribute (original behavior)
	 */
	private function render_horizontal_text_single( $variations_data ) {
		// Check if we're in attribute sections mode (skip individual selected label)
		$is_attribute_section = ! empty( $variations_data ) && ! empty( $variations_data[0]['is_attribute_section'] );
		
		$total_variations = count( $variations_data );
		$needs_lazy_loading = $total_variations > 30;
		$wrapper_class = $needs_lazy_loading ? 'wcvip-horizontal-text-boxes-wrapper' : '';
		?>
		<div class="<?php echo esc_attr( $wrapper_class ); ?>">
			<?php if ( ! $is_attribute_section ) : ?>
			<div class="wcvip-selected-variation-global" style="display: none;">
				<span class="wcvip-selected-label"><?php esc_html_e( 'Selected:', 'wc-variation-images-pro' ); ?></span>
				<span class="wcvip-selected-value"></span>
			</div>
			<?php endif; ?>
		<div class="wcvip-horizontal-text-boxes" role="group" aria-label="<?php esc_attr_e( 'Product variation options', 'wc-variation-images-pro' ); ?>">
				<?php foreach ( $variations_data as $index => $variation ) : ?>
				<?php
				$is_available = $variation['available'];
				$variation_id = $variation['variation_id'];
				$variation_name = $variation['name'];
				$variation_price = $variation['price'];
				$stock_status = $is_available ? __( 'In Stock', 'wc-variation-images-pro' ) : __( 'Out of Stock', 'wc-variation-images-pro' );
				
				// Build tooltip content with variation details
				$tooltip_content = esc_attr( $variation_name );
				?>
				<button type="button"
						class="wcvip-text-box wcvip-tooltip-trigger"
						data-variation-id="<?php echo esc_attr( $variation_id ); ?>"
					 data-attributes="<?php echo esc_attr( json_encode( $variation['attributes'] ) ); ?>"
						data-variation-name="<?php echo esc_attr( $variation_name ); ?>"
						data-variation-price="<?php echo esc_attr( wp_strip_all_tags( $variation_price ) ); ?>"
						data-stock-status="<?php echo esc_attr( $stock_status ); ?>"
						<?php echo ! $is_available ? 'data-unavailable="true" aria-disabled="true"' : ''; ?>
						aria-label="<?php 
						// translators: %s is the variation name
						echo esc_attr( sprintf( __( 'Select variation: %s', 'wc-variation-images-pro' ), $variation_name ) ); 
						?>"
						aria-pressed="false"
						role="radio"
						aria-checked="false"
						tabindex="<?php echo $index === 0 ? '0' : '-1'; ?>"
						title="<?php echo esc_attr( $tooltip_content ); ?>"
						<?php if ( ! $is_available ) : ?>
							aria-describedby="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>"
						<?php endif; ?>>
					<span class="wcvip-text-box-content">
						<?php echo esc_html( $variation_name ); ?>
					</span>
					<?php if ( ! $is_available ) : ?>
						<span class="wcvip-stock-badge" id="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>" aria-hidden="true">
							<?php esc_html_e( 'Out of Stock', 'wc-variation-images-pro' ); ?>
						</span>
					<?php endif; ?>
					<span class="wcvip-tooltip" role="tooltip" aria-hidden="true">
						<span class="wcvip-tooltip-content">
							<?php echo esc_html( $variation_name ); ?>
						</span>
					</span>
				</button>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}
	
	/**
	 * Render horizontal text selector for two attributes (with collapsible groups)
	 */
	private function render_horizontal_text_two_attributes( $variations_data, $primary_attribute ) {
		global $product;
		
		if ( empty( $primary_attribute ) ) {
			// Fallback to single
			$this->render_horizontal_text_single( $variations_data );
			return;
		}
		
		// Group variations by primary attribute
		$grouped = WCVIP_Attribute_Helper::group_variations_by_primary( $variations_data );
		
		// Get default attributes
		$default_attributes = $product->get_default_attributes();
		$default_primary_value = ! empty( $default_attributes[ $primary_attribute ] ) ? $default_attributes[ $primary_attribute ] : '';
		
		// If no default, use first group
		if ( empty( $default_primary_value ) && ! empty( $grouped ) ) {
			$default_primary_value = key( $grouped );
		}
		
		$primary_label = WCVIP_Attribute_Helper::get_attribute_display_name( $primary_attribute );
		
		?>
		<div class="wcvip-horizontal-text-boxes-wrapper wcvip-multi-attribute">
			<?php foreach ( $grouped as $primary_value => $group_variations ) : ?>
				<?php
				$primary_display_value = WCVIP_Attribute_Helper::get_attribute_value_display_name( $primary_attribute, $primary_value );
				$is_default_group = ( $primary_value === $default_primary_value );
				?>
				<div class="wcvip-attribute-group <?php echo $is_default_group ? 'wcvip-group-active' : 'wcvip-group-collapsed'; ?>" 
					 data-primary-attribute="<?php echo esc_attr( $primary_attribute ); ?>"
					 data-primary-value="<?php echo esc_attr( $primary_value ); ?>">
					<button type="button" class="wcvip-group-header wcvip-group-toggle" aria-expanded="<?php echo $is_default_group ? 'true' : 'false'; ?>">
						<div class="wcvip-horizontal-text-boxes-label">
							<span class="wcvip-label-attribute"><?php echo esc_html( $primary_label ); ?>:</span>
							<span class="wcvip-label-value"><?php echo esc_html( $primary_display_value ); ?></span>
							<span class="wcvip-group-count">(<?php echo count( $group_variations ); ?>)</span>
						</div>
						<span class="wcvip-group-toggle-icon" aria-hidden="true">▼</span>
					</button>
					<div class="wcvip-group-content" <?php echo ! $is_default_group ? 'style="display: none;"' : ''; ?>>
						<div class="wcvip-horizontal-text-boxes" role="group" aria-label="<?php 
						// translators: %s is the primary attribute value
						echo esc_attr( sprintf( __( '%s options', 'wc-variation-images-pro' ), $primary_display_value ) ); 
						?>">
							<?php foreach ( $group_variations as $index => $variation ) : ?>
								<?php
								$is_available = $variation['available'];
								$variation_id = $variation['variation_id'];
								$variation_name = $variation['name'];
								$variation_price = $variation['price'];
								$stock_status = $is_available ? __( 'In Stock', 'wc-variation-images-pro' ) : __( 'Out of Stock', 'wc-variation-images-pro' );
								
								// Build tooltip content with variation details
								$tooltip_content = esc_attr( $variation_name );
								?>
								<button type="button"
										class="wcvip-text-box wcvip-tooltip-trigger"
										data-variation-id="<?php echo esc_attr( $variation_id ); ?>"
										data-attributes="<?php echo esc_attr( json_encode( $variation['attributes'] ) ); ?>"
										data-variation-name="<?php echo esc_attr( $variation_name ); ?>"
										data-variation-price="<?php echo esc_attr( wp_strip_all_tags( $variation_price ) ); ?>"
										data-stock-status="<?php echo esc_attr( $stock_status ); ?>"
										<?php echo ! $is_available ? 'data-unavailable="true" aria-disabled="true"' : ''; ?>
										aria-label="<?php 
										// translators: %s is the variation name
										echo esc_attr( sprintf( __( 'Select variation: %s', 'wc-variation-images-pro' ), $variation_name ) ); 
										?>"
										aria-pressed="false"
										role="radio"
										aria-checked="false"
										tabindex="<?php echo $index === 0 ? '0' : '-1'; ?>"
										title="<?php echo esc_attr( $tooltip_content ); ?>"
										<?php if ( ! $is_available ) : ?>
											aria-describedby="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>"
										<?php endif; ?>>
									<span class="wcvip-text-box-content">
										<?php echo esc_html( $variation_name ); ?>
									</span>
									<?php if ( ! $is_available ) : ?>
										<span class="wcvip-stock-badge" id="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>" aria-hidden="true">
											<?php esc_html_e( 'Out of Stock', 'wc-variation-images-pro' ); ?>
										</span>
									<?php endif; ?>
									<span class="wcvip-tooltip" role="tooltip" aria-hidden="true">
										<span class="wcvip-tooltip-content">
											<?php echo esc_html( $variation_name ); ?>
										</span>
									</span>
								</button>
							<?php endforeach; ?>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}
	
	/**
	 * Render horizontal text selector for three+ attributes (show all with full names)
	 */
	private function render_horizontal_text_multi( $variations_data ) {
		$total_variations = count( $variations_data );
		$needs_lazy_loading = $total_variations > 30;
		$wrapper_class = $needs_lazy_loading ? 'wcvip-horizontal-text-boxes-wrapper' : '';
		?>
		<div class="<?php echo esc_attr( $wrapper_class ); ?>">
			<div class="wcvip-horizontal-text-boxes" role="group" aria-label="<?php esc_attr_e( 'Product variation options', 'wc-variation-images-pro' ); ?>">
				<?php foreach ( $variations_data as $index => $variation ) : ?>
				<?php
				$is_available = $variation['available'];
				$variation_id = $variation['variation_id'];
				$variation_name = $variation['name'];
				$variation_price = $variation['price'];
				$stock_status = $is_available ? __( 'In Stock', 'wc-variation-images-pro' ) : __( 'Out of Stock', 'wc-variation-images-pro' );
				
				// Build tooltip content with variation details
				$tooltip_content = esc_attr( $variation_name );
				?>
				<button type="button"
						class="wcvip-text-box wcvip-tooltip-trigger"
						data-variation-id="<?php echo esc_attr( $variation_id ); ?>"
						data-attributes="<?php echo esc_attr( json_encode( $variation['attributes'] ) ); ?>"
						data-variation-name="<?php echo esc_attr( $variation_name ); ?>"
						data-variation-price="<?php echo esc_attr( wp_strip_all_tags( $variation_price ) ); ?>"
						data-stock-status="<?php echo esc_attr( $stock_status ); ?>"
						<?php echo ! $is_available ? 'data-unavailable="true" aria-disabled="true"' : ''; ?>
						aria-label="<?php 
						// translators: %s is the variation name
						echo esc_attr( sprintf( __( 'Select variation: %s', 'wc-variation-images-pro' ), $variation_name ) ); 
						?>"
						aria-pressed="false"
						role="radio"
						aria-checked="false"
						tabindex="<?php echo $index === 0 ? '0' : '-1'; ?>"
						title="<?php echo esc_attr( $tooltip_content ); ?>"
						<?php if ( ! $is_available ) : ?>
							aria-describedby="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>"
						<?php endif; ?>>
					<span class="wcvip-text-box-content">
						<?php echo esc_html( $variation_name ); ?>
					</span>
					<?php if ( ! $is_available ) : ?>
						<span class="wcvip-stock-badge" id="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>" aria-hidden="true">
							<?php esc_html_e( 'Out of Stock', 'wc-variation-images-pro' ); ?>
						</span>
					<?php endif; ?>
					<span class="wcvip-tooltip" role="tooltip" aria-hidden="true">
						<span class="wcvip-tooltip-content">
							<?php echo esc_html( $variation_name ); ?>
						</span>
					</span>
				</button>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Render vertical text list selector
	 * Enhanced with accessibility, tooltips, improved UX, and multi-attribute support
	 */
	private function render_vertical_text_selector( $variations_data ) {
		// Always show all variations in a single flat list without collapsible groups
		$this->render_vertical_text_single( $variations_data );
	}
	
	/**
	 * Render vertical text selector for single attribute (original behavior)
	 */
	private function render_vertical_text_single( $variations_data ) {
		// Check if we're in attribute sections mode (skip individual selected label)
		$is_attribute_section = ! empty( $variations_data ) && ! empty( $variations_data[0]['is_attribute_section'] );
		
		$total_variations = count( $variations_data );
		$needs_lazy_loading = $total_variations > 30;
		$wrapper_class = $needs_lazy_loading ? 'wcvip-vertical-text-list-wrapper' : '';
		?>
		<div class="<?php echo esc_attr( $wrapper_class ); ?>">
			<?php if ( ! $is_attribute_section ) : ?>
			<div class="wcvip-selected-variation-global" style="display: none;">
				<span class="wcvip-selected-label"><?php esc_html_e( 'Selected:', 'wc-variation-images-pro' ); ?></span>
				<span class="wcvip-selected-value"></span>
			</div>
			<?php endif; ?>
			<div class="wcvip-vertical-text-list" role="group" aria-label="<?php esc_attr_e( 'Product variation options', 'wc-variation-images-pro' ); ?>">
			<?php foreach ( $variations_data as $index => $variation ) : ?>
				<?php
				$is_available = $variation['available'];
				$variation_id = $variation['variation_id'];
				$variation_name = $variation['name'];
				$variation_price = $variation['price'];
				$stock_status = $is_available ? __( 'In Stock', 'wc-variation-images-pro' ) : __( 'Out of Stock', 'wc-variation-images-pro' );
				
				// Build tooltip content with variation details
				$tooltip_content = esc_attr( $variation_name );
				if ( ! empty( $variation_price ) ) {
					$tooltip_content .= ' - ' . wp_strip_all_tags( $variation_price );
				}
				$tooltip_content .= ' (' . esc_attr( $stock_status ) . ')';
				?>
				<button type="button"
						class="wcvip-text-box wcvip-tooltip-trigger"
						data-variation-id="<?php echo esc_attr( $variation_id ); ?>"
					 data-attributes="<?php echo esc_attr( json_encode( $variation['attributes'] ) ); ?>"
						data-variation-name="<?php echo esc_attr( $variation_name ); ?>"
						data-variation-price="<?php echo esc_attr( wp_strip_all_tags( $variation_price ) ); ?>"
						data-stock-status="<?php echo esc_attr( $stock_status ); ?>"
						<?php echo ! $is_available ? 'data-unavailable="true" aria-disabled="true"' : ''; ?>
						aria-label="<?php 
						// translators: %s is the variation name
						echo esc_attr( sprintf( __( 'Select variation: %s', 'wc-variation-images-pro' ), $variation_name ) ); 
						?>"
						aria-pressed="false"
						role="radio"
						aria-checked="false"
						tabindex="<?php echo $index === 0 ? '0' : '-1'; ?>"
						title="<?php echo esc_attr( $tooltip_content ); ?>"
						<?php if ( ! $is_available ) : ?>
							aria-describedby="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>"
						<?php endif; ?>>
					<span class="wcvip-text-box-content">
						<?php echo esc_html( $variation_name ); ?>
					</span>
					<?php if ( ! $is_available ) : ?>
						<span class="wcvip-stock-badge" id="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>" aria-hidden="true">
							<?php esc_html_e( 'Out of Stock', 'wc-variation-images-pro' ); ?>
						</span>
					<?php endif; ?>
					<span class="wcvip-tooltip" role="tooltip" aria-hidden="true">
						<span class="wcvip-tooltip-content">
							<?php echo esc_html( $variation_name ); ?>
							<span class="wcvip-tooltip-status"><?php echo esc_html( $stock_status ); ?></span>
						</span>
					</span>
				</button>
			<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Render vertical text selector for two attributes (with collapsible groups)
	 */
	private function render_vertical_text_two_attributes( $variations_data, $primary_attribute ) {
		global $product;
		
		if ( empty( $primary_attribute ) ) {
			// Fallback to single
			$this->render_vertical_text_single( $variations_data );
			return;
		}
		
		// Group variations by primary attribute
		$grouped = WCVIP_Attribute_Helper::group_variations_by_primary( $variations_data );
		
		// Get default attributes
		$default_attributes = $product->get_default_attributes();
		$default_primary_value = ! empty( $default_attributes[ $primary_attribute ] ) ? $default_attributes[ $primary_attribute ] : '';
		
		// If no default, use first group
		if ( empty( $default_primary_value ) && ! empty( $grouped ) ) {
			$default_primary_value = key( $grouped );
		}
		
		$primary_label = WCVIP_Attribute_Helper::get_attribute_display_name( $primary_attribute );
		
		?>
		<div class="wcvip-vertical-text-list-wrapper wcvip-multi-attribute">
			<?php foreach ( $grouped as $primary_value => $group_variations ) : ?>
				<?php
				$primary_display_value = WCVIP_Attribute_Helper::get_attribute_value_display_name( $primary_attribute, $primary_value );
				$is_default_group = ( $primary_value === $default_primary_value );
				?>
				<div class="wcvip-attribute-group <?php echo $is_default_group ? 'wcvip-group-active' : 'wcvip-group-collapsed'; ?>" 
					 data-primary-attribute="<?php echo esc_attr( $primary_attribute ); ?>"
					 data-primary-value="<?php echo esc_attr( $primary_value ); ?>">
					<button type="button" class="wcvip-group-header wcvip-group-toggle" aria-expanded="<?php echo $is_default_group ? 'true' : 'false'; ?>">
						<div class="wcvip-vertical-text-list-label">
							<span class="wcvip-label-attribute"><?php echo esc_html( $primary_label ); ?>:</span>
							<span class="wcvip-label-value"><?php echo esc_html( $primary_display_value ); ?></span>
							<span class="wcvip-group-count">(<?php echo count( $group_variations ); ?>)</span>
						</div>
						<span class="wcvip-group-toggle-icon" aria-hidden="true">▼</span>
					</button>
					<div class="wcvip-group-content" <?php echo ! $is_default_group ? 'style="display: none;"' : ''; ?>>
						<div class="wcvip-vertical-text-list" role="group" aria-label="<?php 
						// translators: %s is the primary attribute value
						echo esc_attr( sprintf( __( '%s options', 'wc-variation-images-pro' ), $primary_display_value ) ); 
						?>">
							<?php foreach ( $group_variations as $index => $variation ) : ?>
								<?php
								$is_available = $variation['available'];
								$variation_id = $variation['variation_id'];
								$variation_name = $variation['name'];
								$variation_price = $variation['price'];
								$stock_status = $is_available ? __( 'In Stock', 'wc-variation-images-pro' ) : __( 'Out of Stock', 'wc-variation-images-pro' );
								
								// Build tooltip content with variation details
								$tooltip_content = esc_attr( $variation_name );
								if ( ! empty( $variation_price ) ) {
									$tooltip_content .= ' - ' . wp_strip_all_tags( $variation_price );
								}
								$tooltip_content .= ' (' . esc_attr( $stock_status ) . ')';
								?>
								<button type="button"
										class="wcvip-text-box wcvip-tooltip-trigger"
										data-variation-id="<?php echo esc_attr( $variation_id ); ?>"
										data-attributes="<?php echo esc_attr( json_encode( $variation['attributes'] ) ); ?>"
										data-variation-name="<?php echo esc_attr( $variation_name ); ?>"
										data-variation-price="<?php echo esc_attr( wp_strip_all_tags( $variation_price ) ); ?>"
										data-stock-status="<?php echo esc_attr( $stock_status ); ?>"
										<?php echo ! $is_available ? 'data-unavailable="true" aria-disabled="true"' : ''; ?>
										aria-label="<?php 
										// translators: %s is the variation name
										echo esc_attr( sprintf( __( 'Select variation: %s', 'wc-variation-images-pro' ), $variation_name ) ); 
										?>"
										aria-pressed="false"
										role="radio"
										aria-checked="false"
										tabindex="<?php echo $index === 0 ? '0' : '-1'; ?>"
										title="<?php echo esc_attr( $tooltip_content ); ?>"
										<?php if ( ! $is_available ) : ?>
											aria-describedby="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>"
										<?php endif; ?>>
									<span class="wcvip-text-box-content">
										<?php echo esc_html( $variation_name ); ?>
									</span>
									<?php if ( ! $is_available ) : ?>
										<span class="wcvip-stock-badge" id="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>" aria-hidden="true">
											<?php esc_html_e( 'Out of Stock', 'wc-variation-images-pro' ); ?>
										</span>
									<?php endif; ?>
									<span class="wcvip-tooltip" role="tooltip" aria-hidden="true">
										<span class="wcvip-tooltip-content">
											<?php echo esc_html( $variation_name ); ?>
											<span class="wcvip-tooltip-status"><?php echo esc_html( $stock_status ); ?></span>
										</span>
									</span>
								</button>
							<?php endforeach; ?>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}
	
	/**
	 * Render vertical text selector for three+ attributes (show all with full names)
	 */
	private function render_vertical_text_multi( $variations_data ) {
		$total_variations = count( $variations_data );
		$needs_lazy_loading = $total_variations > 30;
		$wrapper_class = $needs_lazy_loading ? 'wcvip-vertical-text-list-wrapper' : '';
		?>
		<div class="<?php echo esc_attr( $wrapper_class ); ?>">
		<div class="wcvip-vertical-text-list" role="group" aria-label="<?php esc_attr_e( 'Product variation options', 'wc-variation-images-pro' ); ?>">
			<?php foreach ( $variations_data as $index => $variation ) : ?>
				<?php
				$is_available = $variation['available'];
				$variation_id = $variation['variation_id'];
				$variation_name = $variation['name'];
				$variation_price = $variation['price'];
				$stock_status = $is_available ? __( 'In Stock', 'wc-variation-images-pro' ) : __( 'Out of Stock', 'wc-variation-images-pro' );
				
				// Build tooltip content with variation details
				$tooltip_content = esc_attr( $variation_name );
				if ( ! empty( $variation_price ) ) {
					$tooltip_content .= ' - ' . wp_strip_all_tags( $variation_price );
				}
				$tooltip_content .= ' (' . esc_attr( $stock_status ) . ')';
				?>
				<button type="button"
						class="wcvip-text-box wcvip-tooltip-trigger"
						data-variation-id="<?php echo esc_attr( $variation_id ); ?>"
						data-attributes="<?php echo esc_attr( json_encode( $variation['attributes'] ) ); ?>"
						data-variation-name="<?php echo esc_attr( $variation_name ); ?>"
						data-variation-price="<?php echo esc_attr( wp_strip_all_tags( $variation_price ) ); ?>"
						data-stock-status="<?php echo esc_attr( $stock_status ); ?>"
						<?php echo ! $is_available ? 'data-unavailable="true" aria-disabled="true"' : ''; ?>
						aria-label="<?php 
						// translators: %s is the variation name
						echo esc_attr( sprintf( __( 'Select variation: %s', 'wc-variation-images-pro' ), $variation_name ) ); 
						?>"
						aria-pressed="false"
						role="radio"
						aria-checked="false"
						tabindex="<?php echo $index === 0 ? '0' : '-1'; ?>"
						title="<?php echo esc_attr( $tooltip_content ); ?>"
						<?php if ( ! $is_available ) : ?>
							aria-describedby="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>"
						<?php endif; ?>>
					<span class="wcvip-text-box-content">
						<?php echo esc_html( $variation_name ); ?>
					</span>
					<?php if ( ! $is_available ) : ?>
						<span class="wcvip-stock-badge" id="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>" aria-hidden="true">
							<?php esc_html_e( 'Out of Stock', 'wc-variation-images-pro' ); ?>
						</span>
					<?php endif; ?>
					<span class="wcvip-tooltip" role="tooltip" aria-hidden="true">
						<span class="wcvip-tooltip-content">
							<?php echo esc_html( $variation_name ); ?>
							<span class="wcvip-tooltip-status"><?php echo esc_html( $stock_status ); ?></span>
						</span>
					</span>
				</button>
			<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Render grid selector
	 * Enhanced with tooltips
	 */
	private function render_grid_selector( $variations_data ) {
		$lazy_attr = $this->get_lazy_loading_attr();
		?>
		<div class="wcvip-grid-layout">
			<?php foreach ( $variations_data as $index => $variation ) : ?>
				<?php if ( ! empty( $variation['images'][0] ) ) : ?>
					<?php
					$is_available = $variation['available'];
					$variation_id = $variation['variation_id'];
					$variation_name = $variation['name'];
					$stock_status = $is_available ? __( 'In Stock', 'wc-variation-images-pro' ) : __( 'Out of Stock', 'wc-variation-images-pro' );
					$tooltip_content = esc_attr( $variation_name ) . ' (' . esc_attr( $stock_status ) . ')';
					?>
					<div class="wcvip-grid-thumb wcvip-tooltip-trigger" 
						 data-variation-id="<?php echo esc_attr( $variation_id ); ?>"
						 data-attributes="<?php echo esc_attr( json_encode( $variation['attributes'] ) ); ?>"
						 title="<?php echo esc_attr( $tooltip_content ); ?>">
						<img src="<?php echo esc_url( $variation['images'][0]['thumbnail'] ); ?>" 
							 alt="<?php echo esc_attr( $variation['images'][0]['alt'] ?: $variation['name'] ); ?>"
									 <?php echo wp_kses_post( $lazy_attr ); ?>>
						<span class="wcvip-tooltip" role="tooltip" aria-hidden="true">
							<span class="wcvip-tooltip-content">
								<?php echo esc_html( $variation_name ); ?>
								<span class="wcvip-tooltip-status"><?php echo esc_html( $stock_status ); ?></span>
							</span>
						</span>
					</div>
				<?php endif; ?>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Render horizontal strip selector
	 * Enhanced with tooltips
	 */
	private function render_strip_selector( $variations_data ) {
		$lazy_attr = $this->get_lazy_loading_attr();
		?>
		<div class="wcvip-horizontal-strip">
			<?php foreach ( $variations_data as $index => $variation ) : ?>
				<?php if ( ! empty( $variation['images'][0] ) ) : ?>
					<?php
					$is_available = $variation['available'];
					$variation_id = $variation['variation_id'];
					$variation_name = $variation['name'];
					$stock_status = $is_available ? __( 'In Stock', 'wc-variation-images-pro' ) : __( 'Out of Stock', 'wc-variation-images-pro' );
					$tooltip_content = esc_attr( $variation_name ) . ' (' . esc_attr( $stock_status ) . ')';
					?>
					<div class="wcvip-strip-item wcvip-tooltip-trigger" 
						 data-variation-id="<?php echo esc_attr( $variation_id ); ?>"
						 data-attributes="<?php echo esc_attr( json_encode( $variation['attributes'] ) ); ?>"
						 title="<?php echo esc_attr( $tooltip_content ); ?>">
						<img src="<?php echo esc_url( $variation['images'][0]['thumbnail'] ); ?>" 
							 alt="<?php echo esc_attr( $variation['images'][0]['alt'] ?: $variation['name'] ); ?>"
									 <?php echo wp_kses_post( $lazy_attr ); ?>>
						<span class="wcvip-tooltip" role="tooltip" aria-hidden="true">
							<span class="wcvip-tooltip-content">
								<?php echo esc_html( $variation_name ); ?>
								<span class="wcvip-tooltip-status"><?php echo esc_html( $stock_status ); ?></span>
							</span>
						</span>
					</div>
				<?php endif; ?>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Render radio buttons selector
	 * Enhanced with tooltips
	 */
	private function render_radio_selector( $variations_data ) {
		$lazy_attr = $this->get_lazy_loading_attr();
		?>
		<div class="wcvip-radio-selector">
			<?php foreach ( $variations_data as $index => $variation ) : ?>
				<?php if ( ! empty( $variation['images'][0] ) ) : ?>
					<?php
					$is_available = $variation['available'];
					$variation_id = $variation['variation_id'];
					$variation_name = $variation['name'];
					$stock_status = $is_available ? __( 'In Stock', 'wc-variation-images-pro' ) : __( 'Out of Stock', 'wc-variation-images-pro' );
					$tooltip_content = esc_attr( $variation_name ) . ' (' . esc_attr( $stock_status ) . ')';
					?>
					<label class="wcvip-radio-item wcvip-tooltip-trigger" 
						   data-variation-id="<?php echo esc_attr( $variation_id ); ?>"
						   data-attributes="<?php echo esc_attr( json_encode( $variation['attributes'] ) ); ?>"
									 title="<?php echo esc_attr( $tooltip_content ); ?>">
						<input type="radio" name="wcvip_variation" value="<?php echo esc_attr( $variation['variation_id'] ); ?>">
						<img src="<?php echo esc_url( $variation['images'][0]['thumbnail'] ); ?>" 
							 alt="<?php echo esc_attr( $variation['images'][0]['alt'] ?: $variation['name'] ); ?>"
									 <?php echo wp_kses_post( $lazy_attr ); ?>>
						<span><?php echo esc_html( $variation['name'] ); ?></span>
						<span class="wcvip-tooltip" role="tooltip" aria-hidden="true">
							<span class="wcvip-tooltip-content">
								<?php echo esc_html( $variation_name ); ?>
								<span class="wcvip-tooltip-status"><?php echo esc_html( $stock_status ); ?></span>
							</span>
						</span>
					</label>
				<?php endif; ?>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Get color attribute name for a product
	 */
	private function get_color_attribute_name( $product ) {
		$attributes = $product->get_attributes();
		foreach ( $attributes as $attribute_name => $attribute ) {
			$lower_name = strtolower( $attribute_name );
			if ( strpos( $lower_name, 'color' ) !== false || strpos( $lower_name, 'colour' ) !== false ) {
				return $attribute_name;
			}
		}
		return null;
	}

	/**
	 * Check if a specific attribute key is a color attribute
	 *
	 * @param string $attribute_key The attribute key to check (e.g., 'attribute_pa_color' or 'attribute_color')
	 * @return bool True if the attribute is a color attribute, false otherwise
	 */
	private function is_color_attribute( $attribute_key ) {
		// Remove 'attribute_' prefix if present
		$clean_key = str_replace( 'attribute_', '', $attribute_key );
		// Remove 'pa_' prefix if present (taxonomy attributes)
		$clean_key = str_replace( 'pa_', '', $clean_key );
		
		$lower_key = strtolower( $clean_key );
		
		// Check if the attribute name contains 'color' or 'colour'
		if ( strpos( $lower_key, 'color' ) !== false || strpos( $lower_key, 'colour' ) !== false ) {
			return true;
		}
		
		return false;
	}

	/**
	 * Get color swatches data for product variations
	 */
	private function get_color_swatches_data( $product ) {
		$color_attr_name = $this->get_color_attribute_name( $product );
		if ( ! $color_attr_name ) {
			return null;
		}

		$variation_ids = $product->get_children();
		$swatches = array();

		// Check if this is a taxonomy attribute (starts with pa_)
		$is_taxonomy = strpos( $color_attr_name, 'pa_' ) === 0;
		
		// Check if it's a custom attribute by checking if taxonomy exists
		$taxonomy = wc_attribute_taxonomy_name( str_replace( 'pa_', '', $color_attr_name ) );
		$is_custom_attribute = ! $is_taxonomy && ! taxonomy_exists( $taxonomy );

		foreach ( $variation_ids as $variation_id ) {
			$variation = wc_get_product( $variation_id );
			if ( ! $variation ) {
				continue;
			}

			$attributes = $variation->get_variation_attributes();
			
			// Handle both taxonomy and custom attribute formats
			// Taxonomy: pa_color -> attribute_pa_color
			// Custom: color -> attribute_color
			$color_value = null;
			$attribute_key = null;
			
			// Try taxonomy format first (pa_color -> attribute_pa_color)
			if ( $is_taxonomy && isset( $attributes[ 'attribute_' . $color_attr_name ] ) ) {
				$color_value = $attributes[ 'attribute_' . $color_attr_name ];
				$attribute_key = 'attribute_' . $color_attr_name;
			} elseif ( isset( $attributes[ 'attribute_' . $color_attr_name ] ) ) {
				// Custom attribute format (color -> attribute_color)
				$color_value = $attributes[ 'attribute_' . $color_attr_name ];
				$attribute_key = 'attribute_' . $color_attr_name;
			} elseif ( isset( $attributes[ $color_attr_name ] ) ) {
				// Direct attribute name (fallback)
			$color_value = $attributes[ $color_attr_name ];
				$attribute_key = $color_attr_name;
			}
			
			if ( empty( $color_value ) ) {
				continue;
			}

			$term_slug = sanitize_title( $color_value );
			$color_name = $color_value;
			$color_hex = '';

			// Try taxonomy attribute first (with term meta support)
			if ( $is_taxonomy && taxonomy_exists( $taxonomy ) ) {
			$term = get_term_by( 'slug', $term_slug, $taxonomy );
				if ( $term ) {
					$color_name = $term->name;
					// Get color hex from term meta - check multiple keys for plugin compatibility
					$term_meta_keys = array(
						'wcvip_color', // Our plugin
						'product_attribute_color', // WooCommerce Color/Image Swatches
						'color', // Generic
						'pa_color', // Alternative format
					);
					
					foreach ( $term_meta_keys as $meta_key ) {
						$color_hex = get_term_meta( $term->term_id, $meta_key, true );
						if ( ! empty( $color_hex ) ) {
							break; // Found a color, stop checking
						}
					}
					
			if ( empty( $color_hex ) ) {
				// Try to parse color from term name if hex not set
				$color_hex = $this->parse_color_from_name( $term->name );
					}
				}
			}

			// For custom attributes or if taxonomy parsing failed, parse from value name
			if ( empty( $color_hex ) ) {
				$color_hex = $this->parse_color_from_name( $color_value );
			}

			// If still no hex found, try to get variation image as fallback
			$variation_image_url = '';
			if ( empty( $color_hex ) ) {
				$variation_image_id = $variation->get_image_id();
				if ( $variation_image_id ) {
					$variation_image_url = wp_get_attachment_image_url( $variation_image_id, 'thumbnail' );
				}
				
				// If no variation image, skip this variation (maintains backward compatibility)
				if ( empty( $variation_image_url ) ) {
					continue;
				}
			}

			// Only add unique color swatches
			if ( ! isset( $swatches[ $term_slug ] ) ) {
				$swatches[ $term_slug ] = array(
					'term_slug'         => $term_slug,
					'term_name'         => $color_name,
					'color_hex'         => $color_hex,
					'variation_id'      => $variation_id,
					'attributes'        => $attributes,
					'image_url'         => $variation_image_url, // Fallback image if hex not found
					'has_image_fallback' => ! empty( $variation_image_url ) && empty( $color_hex ),
				);
			}
		}

		return ! empty( $swatches ) ? $swatches : null;
	}

	/**
	 * Parse color hex from term name (enhanced with expanded color map and multi-word support)
	 */
	private function parse_color_from_name( $name ) {
		// First, try to extract hex code if present in the name
		if ( preg_match( '/#([a-f0-9]{3}|[a-f0-9]{6})\b/i', $name, $matches ) ) {
			$hex = '#' . $matches[1];
			// Expand 3-digit hex to 6-digit
			if ( strlen( $hex ) === 4 ) {
				$hex = '#' . $matches[1][0] . $matches[1][0] . $matches[1][1] . $matches[1][1] . $matches[1][2] . $matches[1][2];
			}
			return strtolower( $hex );
		}

		// Expanded color map with 50+ colors including variations
		$color_map = array(
			// Basic colors
			'red' => '#ff0000',
			'blue' => '#0000ff',
			'green' => '#008000',
			'yellow' => '#ffff00',
			'black' => '#000000',
			'white' => '#ffffff',
			'orange' => '#ffa500',
			'purple' => '#800080',
			'pink' => '#ffc0cb',
			'gray' => '#808080',
			'grey' => '#808080',
			'brown' => '#a52a2a',
			'cyan' => '#00ffff',
			'magenta' => '#ff00ff',
			'silver' => '#c0c0c0',
			'gold' => '#ffd700',
			'beige' => '#f5f5dc',
			'ivory' => '#fffff0',
			'navy' => '#000080',
			'maroon' => '#800000',
			'olive' => '#808000',
			'lime' => '#00ff00',
			'aqua' => '#00ffff',
			'teal' => '#008080',
			'indigo' => '#4b0082',
			'violet' => '#ee82ee',
			'coral' => '#ff7f50',
			'salmon' => '#fa8072',
			'turquoise' => '#40e0d0',
			'khaki' => '#f0e68c',
			'plum' => '#dda0dd',
			'tan' => '#d2b48c',
			'crimson' => '#dc143c',
			'lavender' => '#e6e6fa',
			'peach' => '#ffdab9',
			'mint' => '#f5fffa',
			'cream' => '#fffdd0',
			'charcoal' => '#36454f',
			'burgundy' => '#800020',
			'emerald' => '#50c878',
			'amber' => '#ffbf00',
			'copper' => '#b87333',
			'brass' => '#b5a642',
			'bronze' => '#cd7f32',
			// Multi-word colors - light variations
			'light blue' => '#add8e6',
			'light green' => '#90ee90',
			'light gray' => '#d3d3d3',
			'light grey' => '#d3d3d3',
			'light pink' => '#ffb6c1',
			'light yellow' => '#ffffe0',
			'light red' => '#ffcccb',
			'light orange' => '#ffd580',
			'light purple' => '#c8a2c8',
			'light brown' => '#b5651d',
			'light cyan' => '#e0ffff',
			'light salmon' => '#ffa07a',
			'light coral' => '#f08080',
			'light steel blue' => '#b0c4de',
			'light sea green' => '#20b2aa',
			'light sky blue' => '#87cefa',
			'light slate gray' => '#778899',
			'light slate grey' => '#778899',
			// Multi-word colors - dark variations
			'dark blue' => '#00008b',
			'dark green' => '#006400',
			'dark gray' => '#a9a9a9',
			'dark grey' => '#a9a9a9',
			'dark red' => '#8b0000',
			'dark orange' => '#ff8c00',
			'dark purple' => '#4b0082',
			'dark pink' => '#c71585',
			'dark brown' => '#654321',
			'dark cyan' => '#008b8b',
			'dark salmon' => '#e9967a',
			'dark khaki' => '#bdb76b',
			'dark olive green' => '#556b2f',
			'dark slate gray' => '#2f4f4f',
			'dark slate grey' => '#2f4f4f',
			'dark sea green' => '#8fbc8f',
			'dark turquoise' => '#00ced1',
			'dark violet' => '#9400d3',
			'dark magenta' => '#8b008b',
			// Multi-word colors - other variations
			'navy blue' => '#000080',
			'royal blue' => '#4169e1',
			'sky blue' => '#87ceeb',
			'powder blue' => '#b0e0e6',
			'steel blue' => '#4682b4',
			'cornflower blue' => '#6495ed',
			'midnight blue' => '#191970',
			'forest green' => '#228b22',
			'sea green' => '#2e8b57',
			'spring green' => '#00ff7f',
			'olive green' => '#808000',
			'lime green' => '#32cd32',
			'pale green' => '#98fb98',
			'yellow green' => '#9acd32',
			'hot pink' => '#ff69b4',
			'deep pink' => '#ff1493',
			'pale pink' => '#fadadd',
			'rose pink' => '#ff66cc',
			'cherry red' => '#de3163',
			'fire red' => '#ff4500',
			'blood red' => '#8b0000',
			'brick red' => '#cb4154',
			'burnt orange' => '#cc5500',
			'apricot' => '#fbceb1',
			'peach orange' => '#ffcc99',
			'golden yellow' => '#ffd700',
			'lemon yellow' => '#fff700',
			'canary yellow' => '#ffef00',
			'champagne' => '#f7e7ce',
			'beige tan' => '#f5f5dc',
			'sand' => '#c2b280',
			'wheat' => '#f5deb3',
			'almond' => '#efdecd',
			'coffee' => '#6f4e37',
			'chocolate' => '#7b3f00',
			'cocoa' => '#d2691e',
			'caramel' => '#af6e4d',
			'honey' => '#f0fff0',
			'butter' => '#fffacd',
			'ivory white' => '#fffff0',
			'pearl white' => '#f8f6f0',
			'off white' => '#fafafa',
			'eggshell' => '#f0ead6',
			'bone' => '#e3dac9',
			'charcoal gray' => '#36454f',
			'charcoal grey' => '#36454f',
			'gunmetal' => '#2a3439',
			'slate gray' => '#708090',
			'slate grey' => '#708090',
			'ash gray' => '#b2beb5',
			'ash grey' => '#b2beb5',
			'smoke' => '#848884',
			'pewter' => '#e9eaec',
			'platinum' => '#e5e4e2',
			'rose gold' => '#e8b4b8',
			'copper red' => '#b87333',
			'rust' => '#b7410e',
			'terracotta' => '#e2725b',
			'cinnamon' => '#d2691e',
			'nutmeg' => '#683600',
			'clay' => '#b66a50',
			'sepia' => '#704214',
			'umber' => '#635147',
			'sienna' => '#a0522d',
			'ochre' => '#cc7722',
			'amber gold' => '#ffbf00',
			'brass gold' => '#b5a642',
			'antique gold' => '#b8860b',
			'metallic gold' => '#d4af37',
			'rose' => '#ff007f',
			'blush' => '#de5d83',
			'fuchsia' => '#ff00ff',
			'mauve' => '#e0b0ff',
			'periwinkle' => '#ccccff',
			'lavender blue' => '#e6e6fa',
			'cornflower' => '#6495ed',
			'azure' => '#007fff',
			'cerulean' => '#007ba7',
			'cobalt' => '#0047ab',
			'ultramarine' => '#120a8f',
			'prussian blue' => '#003153',
			'egyptian blue' => '#1034a6',
			'egyptian' => '#1034a6',
			'pale blue' => '#afeeee',
			'ice blue' => '#99ffff',
			'baby blue' => '#89cff0',
			'robin egg blue' => '#00cccc',
			'turquoise blue' => '#00ced1',
			'aqua blue' => '#00ffff',
			'teal blue' => '#008080',
			'emerald green' => '#50c878',
			'jade' => '#00a86b',
			'mint green' => '#98ff98',
			'pine green' => '#01796f',
			'jungle green' => '#29ab87',
			'neon green' => '#39ff14',
			'chartreuse' => '#7fff00',
			'olive drab' => '#6b8e23',
			'army green' => '#4b5320',
			'camouflage green' => '#78866b',
			'kelly green' => '#4cbb17',
			'harlequin' => '#3fff00',
			'neon yellow' => '#ffff00',
			'canary' => '#ffef00',
			'banana' => '#ffe135',
			'corn' => '#fbec5d',
			'maize' => '#fbec5d',
			'goldenrod' => '#daa520',
			'amber yellow' => '#ffbf00',
			'apricot yellow' => '#fbceb1',
			'peach yellow' => '#ffcc99',
			'cream yellow' => '#fffdd0',
			'ivory yellow' => '#fffff0',
			'lemon' => '#fff700',
			'citron' => '#9fa91f',
			'citrus' => '#9fa91f',
			'orange red' => '#ff4500',
			'red orange' => '#ff4500',
			'coral red' => '#ff7f50',
			'salmon pink' => '#fa8072',
			'pink red' => '#ff1493',
			'rose red' => '#c21e56',
			'crimson red' => '#dc143c',
			'burgundy red' => '#800020',
			'wine red' => '#722f37',
			'cherry' => '#de3163',
			'strawberry' => '#fc5a8d',
			'raspberry' => '#e30b5d',
			'cranberry' => '#9f000f',
			'grape' => '#6f2da8',
			'plum purple' => '#dda0dd',
			'lavender purple' => '#e6e6fa',
			'violet purple' => '#ee82ee',
			'orchid' => '#da70d6',
			'lilac' => '#c8a2c8',
			'amethyst' => '#9966cc',
			'eggplant' => '#614051',
			'aubergine' => '#614051',
			'wisteria' => '#c9a0dc',
			'iris' => '#5a4fcf',
			'indigo purple' => '#4b0082',
			'royal purple' => '#7851a9',
			'tyrian purple' => '#66023c',
			'byzantium' => '#702963',
			'puce' => '#cc8899',
			'thistle' => '#d8bfd8',
			'heliotrope' => '#df73ff',
			'veronica' => '#a020f0',
			'medium purple' => '#9370db',
			'blue violet' => '#8a2be2',
			'purple blue' => '#663399',
			'periwinkle blue' => '#ccccff',
			'lavender blue' => '#e6e6fa',
			'pale purple' => '#fae6fa',
			'light purple' => '#c8a2c8',
			'dark purple' => '#4b0082',
			'deep purple' => '#36013f',
			'rich purple' => '#6a0dad',
			'vibrant purple' => '#9d00ff',
			'neon purple' => '#bc13fe',
			'hot purple' => '#a020f0',
			'electric purple' => '#bf00ff',
			'neon pink' => '#ff1493',
			'hot pink' => '#ff69b4',
			'deep pink' => '#ff1493',
			'bright pink' => '#ff007f',
			'vibrant pink' => '#ff10f0',
			'neon pink' => '#ff1493',
			'electric pink' => '#ff1493',
			'fuchsia pink' => '#ff00ff',
			'magenta pink' => '#ff00ff',
			'rose pink' => '#ff66cc',
			'blush pink' => '#de5d83',
			'peach pink' => '#ffdab9',
			'salmon pink' => '#fa8072',
			'coral pink' => '#ff7f50',
			'dusty pink' => '#d4a5a5',
			'powder pink' => '#ffb6c1',
			'pale pink' => '#fadadd',
			'light pink' => '#ffb6c1',
			'medium pink' => '#ff69b4',
			'dark pink' => '#c71585',
			'deep pink' => '#ff1493',
			'rich pink' => '#ff007f',
			'vibrant pink' => '#ff10f0',
			'neon pink' => '#ff1493',
			'hot pink' => '#ff69b4',
			'electric pink' => '#ff1493',
			'fuchsia' => '#ff00ff',
			'magenta' => '#ff00ff',
			'rose' => '#ff007f',
			'blush' => '#de5d83',
			'peach' => '#ffdab9',
			'salmon' => '#fa8072',
			'coral' => '#ff7f50',
			'apricot' => '#fbceb1',
			'melon' => '#fdbcb4',
			'watermelon' => '#fc6c85',
			'strawberry' => '#fc5a8d',
			'raspberry' => '#e30b5d',
			'cherry' => '#de3163',
			'cranberry' => '#9f000f',
			'pomegranate' => '#c0392b',
			'blood orange' => '#ff4500',
			'tangerine' => '#ffa500',
			'clementine' => '#ff9500',
			'mandarin' => '#ffa500',
			'persimmon' => '#ec5800',
			'papaya' => '#ffefd5',
			'mango' => '#ffc324',
			'pineapple' => '#ffd700',
			'banana' => '#ffe135',
			'lemon' => '#fff700',
			'lime' => '#00ff00',
			'kiwi' => '#7cb518',
			'avocado' => '#568203',
			'olive' => '#808000',
			'pear' => '#d1e231',
			'apple green' => '#8db600',
			'apple red' => '#ff0800',
			'grape' => '#6f2da8',
			'grape purple' => '#6f2da8',
			'plum' => '#dda0dd',
			'plum purple' => '#dda0dd',
			'fig' => '#556b2f',
			'date' => '#6f4e37',
			'raisin' => '#2f1b14',
			'currant' => '#7f1d1d',
			'elderberry' => '#1e3a8a',
			'blueberry' => '#4f86f7',
			'blackberry' => '#4a0e4e',
			'boysenberry' => '#630330',
			'mulberry' => '#c54b8c',
			'gooseberry' => '#8b9a46',
			'cranberry' => '#9f000f',
			'strawberry' => '#fc5a8d',
			'raspberry' => '#e30b5d',
			'cherry' => '#de3163',
			'pomegranate' => '#c0392b',
			'watermelon' => '#fc6c85',
			'cantaloupe' => '#ffa62e',
			'honeydew' => '#f0fff0',
			'papaya' => '#ffefd5',
			'mango' => '#ffc324',
			'pineapple' => '#ffd700',
			'banana' => '#ffe135',
			'lemon' => '#fff700',
			'lime' => '#00ff00',
			'kiwi' => '#7cb518',
			'avocado' => '#568203',
			'olive' => '#808000',
			'pear' => '#d1e231',
			'apple green' => '#8db600',
			'apple red' => '#ff0800',
			'grape' => '#6f2da8',
			'plum' => '#dda0dd',
			'fig' => '#556b2f',
			'date' => '#6f4e37',
			'raisin' => '#2f1b14',
			'currant' => '#7f1d1d',
			'elderberry' => '#1e3a8a',
			'blueberry' => '#4f86f7',
			'blackberry' => '#4a0e4e',
			'boysenberry' => '#630330',
			'mulberry' => '#c54b8c',
			'gooseberry' => '#8b9a46',
			'cranberry' => '#9f000f',
			'strawberry' => '#fc5a8d',
			'raspberry' => '#e30b5d',
			'cherry' => '#de3163',
			'pomegranate' => '#c0392b',
			'watermelon' => '#fc6c85',
			'cantaloupe' => '#ffa62e',
			'honeydew' => '#f0fff0',
			'papaya' => '#ffefd5',
			'mango' => '#ffc324',
			'pineapple' => '#ffd700',
			'banana' => '#ffe135',
			'lemon' => '#fff700',
			'lime' => '#00ff00',
			'kiwi' => '#7cb518',
			'avocado' => '#568203',
			'olive' => '#808000',
			'pear' => '#d1e231',
			'apple green' => '#8db600',
			'apple red' => '#ff0800',
			'grape' => '#6f2da8',
			'plum' => '#dda0dd',
			'fig' => '#556b2f',
			'date' => '#6f4e37',
			'raisin' => '#2f1b14',
			'currant' => '#7f1d1d',
			'elderberry' => '#1e3a8a',
			'blueberry' => '#4f86f7',
			'blackberry' => '#4a0e4e',
			'boysenberry' => '#630330',
			'mulberry' => '#c54b8c',
			'gooseberry' => '#8b9a46',
		);

		$lower_name = strtolower( trim( $name ) );
		
		// Try exact match first
		if ( isset( $color_map[ $lower_name ] ) ) {
			return $color_map[ $lower_name ];
		}
		
		// Try partial matching for multi-word colors (e.g., "light blue", "navy blue")
		// Remove common prefixes/suffixes and try again
		$words = explode( ' ', $lower_name );
		if ( count( $words ) > 1 ) {
			// Try without first word (e.g., "light blue" -> "blue")
			$without_first = implode( ' ', array_slice( $words, 1 ) );
			if ( isset( $color_map[ $without_first ] ) ) {
				return $color_map[ $without_first ];
			}
			
			// Try without last word (e.g., "navy blue" -> "navy")
			$without_last = implode( ' ', array_slice( $words, 0, -1 ) );
			if ( isset( $color_map[ $without_last ] ) ) {
				return $color_map[ $without_last ];
			}
			
			// Try full multi-word match
			$full_match = implode( ' ', $words );
			if ( isset( $color_map[ $full_match ] ) ) {
				return $color_map[ $full_match ];
			}
		}
		
		// Try fuzzy matching - check if any color name is contained in the input
		foreach ( $color_map as $color_name => $hex ) {
			if ( strpos( $lower_name, $color_name ) !== false || strpos( $color_name, $lower_name ) !== false ) {
				return $hex;
			}
		}
		
		return '';
	}

	/**
	 * Render color swatches selector
	 * Enhanced with accessibility, tooltips, and improved UX
	 */
	private function render_color_swatches_selector( $variations_data ) {
		global $product;
		
		if ( ! $product ) {
			return;
		}

		// Check attribute count and get color attribute name
		$attribute_count = ! empty( $variations_data[0]['attribute_count'] ) ? $variations_data[0]['attribute_count'] : 1;
		$display_strategy = ! empty( $variations_data[0]['display_strategy'] ) ? $variations_data[0]['display_strategy'] : 'single';
		$primary_attribute = ! empty( $variations_data[0]['primary_attribute'] ) ? $variations_data[0]['primary_attribute'] : null;
		
		$color_attr_name = $this->get_color_attribute_name( $product );
		
		// If no color attribute found, fallback to horizontal text selector
		if ( ! $color_attr_name ) {
			$this->render_horizontal_text_selector( $variations_data );
			return;
		}
		
		// Determine if color is primary or secondary
		$color_attr_key = 'attribute_' . $color_attr_name;
		$is_color_primary = ( $color_attr_key === $primary_attribute || $color_attr_name === $primary_attribute );
		
		// Single attribute or color is primary: Show color swatches (original behavior)
		if ( $attribute_count === 1 || $display_strategy === 'single' || $is_color_primary ) {
			$this->render_color_swatches_single( $variations_data, $product );
			return;
		}
		
		// Two attributes with color as secondary: Group by primary, show colors as sub-options
		if ( $attribute_count === 2 || $display_strategy === 'two_attributes' ) {
			$this->render_color_swatches_two_attributes( $variations_data, $product, $primary_attribute, $color_attr_name );
			return;
		}
		
		// Three+ attributes: Show all with color swatches where applicable
		$this->render_color_swatches_multi( $variations_data, $product, $color_attr_name );
	}
	
	/**
	 * Render color swatches for single attribute or when color is primary
	 */
	private function render_color_swatches_single( $variations_data, $product ) {
		$swatches = $this->get_color_swatches_data( $product );
		if ( ! $swatches ) {
			// Fallback to horizontal text if no color data found
			$this->render_horizontal_text_selector( $variations_data );
			return;
		}

		// Get variation availability data
		$variation_availability = array();
		foreach ( $variations_data as $variation ) {
			$variation_availability[ $variation['variation_id'] ] = $variation['available'];
		}

		// Check if we're in attribute sections mode (skip individual selected label)
		$is_attribute_section = ! empty( $variations_data ) && ! empty( $variations_data[0]['is_attribute_section'] );

		$total_variations = count( $swatches );
		$needs_lazy_loading = $total_variations > 30;
		$wrapper_class = $needs_lazy_loading ? 'wcvip-color-swatches-wrapper ' : '';
		?>
		<div class="<?php echo esc_attr( $wrapper_class ); ?>wcvip-color-swatches">
			<?php if ( ! $is_attribute_section ) : ?>
			<div class="wcvip-selected-variation-global" style="display: none;">
				<span class="wcvip-selected-label"><?php esc_html_e( 'Selected:', 'wc-variation-images-pro' ); ?></span>
				<span class="wcvip-selected-value"></span>
			</div>
			<?php endif; ?>
			<div class="wcvip-color-swatches" role="group" aria-label="<?php esc_attr_e( 'Product color options', 'wc-variation-images-pro' ); ?>">
			<?php foreach ( $swatches as $index => $swatch ) : ?>
				<?php
				$variation_id = $swatch['variation_id'];
				$is_available = isset( $variation_availability[ $variation_id ] ) ? $variation_availability[ $variation_id ] : true;
				$color_name = $swatch['term_name'];
				$color_hex = ! empty( $swatch['color_hex'] ) ? $swatch['color_hex'] : '';
				$image_url = ! empty( $swatch['image_url'] ) ? $swatch['image_url'] : '';
				$has_image_fallback = ! empty( $swatch['has_image_fallback'] ) ? $swatch['has_image_fallback'] : false;
				$stock_status = $is_available ? __( 'In Stock', 'wc-variation-images-pro' ) : __( 'Out of Stock', 'wc-variation-images-pro' );
				
				// Get variation name from variations_data
				$variation_name = $color_name;
				foreach ( $variations_data as $variation ) {
					if ( $variation['variation_id'] === $variation_id ) {
						$variation_name = $variation['name'];
						break;
					}
				}
				
				// Build tooltip content
				$tooltip_content = esc_attr( $color_name ) . ' (' . esc_attr( $stock_status ) . ')';
				
				// Build style attribute - use image as background if no hex, otherwise use hex
				$swatch_style = '';
				if ( $has_image_fallback && ! empty( $image_url ) ) {
					$swatch_style = 'background-image: url(' . esc_url( $image_url ) . '); background-size: cover; background-position: center;';
				} elseif ( ! empty( $color_hex ) ) {
					$swatch_style = 'background-color: ' . esc_attr( $color_hex ) . ';';
				}
				?>
				<button type="button"
						class="wcvip-color-swatch wcvip-tooltip-trigger <?php echo $has_image_fallback ? 'wcvip-swatch-with-image' : ''; ?>"
						data-variation-id="<?php echo esc_attr( $variation_id ); ?>"
					 data-attributes="<?php echo esc_attr( json_encode( $swatch['attributes'] ) ); ?>"
						data-variation-name="<?php echo esc_attr( $variation_name ); ?>"
						data-color-name="<?php echo esc_attr( $color_name ); ?>"
						data-color-hex="<?php echo esc_attr( $color_hex ); ?>"
						data-stock-status="<?php echo esc_attr( $stock_status ); ?>"
						<?php if ( ! empty( $swatch_style ) ) : ?>
							style="<?php echo esc_attr( $swatch_style ); ?>"
						<?php endif; ?>
						<?php echo ! $is_available ? 'data-unavailable="true" aria-disabled="true"' : ''; ?>
						aria-label="<?php 
						// translators: %s is the color name
						echo esc_attr( sprintf( __( 'Select color: %s', 'wc-variation-images-pro' ), $color_name ) ); 
						?>"
						aria-pressed="false"
						role="radio"
						aria-checked="false"
						tabindex="<?php echo $index === 0 ? '0' : '-1'; ?>"
						title="<?php echo esc_attr( $tooltip_content ); ?>"
						<?php if ( ! $is_available ) : ?>
							aria-describedby="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>"
						<?php endif; ?>>
					<?php if ( ! $is_available ) : ?>
						<span class="wcvip-swatch-unavailable-overlay" id="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>" aria-hidden="true"></span>
					<?php endif; ?>
					<span class="wcvip-tooltip" role="tooltip" aria-hidden="true">
						<span class="wcvip-tooltip-content">
							<?php echo esc_html( $color_name ); ?>
							<span class="wcvip-tooltip-status"><?php echo esc_html( $stock_status ); ?></span>
						</span>
					</span>
				</button>
			<?php endforeach; ?>
			</div>
		</div>
		<?php
	}
	
	/**
	 * Render color swatches for two attributes (color as secondary)
	 */
	private function render_color_swatches_two_attributes( $variations_data, $product, $primary_attribute, $color_attr_name ) {
		global $product;
		
		if ( empty( $primary_attribute ) ) {
			// Fallback to single color swatches
			$this->render_color_swatches_single( $variations_data, $product );
			return;
		}
		
		// Group variations by primary attribute
		$grouped = WCVIP_Attribute_Helper::group_variations_by_primary( $variations_data );
		
		// Get default attributes
		$default_attributes = $product->get_default_attributes();
		$default_primary_value = ! empty( $default_attributes[ $primary_attribute ] ) ? $default_attributes[ $primary_attribute ] : '';
		
		// If no default, use first group
		if ( empty( $default_primary_value ) && ! empty( $grouped ) ) {
			$default_primary_value = key( $grouped );
		}
		
		$primary_label = WCVIP_Attribute_Helper::get_attribute_display_name( $primary_attribute );
		
		// Get variation availability data
		$variation_availability = array();
		foreach ( $variations_data as $variation ) {
			$variation_availability[ $variation['variation_id'] ] = $variation['available'];
		}
		
		// Check if we need lazy loading (count total variations across all groups)
		$total_variations = count( $variations_data );
		$needs_lazy_loading = $total_variations > 30;
		$wrapper_class = $needs_lazy_loading ? 'wcvip-color-swatches-wrapper ' : '';
		?>
		<div class="<?php echo esc_attr( $wrapper_class ); ?>wcvip-color-swatches wcvip-multi-attribute">
			<div class="wcvip-selected-variation-global" style="display: none;">
				<span class="wcvip-selected-label"><?php esc_html_e( 'Selected:', 'wc-variation-images-pro' ); ?></span>
				<span class="wcvip-selected-value"></span>
			</div>
			<?php foreach ( $grouped as $primary_value => $group_variations ) : ?>
				<?php
				$primary_display_value = WCVIP_Attribute_Helper::get_attribute_value_display_name( $primary_attribute, $primary_value );
				$is_default_group = ( $primary_value === $default_primary_value );
				?>
				<div class="wcvip-attribute-group <?php echo $is_default_group ? 'wcvip-group-active' : 'wcvip-group-collapsed'; ?>" 
					 data-primary-attribute="<?php echo esc_attr( $primary_attribute ); ?>"
					 data-primary-value="<?php echo esc_attr( $primary_value ); ?>">
					<button type="button" class="wcvip-group-header wcvip-group-toggle" aria-expanded="<?php echo $is_default_group ? 'true' : 'false'; ?>">
						<div class="wcvip-color-swatches-group-header">
							<span class="wcvip-label-attribute"><?php echo esc_html( $primary_label ); ?>:</span>
							<span class="wcvip-label-value"><?php echo esc_html( $primary_display_value ); ?></span>
							<span class="wcvip-group-count">(<?php echo count( $group_variations ); ?>)</span>
						</div>
						<span class="wcvip-group-toggle-icon" aria-hidden="true">▼</span>
					</button>
					<div class="wcvip-group-content" <?php echo ! $is_default_group ? 'style="display: none;"' : ''; ?>>
						<div class="wcvip-color-swatches-group" role="group" aria-label="<?php 
						// translators: %s is the primary attribute value
						echo esc_attr( sprintf( __( '%s color options', 'wc-variation-images-pro' ), $primary_display_value ) ); 
						?>">
						<?php
						$swatch_index = 0;
						foreach ( $group_variations as $variation ) : 
							// Get color value from variation
							$color_value = '';
							$color_hex = '';
							$color_name = '';
							
							$color_attr_key = 'attribute_' . $color_attr_name;
							if ( isset( $variation['attributes'][ $color_attr_key ] ) ) {
								$color_value = $variation['attributes'][ $color_attr_key ];
							} elseif ( isset( $variation['attributes'][ $color_attr_name ] ) ) {
								$color_value = $variation['attributes'][ $color_attr_name ];
							}
							
							if ( empty( $color_value ) ) {
								continue;
							}
							
							// Get color hex and name
							$color_hex = $this->get_color_hex_for_value( $color_attr_name, $color_value );
							$color_name = WCVIP_Attribute_Helper::get_attribute_value_display_name( $color_attr_key, $color_value );
							
							// If no hex found, try to get variation image as fallback
							$variation_image_url = '';
							$has_image_fallback = false;
							if ( empty( $color_hex ) ) {
								$variation_image_id = $variation->get_image_id();
								if ( $variation_image_id ) {
									$variation_image_url = wp_get_attachment_image_url( $variation_image_id, 'thumbnail' );
									$has_image_fallback = ! empty( $variation_image_url );
								}
							}
							
							$variation_id = $variation['variation_id'];
							$is_available = isset( $variation_availability[ $variation_id ] ) ? $variation_availability[ $variation_id ] : true;
							$stock_status = $is_available ? __( 'In Stock', 'wc-variation-images-pro' ) : __( 'Out of Stock', 'wc-variation-images-pro' );
							$variation_name = $variation['name'];
							$tooltip_content = esc_attr( $color_name ) . ' (' . esc_attr( $stock_status ) . ')';
							
							// Build style attribute - use image as background if no hex, otherwise use hex
							$swatch_style = '';
							if ( $has_image_fallback && ! empty( $variation_image_url ) ) {
								$swatch_style = 'background-image: url(' . esc_url( $variation_image_url ) . '); background-size: cover; background-position: center;';
							} elseif ( ! empty( $color_hex ) ) {
								$swatch_style = 'background-color: ' . esc_attr( $color_hex ) . ';';
							}
							?>
							<button type="button"
									class="wcvip-color-swatch wcvip-tooltip-trigger <?php echo $has_image_fallback ? 'wcvip-swatch-with-image' : ''; ?>"
									data-variation-id="<?php echo esc_attr( $variation_id ); ?>"
									data-attributes="<?php echo esc_attr( json_encode( $variation['attributes'] ) ); ?>"
									data-variation-name="<?php echo esc_attr( $variation_name ); ?>"
									data-color-name="<?php echo esc_attr( $color_name ); ?>"
									data-color-hex="<?php echo esc_attr( $color_hex ); ?>"
									data-stock-status="<?php echo esc_attr( $stock_status ); ?>"
									<?php if ( ! empty( $swatch_style ) ) : ?>
										style="<?php echo esc_attr( $swatch_style ); ?>"
									<?php endif; ?>
									<?php echo ! $is_available ? 'data-unavailable="true" aria-disabled="true"' : ''; ?>
									aria-label="<?php 
						// translators: %s is the color name
						echo esc_attr( sprintf( __( 'Select color: %s', 'wc-variation-images-pro' ), $color_name ) ); 
						?>"
									aria-pressed="false"
									role="radio"
									aria-checked="false"
									tabindex="<?php echo ( $is_default_group && $swatch_index === 0 ) ? '0' : '-1'; ?>"
									title="<?php echo esc_attr( $tooltip_content ); ?>"
									<?php if ( ! $is_available ) : ?>
										aria-describedby="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>"
									<?php endif; ?>>
								<?php if ( ! $is_available ) : ?>
									<span class="wcvip-swatch-unavailable-overlay" id="wcvip-unavailable-<?php echo esc_attr( $variation_id ); ?>" aria-hidden="true"></span>
								<?php endif; ?>
								<span class="wcvip-tooltip" role="tooltip" aria-hidden="true">
									<span class="wcvip-tooltip-content">
										<?php echo esc_html( $color_name ); ?>
										<span class="wcvip-tooltip-status"><?php echo esc_html( $stock_status ); ?></span>
									</span>
								</span>
							</button>
							<?php $swatch_index++; ?>
						<?php endforeach; ?>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}
	
	/**
	 * Render color swatches for three+ attributes
	 */
	private function render_color_swatches_multi( $variations_data, $product, $color_attr_name ) {
		// For 3+ attributes, show all variations but use color swatches where color attribute exists
		// Fallback to horizontal text selector for better clarity
		$this->render_horizontal_text_selector( $variations_data );
	}
	
	/**
	 * Get color hex for a color attribute value
	 */
	private function get_color_hex_for_value( $color_attr_name, $color_value ) {
		// Check if it's a taxonomy
		$is_taxonomy = strpos( $color_attr_name, 'pa_' ) === 0;
		$taxonomy = $is_taxonomy ? $color_attr_name : wc_attribute_taxonomy_name( $color_attr_name );
		
		if ( $is_taxonomy && taxonomy_exists( $taxonomy ) ) {
			$term = get_term_by( 'slug', $color_value, $taxonomy );
			if ( $term ) {
				// Check multiple term meta keys for plugin compatibility
				$term_meta_keys = array(
					'wcvip_color', // Our plugin
					'product_attribute_color', // WooCommerce Color/Image Swatches
					'color', // Generic
					'pa_color', // Alternative format
				);
				
				foreach ( $term_meta_keys as $meta_key ) {
					$color_hex = get_term_meta( $term->term_id, $meta_key, true );
					if ( ! empty( $color_hex ) ) {
						return $color_hex;
					}
				}
			}
		}
		
		// Try to parse color from value name
		return $this->parse_color_from_name( $color_value );
	}

	/**
	 * AJAX: Save design from preview mode
	 */
	public function ajax_save_preview_design() {
		// Check nonce and log failures
		if ( ! check_ajax_referer( 'wcvip-save-preview', 'nonce', false ) ) {
			WCVIP_Security_Logger::log(
				'nonce_failed',
				'Failed nonce verification for ajax_save_preview_design',
				array(
					'action' => 'ajax_save_preview_design',
					'nonce' => isset( $_POST['nonce'] ) ? 'present' : 'missing',
				)
			);
			wp_send_json_error( array( 'message' => __( 'Security check failed', 'wc-variation-images-pro' ) ) );
		}

		// Check user capabilities
		if ( ! current_user_can( 'edit_products' ) ) {
			WCVIP_Security_Logger::log(
				'permission_denied',
				'User attempted to save preview design without edit_products permission',
				array(
					'user_id' => get_current_user_id(),
				)
			);
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions', 'wc-variation-images-pro' ) ) );
		}

		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		$style = isset( $_POST['style'] ) ? sanitize_text_field( wp_unslash( $_POST['style'] ) ) : '';

		if ( ! $product_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid product ID', 'wc-variation-images-pro' ) ) );
		}

		// Verify product exists and user can edit it
		$product = wc_get_product( $product_id );
		if ( ! $product || ! current_user_can( 'edit_product', $product_id ) ) {
			WCVIP_Security_Logger::log(
				'permission_denied',
				'User attempted to save preview design for product without permission',
				array(
					'product_id' => $product_id,
					'user_id' => get_current_user_id(),
				)
			);
			wp_send_json_error( array( 'message' => __( 'Invalid product or insufficient permissions', 'wc-variation-images-pro' ) ) );
		}

		// Save product-specific style
		if ( ! empty( $style ) ) {
			update_post_meta( $product_id, '_wcvip_display_style', $style );
		}

		// Return success with redirect URL (remove preview parameters)
		$redirect_url = remove_query_arg( array( 'wcvip_preview', 'wcvip_style', 'wcvip_nonce' ), get_permalink( $product_id ) );
		$designer_url = admin_url( 'admin.php?page=wcvip-visual-designer&product_id=' . $product_id );

		wp_send_json_success( array(
			'message' => __( 'Design saved successfully!', 'wc-variation-images-pro' ),
			'redirect_url' => $redirect_url,
			'designer_url' => $designer_url,
		) );
	}
}

