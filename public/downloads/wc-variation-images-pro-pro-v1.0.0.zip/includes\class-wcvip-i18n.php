<?php
/**
 * Define the internationalization functionality
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Define the internationalization functionality
 */
class WCVIP_i18n {

	/**
	 * Load the plugin text domain for translation
	 * 
	 * Note: For WordPress.org hosted plugins, translations are automatically loaded.
	 * This function is kept for backward compatibility with non-WordPress.org installations.
	 */
	public function load_plugin_textdomain() {
		// phpcs:ignore PluginCheck.CodeAnalysis.DiscouragedFunctions.load_plugin_textdomainFound -- Kept for backward compatibility, WordPress.org will auto-load translations
		load_plugin_textdomain(
			'shalconnects-variation-images',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);
	}
}

