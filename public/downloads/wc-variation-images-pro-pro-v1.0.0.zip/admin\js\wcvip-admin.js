jQuery(document).ready(function ($) {

    // Variables
    let searchTerm = '';
    let filterStatus = 'all';
    let sortBy = 'name';
    let sortOrder = 'asc';
    let currentPage = 1;
    let itemsPerPage = 25;
    let allProducts = []; // Store all products for client-side filtering
    let searchTimeout = null; // For debouncing search
    let expandedProductId = null; // Track which product row is expanded

    // Initialize
    init();

    function init() {
        // Immediately replace initial loading with skeleton
        const container = $('#wcvip-products-container');
        if (container.find('.wcvip-initial-loading').length > 0) {
            container.html(renderSkeletonLoader());
        }
        loadProducts();
        setupEventListeners();
    }

    /**
     * Render skeleton loader
     */
    function renderSkeletonLoader() {
        let html = '<div class="wcvip-skeleton-loader">';
        
        // Stats skeleton
        html += '<div class="wcvip-skeleton-stats">';
        for (let i = 0; i < 4; i++) {
            html += '<div class="wcvip-skeleton-stat"></div>';
        }
        html += '</div>';
        
        // Filters skeleton
        html += '<div class="wcvip-skeleton-filters">';
        html += '<div class="wcvip-skeleton-filter-row">';
        html += '<div class="wcvip-skeleton-search"></div>';
        html += '<div class="wcvip-skeleton-sort"></div>';
        html += '</div>';
        html += '<div class="wcvip-skeleton-filter-row">';
        for (let i = 0; i < 4; i++) {
            html += '<div class="wcvip-skeleton-filter-btn"></div>';
        }
        html += '</div>';
        html += '</div>';
        
        // Table skeleton
        html += '<div class="wcvip-skeleton-table">';
        html += '<div class="wcvip-skeleton-table-header">';
        html += '<div class="wcvip-skeleton-table-header-cell"></div>';
        html += '<div class="wcvip-skeleton-table-header-cell"></div>';
        html += '<div class="wcvip-skeleton-table-header-cell"></div>';
        html += '<div class="wcvip-skeleton-table-header-cell"></div>';
        html += '<div class="wcvip-skeleton-table-header-cell"></div>';
        html += '<div class="wcvip-skeleton-table-header-cell"></div>';
        html += '</div>';
        
        // Table rows skeleton
        for (let i = 0; i < 5; i++) {
            html += '<div class="wcvip-skeleton-table-row">';
            html += '<div class="wcvip-skeleton-table-cell image"></div>';
            html += '<div class="wcvip-skeleton-table-cell"></div>';
            html += '<div class="wcvip-skeleton-table-cell"></div>';
            html += '<div class="wcvip-skeleton-table-cell"></div>';
            html += '<div class="wcvip-skeleton-table-cell"></div>';
            html += '<div class="wcvip-skeleton-table-cell actions"></div>';
            html += '</div>';
        }
        html += '</div>';
        
        html += '</div>';
        return html;
    }

    /**
     * Load products list
     */
    function loadProducts() {
        const container = $('#wcvip-products-container');
        const wrapper = container.closest('.wcvip-products-list');
        
        // If content exists and is not skeleton/initial loading, add overlay
        if (container.children().length > 0 && 
            !container.find('.wcvip-empty').length && 
            !container.find('.wcvip-skeleton-loader').length &&
            !container.find('.wcvip-initial-loading').length) {
            wrapper.addClass('wcvip-loading-overlay');
        } else if (!container.find('.wcvip-skeleton-loader').length && !container.find('.wcvip-initial-loading').length) {
            // Show skeleton if not already showing
            container.html(renderSkeletonLoader());
        }

        $.ajax({
            url: wcvipData.ajaxurl,
            type: 'POST',
            data: {
                action: 'wcvip_get_products',
                nonce: wcvipData.nonce
            },
            success: function (response) {
                wrapper.removeClass('wcvip-loading-overlay');
                if (response.success) {
                    allProducts = response.data; // Store products for client-side filtering
                    renderProducts(allProducts);
                } else {
                    container.html('<p>Error loading products.</p>');
                }
            },
            error: function () {
                wrapper.removeClass('wcvip-loading-overlay');
                container.html('<p>Error loading products.</p>');
            }
        });
    }

    /**
     * Render products list
     */
    function renderProducts(products) {
        const container = $('#wcvip-products-container');
        const wrapper = container.closest('.wcvip-products-list');

        if (products.length === 0) {
            container.html('<div class="wcvip-empty"><p>No variable products found. Create some variable products in WooCommerce to get started.</p></div>');
            return;
        }

        // Calculate stats
        const totalProducts = products.length;
        const totalVariations = products.reduce((sum, p) => sum + (p.variation_count || 0), 0);
        const totalVariationsWithImages = products.reduce((sum, p) => sum + (p.variations_with_images || 0), 0);
        const productsComplete = products.filter(p => {
            const count = p.variation_count || 0;
            const withImages = p.variations_with_images || 0;
            return count > 0 && withImages === count;
        }).length;

        // Sort products
        const sortedProducts = [...products].sort((a, b) => {
            let aVal, bVal;
            if (sortBy === 'name') {
                aVal = a.name.toLowerCase();
                bVal = b.name.toLowerCase();
            } else if (sortBy === 'sku') {
                aVal = (a.sku || '').toLowerCase();
                bVal = (b.sku || '').toLowerCase();
            } else if (sortBy === 'variations') {
                aVal = a.variation_count || 0;
                bVal = b.variation_count || 0;
            } else if (sortBy === 'images') {
                aVal = a.variations_with_images || 0;
                bVal = b.variations_with_images || 0;
            } else {
                return 0;
            }
            if (sortBy === 'name' || sortBy === 'sku') {
                return sortOrder === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
                } else {
                return sortOrder === 'asc' ? aVal - bVal : bVal - aVal;
            }
        });

        // Filter products
        const filteredProducts = sortedProducts.filter(product => {
            const matchesSearch = !searchTerm || 
                product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                (product.sku && product.sku.toLowerCase().includes(searchTerm.toLowerCase()));
            if (!matchesSearch) return false;
            if (filterStatus === 'all') return true;
            const count = product.variation_count || 0;
            const withImages = product.variations_with_images || 0;
            if (filterStatus === 'complete') {
                return count > 0 && withImages === count;
            } else if (filterStatus === 'partial') {
                return count > 0 && withImages > 0 && withImages < count;
            } else if (filterStatus === 'none') {
                return withImages === 0;
            }
            return true;
        });

        // Pagination
        const totalPages = Math.ceil(filteredProducts.length / itemsPerPage);
        const startIndex = (currentPage - 1) * itemsPerPage;
        const endIndex = startIndex + itemsPerPage;
        const paginatedProducts = filteredProducts.slice(startIndex, endIndex);

        // Build HTML
        let html = '<div class="wcvip-products-header">';
        html += '<div class="wcvip-stats-grid">';
         html += `<div class="wcvip-stat-card"><div class="wcvip-stat-value">${totalProducts}</div><div class="wcvip-stat-label">Total Products (with variations)</div></div>`;
        html += `<div class="wcvip-stat-card"><div class="wcvip-stat-value">${totalVariations}</div><div class="wcvip-stat-label">Total Variations</div></div>`;
        html += `<div class="wcvip-stat-card"><div class="wcvip-stat-value">${totalVariationsWithImages}</div><div class="wcvip-stat-label">With Images</div></div>`;
        html += `<div class="wcvip-stat-card"><div class="wcvip-stat-value">${productsComplete}</div><div class="wcvip-stat-label">Complete</div></div>`;
        html += '</div>';
        html += '<div class="wcvip-filters">';
        html += '<div class="wcvip-search-box"><input type="text" placeholder="Search products by name or SKU..." class="wcvip-search-input" id="wcvip-search-input" value="' + (searchTerm || '') + '"></div>';
        html += '<div class="wcvip-sort-controls"><select class="wcvip-sort-select" id="wcvip-sort-select">';
        html += `<option value="name" ${sortBy === 'name' ? 'selected' : ''}>Sort by Name</option>`;
        html += `<option value="variations" ${sortBy === 'variations' ? 'selected' : ''}>Sort by Variations</option>`;
        html += `<option value="images" ${sortBy === 'images' ? 'selected' : ''}>Sort by Images</option>`;
        html += '</select><button class="wcvip-sort-order-btn" id="wcvip-sort-order">' + (sortOrder === 'asc' ? '↑' : '↓') + '</button></div>';
        html += '<div class="wcvip-filter-buttons">';
        html += `<button class="wcvip-filter-btn ${filterStatus === 'all' ? 'active' : ''}" data-filter="all">All</button>`;
        html += `<button class="wcvip-filter-btn ${filterStatus === 'complete' ? 'active' : ''}" data-filter="complete">Complete</button>`;
        html += `<button class="wcvip-filter-btn ${filterStatus === 'partial' ? 'active' : ''}" data-filter="partial">Partial</button>`;
        html += `<button class="wcvip-filter-btn ${filterStatus === 'none' ? 'active' : ''}" data-filter="none">No Images</button>`;
        html += '</div></div>';

        html += renderTableView(paginatedProducts, filteredProducts.length, itemsPerPage);

        if (filteredProducts.length > itemsPerPage) {
            html += '<div class="wcvip-pagination">';
            html += `<button class="wcvip-btn wcvip-btn-secondary" ${currentPage === 1 ? 'disabled' : ''} id="wcvip-prev-page">← Previous</button>`;
            html += `<div class="wcvip-pagination-info">Page ${currentPage} of ${totalPages} <span class="wcvip-pagination-count">(${filteredProducts.length} products)</span></div>`;
            html += `<button class="wcvip-btn wcvip-btn-secondary" ${currentPage === totalPages ? 'disabled' : ''} id="wcvip-next-page">Next →</button>`;
            html += '</div>';
        }

        container.html(html);
        setupNewEventListeners();
    }

     function renderTableView(products, totalCount, perPage) {
         let html = '<div class="wcvip-products-table-wrapper"><table class="wcvip-products-table"><thead><tr>';
         html += '<th class="wcvip-col-image">Image</th>';
        html += `<th class="wcvip-col-name sortable" data-sort="name">Product Name ${sortBy === 'name' ? (sortOrder === 'asc' ? '↑' : '↓') : ''}</th>`;
        html += `<th class="wcvip-col-variations sortable" data-sort="variations">Variations ${sortBy === 'variations' ? (sortOrder === 'asc' ? '↑' : '↓') : ''}</th>`;
        html += `<th class="wcvip-col-status sortable" data-sort="images">Images Status ${sortBy === 'images' ? (sortOrder === 'asc' ? '↑' : '↓') : ''}</th>`;
        html += '<th class="wcvip-col-actions">Actions</th></tr></thead><tbody>';

         if (products.length === 0) {
             html += '<tr><td colspan="5" class="wcvip-empty-results"><p>No products found matching your search criteria.</p></td></tr>';
         } else {
             products.forEach(product => {
                 const variationsWithImages = product.variations_with_images || 0;
                 const variationCount = product.variation_count || 0;
                 let statusClass = 'none';
                 let statusText = 'No Images';
                 if (variationCount > 0) {
                     if (variationsWithImages === variationCount) {
                         statusClass = 'complete';
                         statusText = 'Complete';
                     } else if (variationsWithImages > 0) {
                         statusClass = 'partial';
                         statusText = 'Partial';
                     }
                 }
                 html += `<tr class="wcvip-product-row" data-product-id="${product.id}">`;
                 html += '<td class="wcvip-col-image"><div class="wcvip-product-image">';
                html += product.image ? `<img src="${product.image}" alt="${product.name}">` : '<div class="wcvip-no-image">📦</div>';
                html += '</div></td>';
                html += `<td class="wcvip-col-name"><div class="wcvip-product-name-cell">${product.name}</div></td>`;
                html += `<td class="wcvip-col-variations">${variationCount}</td>`;
                html += '<td class="wcvip-col-status"><div class="wcvip-status-cell">';
                html += `<span class="wcvip-product-status-badge ${statusClass}">${statusText}</span>`;
                html += `<span class="wcvip-status-count">${variationsWithImages} / ${variationCount}</span>`;
                html += '</div></td>';
                html += '<td class="wcvip-col-actions"><div class="wcvip-table-actions">';
                html += `<button class="wcvip-btn wcvip-btn-secondary wcvip-expand-row wcvip-expand-btn wcvip-btn-sm" data-product-id="${product.id}" title="Expand to manage variations">${expandedProductId === product.id ? '▼' : '▶'}</button>`;
                html += `<button class="wcvip-btn wcvip-btn-secondary wcvip-reset-product wcvip-btn-sm" data-product-id="${product.id}" title="Reset to original state">↻</button>`;
                html += `<a href="${product.permalink}" target="_blank" class="wcvip-btn wcvip-btn-secondary wcvip-view-product-btn wcvip-btn-sm" title="View Product">👁</a>`;
                html += '</div></td></tr>';
                // Add expandable row section
                if (expandedProductId === product.id) {
                    html += `<tr class="wcvip-expanded-row" data-product-id="${product.id}"><td colspan="5" class="wcvip-expanded-content"><div class="wcvip-variations-expanded-container" id="wcvip-variations-${product.id}"></div></td></tr>`;
            }
        });
    }
        html += '</tbody></table></div>';
        return html;
    }

    function setupNewEventListeners() {
        $('#wcvip-search-input').on('input', function() {
            const input = $(this);
            const inputValue = input.val();
            const cursorPos = input[0].selectionStart || inputValue.length;
            searchTerm = inputValue;
            currentPage = 1;
            
            // Clear previous timeout
            if (searchTimeout) {
                clearTimeout(searchTimeout);
            }
            
            // Debounce search - wait 300ms after user stops typing
            searchTimeout = setTimeout(function() {
                // Filter client-side without AJAX call
                if (allProducts.length > 0) {
                    renderProducts(allProducts);
                    // Restore focus and cursor position after re-render
                    setTimeout(function() {
                        const newInput = $('#wcvip-search-input');
                        if (newInput.length) {
                            newInput.focus();
                            // Restore cursor position
                            if (newInput[0].setSelectionRange) {
                                newInput[0].setSelectionRange(cursorPos, cursorPos);
                            } else if (newInput[0].createTextRange) {
                                const range = newInput[0].createTextRange();
                                range.collapse(true);
                                range.moveEnd('character', cursorPos);
                                range.moveStart('character', cursorPos);
                                range.select();
                            }
                        }
                    }, 0);
                }
            }, 300);
        });

        $('#wcvip-sort-select').on('change', function() {
            sortBy = $(this).val();
            currentPage = 1;
            // Filter client-side without AJAX call
            if (allProducts.length > 0) {
                renderProducts(allProducts);
            }
        });

        $('#wcvip-sort-order').on('click', function() {
            sortOrder = sortOrder === 'asc' ? 'desc' : 'asc';
            $(this).text(sortOrder === 'asc' ? '↑' : '↓');
            currentPage = 1;
            // Filter client-side without AJAX call
            if (allProducts.length > 0) {
                renderProducts(allProducts);
            }
        });

        $('.wcvip-filter-btn').on('click', function() {
            if ($(this).hasClass('wcvip-clear-filters')) {
                searchTerm = '';
                filterStatus = 'all';
                $('#wcvip-search-input').val('');
                currentPage = 1;
                if (allProducts.length > 0) {
                    renderProducts(allProducts);
                }
                    return;
                }
            filterStatus = $(this).data('filter');
            currentPage = 1;
            // Filter client-side without AJAX call
            if (allProducts.length > 0) {
                renderProducts(allProducts);
            }
        });

        $('#wcvip-prev-page').on('click', function() {
            if (currentPage > 1) {
                currentPage--;
                // Filter client-side without AJAX call
                if (allProducts.length > 0) {
                    renderProducts(allProducts);
                }
            }
        });

        $('#wcvip-next-page').on('click', function() {
            currentPage++;
            // Filter client-side without AJAX call
            if (allProducts.length > 0) {
                renderProducts(allProducts);
            }
        });

        $('.sortable').on('click', function() {
            const newSort = $(this).data('sort');
            if (sortBy === newSort) {
                sortOrder = sortOrder === 'asc' ? 'desc' : 'asc';
            } else {
                sortBy = newSort;
                sortOrder = 'asc';
            }
            currentPage = 1;
            // Filter client-side without AJAX call
            if (allProducts.length > 0) {
                renderProducts(allProducts);
            }
        });
    }

    /**
     * Load Visual Designer for expanded product
     */
    function loadVariationsForProduct(productId) {
        const container = $(`#wcvip-variations-${productId}`);
        if (!container.length) return;
        
        container.html('<div class="wcvip-loading"><p>Loading Visual Designer...</p></div>');

        // Load the Visual Designer HTML via AJAX
        $.ajax({
            url: wcvipData.ajaxurl,
            type: 'POST',
            data: {
                action: 'wcvip_get_designer_html',
                nonce: wcvipData.nonce,
                product_id: productId
            },
            success: function (response) {
                if (response.success && response.data.html) {
                    container.html(response.data.html);
                    // Trigger designer initialization after a short delay to ensure DOM is ready
                    setTimeout(function() {
                        // Re-initialize designer script for dynamically loaded content
                        if (typeof window.wcvipDesignerInit === 'function') {
                            window.wcvipDesignerInit();
                        } else if (typeof jQuery !== 'undefined') {
                            // Fallback: trigger custom event
                            jQuery(document).trigger('wcvip-designer-loaded');
                        }
                    }, 100);
                } else {
                    container.html('<div class="wcvip-error">Error loading Visual Designer.</div>');
                }
            },
            error: function () {
                container.html('<div class="wcvip-error">Error loading Visual Designer.</div>');
            }
        });
    }

    /**
     * Show toast notification
     */
    function showToast(message, type) {
        type = type || 'info';
        
        const icons = {
            success: '✓',
            error: '✕',
            warning: '⚠',
            info: 'ℹ'
        };
        
        const notification = $('<div>')
            .addClass('wcvip-notification wcvip-notice-' + type)
            .html(`
                <div class="wcvip-notification-content">
                    <span class="wcvip-notification-icon">${icons[type] || icons.info}</span>
                    <span class="wcvip-notification-message">${message}</span>
                </div>
                <button type="button" class="wcvip-notification-close" aria-label="Dismiss">×</button>
            `);
        
        let container = $('#wcvip-notification-container');
        if (container.length === 0) {
            container = $('<div id="wcvip-notification-container" class="wcvip-notification-container"></div>');
            $('body').append(container);
        }
        
        container.append(notification);
        
        // Auto-dismiss after 8 seconds
        const autoDismiss = setTimeout(function() {
            dismissNotification(notification);
        }, 8000);
        
        // Manual dismiss
        notification.find('.wcvip-notification-close').on('click', function() {
            clearTimeout(autoDismiss);
            dismissNotification(notification);
        });
    }

    /**
     * Dismiss notification
     */
    function dismissNotification(notification) {
        notification.addClass('hiding');
        setTimeout(function() {
            notification.remove();
        }, 300);
    }

    /**
     * Show confirmation modal
     */
    function showConfirmModal(title, message, onConfirm, onCancel) {
        const overlay = $('<div class="wcvip-modal-overlay"></div>');
        const modal = $('<div class="wcvip-modal"></div>');
        
        modal.html(`
            <div class="wcvip-modal-header">
                <h2>${title}</h2>
            </div>
            <div class="wcvip-modal-body">
                <p>${message}</p>
            </div>
            <div class="wcvip-modal-footer">
                <button type="button" class="wcvip-btn wcvip-btn-secondary wcvip-modal-cancel">Cancel</button>
                <button type="button" class="wcvip-btn wcvip-btn-primary wcvip-modal-confirm">Confirm</button>
            </div>
        `);
        
        overlay.append(modal);
        $('body').append(overlay);
        
        // Handle confirm
        modal.find('.wcvip-modal-confirm').on('click', function() {
            overlay.remove();
            if (typeof onConfirm === 'function') {
                onConfirm();
            }
        });
        
        // Handle cancel
        modal.find('.wcvip-modal-cancel').on('click', function() {
            overlay.remove();
            if (typeof onCancel === 'function') {
                onCancel();
            }
        });
        
        // Close on overlay click
        overlay.on('click', function(e) {
            if ($(e.target).hasClass('wcvip-modal-overlay')) {
                overlay.remove();
                if (typeof onCancel === 'function') {
                    onCancel();
                }
            }
        });
    }

    /**
     * Reset product to original state
     */
    function resetProduct(productId) {
        showConfirmModal(
            'Reset Product',
            'Are you sure you want to reset this product to its original state? This will remove all custom variation images and reset display settings.',
            function() {
                // User confirmed
                const $btn = $(`.wcvip-reset-product[data-product-id="${productId}"]`);
                const originalText = $btn.html();
                $btn.prop('disabled', true).html('⏳');

                $.ajax({
                    url: wcvipData.ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'wcvip_reset_product',
                        nonce: wcvipData.nonce,
                        product_id: productId
                    },
                    success: function (response) {
                        if (response.success) {
                            // Collapse expanded row if this product was expanded
                            if (expandedProductId === productId) {
                                expandedProductId = null;
                            }
                            // Reload products to show updated state
                            loadProducts();
                            // Show success message after a short delay to allow DOM to settle
                            setTimeout(function() {
                                showToast('Product reset successfully!', 'success');
                            }, 500);
                        } else {
                            showToast('Error resetting product: ' + (response.data?.message || 'Unknown error'), 'error');
                            $btn.prop('disabled', false).html(originalText);
                        }
                    },
                    error: function () {
                        showToast('Error resetting product. Please try again.', 'error');
                        $btn.prop('disabled', false).html(originalText);
                    }
                });
            }
        );
    }

    /**
     * Setup main event listeners
     */
    function setupEventListeners() {
        // Expand/collapse row - handle row click
        $(document).on('click', '.wcvip-product-row', function(e) {
            // Don't expand if clicking on action buttons or links
            if ($(e.target).closest('.wcvip-table-actions').length > 0) {
                return;
            }
            
            const productId = parseInt($(this).data('product-id'));
            
            // If clicking the same product, collapse it
            if (expandedProductId === productId) {
                expandedProductId = null;
            } else {
                expandedProductId = productId;
            }
            
            // Re-render products to show/hide expanded section
            if (allProducts.length > 0) {
                renderProducts(allProducts);
                // Load variations if expanded
                if (expandedProductId === productId) {
                    loadVariationsForProduct(productId);
                }
            }
        });

        // Expand/collapse row - handle button click (keep existing functionality)
        $(document).on('click', '.wcvip-expand-row', function(e) {
            e.preventDefault();
            e.stopPropagation(); // Prevent row click from firing
            const productId = parseInt($(this).data('product-id'));
            
            // If clicking the same product, collapse it
            if (expandedProductId === productId) {
                expandedProductId = null;
            } else {
                expandedProductId = productId;
            }
            
            // Re-render products to show/hide expanded section
            if (allProducts.length > 0) {
                renderProducts(allProducts);
                // Load variations if expanded
                if (expandedProductId === productId) {
                    loadVariationsForProduct(productId);
                }
            }
        });

        // Reset product - stop propagation to prevent row click
        $(document).on('click', '.wcvip-reset-product', function(e) {
            e.preventDefault();
            e.stopPropagation(); // Prevent row click from firing
            const productId = parseInt($(this).data('product-id'));
            resetProduct(productId);
        });

        // View product link - stop propagation to prevent row click
        $(document).on('click', '.wcvip-view-product-btn', function(e) {
            e.stopPropagation(); // Prevent row click from firing
            // Allow default link behavior
        });
    }
});