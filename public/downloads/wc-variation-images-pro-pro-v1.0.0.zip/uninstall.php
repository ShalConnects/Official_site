<?php
/**
 * Fired when the plugin is uninstalled
 *
 * @package WCVIP
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Uninstall the plugin
 * 
 * Note: WordPress uninstall hook doesn't support user interaction/prompts.
 * For Envato compliance, we retain all data by default to be safe.
 * Data will only be deleted if user explicitly enabled deletion in settings.
 */
function wcvip_uninstall_plugin() {
	// Envato Requirement: Offer option to retain data
	// Since WordPress uninstall hook doesn't support prompts, we retain data by default
	// This is the safest approach and complies with Envato's requirement
	
	// Check if user explicitly enabled data deletion in settings
	$delete_data = get_option( 'wcvip_delete_data_on_uninstall', false );
	
	// If user hasn't explicitly enabled deletion, retain all data (safer, Envato-compliant)
	if ( ! $delete_data ) {
		// Clear only temporary data (transients, cron)
		global $wpdb;
		
		// Clear scheduled cron events
		$timestamp = wp_next_scheduled( 'wcvip_clean_security_logs' );
		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, 'wcvip_clean_security_logs' );
		}
		
	// Clear transients only (temporary data)
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Uninstall cleanup operation
	$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_wcvip_%'" );
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Uninstall cleanup operation
	$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_wcvip_%'" );
		
		return; // Retain all other data (options, post meta, tables)
	}
	
	// Only delete if user explicitly enabled deletion
	
	// Delete all plugin options
	$options = array(
		'wcvip_display_style',
		'wcvip_lazy_load',
		'wcvip_show_badge',
		'wcvip_image_limit',
		'wcvip_use_attribute_sections',
		'wcvip_out_of_stock_action',
		'wcvip_attribute_styles',
		'wcvip_display_in_dropdown',
		'wcvip_display_thumbnails',
		'wcvip_testing_enable_pro_styles',
		'wcvip_security_logging_enabled',
		'wcvip_security_logging_database',
		'wcvip_security_log_retention_days',
		'wcvip_display_style_migrated',
		'wcvip_delete_data_on_uninstall',
	);
	
	foreach ( $options as $option ) {
		delete_option( $option );
	}
	
	// Delete all post meta for variation images
	global $wpdb;
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Uninstall cleanup operation
	$wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE '_wcvip_%'" );
	
	// Delete security logs table
	$table_name = $wpdb->prefix . 'wcvip_security_logs';
	$escaped_table_name = esc_sql( $table_name );
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.SchemaChange,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Uninstall cleanup operation, table deletion required, table name escaped
	$wpdb->query( "DROP TABLE IF EXISTS `{$escaped_table_name}`" );
	
	// Clear scheduled cron events
	$timestamp = wp_next_scheduled( 'wcvip_clean_security_logs' );
	if ( $timestamp ) {
		wp_unschedule_event( $timestamp, 'wcvip_clean_security_logs' );
	}
	
	// Clear all transients
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Uninstall cleanup operation
	$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_wcvip_%'" );
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Uninstall cleanup operation
	$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_wcvip_%'" );
}

// Run uninstall
wcvip_uninstall_plugin();

