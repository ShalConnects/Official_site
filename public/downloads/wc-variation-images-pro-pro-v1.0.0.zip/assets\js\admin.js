jQuery(document).ready(function ($) {

    // Variables
    let currentView = 'products';
    let selectedProduct = null;
    let currentVariation = null;
    let uploadedImages = [];

    // Initialize
    init();

    function init() {
        loadProducts();
        setupEventListeners();
    }

    /**
     * Load products list
     */
    function loadProducts() {
        const container = $('#wcvip-products-container');
        container.html('<p>Loading products...</p>');

        $.ajax({
            url: wcvipData.ajaxurl,
            type: 'POST',
            data: {
                action: 'wcvip_get_products',
                nonce: wcvipData.nonce
            },
            success: function (response) {
                if (response.success) {
                    renderProducts(response.data);
                } else {
                    container.html('<p>Error loading products.</p>');
                }
            },
            error: function () {
                container.html('<p>Error loading products.</p>');
            }
        });
    }

    /**
     * Render products list
     */
    function renderProducts(products) {
        const container = $('#wcvip-products-container');

        if (products.length === 0) {
            container.html('<p>No variable products found. Create some variable products in WooCommerce to get started.</p>');
            return;
        }

        let html = '';

        products.forEach(product => {
            html += `
                <div class="wcvip-product-card" data-product-id="${product.id}">
                    <div class="wcvip-product-image">
                        ${product.image ? `<img src="${product.image}" alt="${product.name}">` : '<div class="wcvip-no-image">??</div>'}
                    </div>
                    <div class="wcvip-product-info">
                        <h3>${product.name}</h3>
                        <div class="wcvip-product-meta">
                            ${product.sku ? `<span>SKU: ${product.sku}</span>` : ''}
                            <span>${product.variation_count} variations</span>
                        </div>
                    </div>
                    <div class="wcvip-product-actions">
                        <button class="wcvip-btn wcvip-btn-primary wcvip-manage-variations" data-product-id="${product.id}">
                            Manage Variations
                        </button>
                        <a href="?page=wcvip-dashboard&product_id=${product.id}&view=designer" class="wcvip-btn wcvip-btn-secondary wcvip-visual-designer-btn" data-product-id="${product.id}">
                            🎨 Visual Designer
                        </a>
                        <a href="${product.permalink}" target="_blank" class="wcvip-btn wcvip-btn-secondary">
                            View Product
                        </a>
                    </div>
                </div>
            `;
        });

        container.html(html);
    }

    /**
     * Load variations for a product
     */
    function loadVariations(productId) {
        const container = $('#wcvip-products-container');
        container.html('<p>Loading variations...</p>');

        $.ajax({
            url: wcvipData.ajaxurl,
            type: 'POST',
            data: {
                action: 'wcvip_get_variations',
                nonce: wcvipData.nonce,
                product_id: productId
            },
            success: function (response) {
                if (response.success) {
                    renderVariations(response.data, productId);
                } else {
                    container.html('<p>Error loading variations.</p>');
                }
            },
            error: function () {
                container.html('<p>Error loading variations.</p>');
            }
        });
    }

    /**
     * Render variations list
     */
    function renderVariations(variations, productId) {
        const container = $('#wcvip-products-container');

        let html = `
            <div class="wcvip-breadcrumb">
                <button class="wcvip-back-btn" id="wcvip-back-to-products">? Back to Products</button>
            </div>
            <div class="wcvip-variations-header">
                <h2>Manage Variation Images</h2>
                <p>${variations.length} variations found</p>
            </div>
            <div class="wcvip-variations-grid">
        `;

        variations.forEach(variation => {
            const imageCount = variation.custom_images ? variation.custom_images.length : 0;

            html += `
                <div class="wcvip-variation-card">
                    <div class="wcvip-variation-preview">
                        ${variation.image ? `<img src="${variation.image}" alt="${variation.attributes_display}">` : '<div class="wcvip-no-image">???</div>'}
                    </div>
                    <div class="wcvip-variation-info">
                        <h4>${variation.attributes_display}</h4>
                        <div class="wcvip-variation-meta">
                            ${variation.sku ? `<span>SKU: ${variation.sku}</span>` : ''}
                        </div>
                        <div class="wcvip-media-count">
                            <span class="${imageCount > 0 ? 'has-images' : ''}">
                                ??? ${imageCount} ${imageCount === 1 ? 'image' : 'images'}
                            </span>
                        </div>
                        <button class="wcvip-btn wcvip-btn-primary wcvip-btn-block wcvip-manage-images" data-variation-id="${variation.id}" data-variation-name="${variation.attributes_display}">
                            Manage Images
                        </button>
                    </div>
                </div>
            `;
        });

        html += '</div>';
        container.html(html);

        selectedProduct = productId;
        currentView = 'variations';
    }

    /**
     * Open image management modal
     */
    function openImageModal(variationId, variationName) {
        currentVariation = variationId;

        // Get existing images
        const variationCard = $(`.wcvip-manage-images[data-variation-id="${variationId}"]`).closest('.wcvip-variation-card');
        const existingImages = []; // We'll load this via AJAX in a real implementation

        uploadedImages = existingImages;

        const modalHTML = `
            <div class="wcvip-modal-overlay" id="wcvip-image-modal">
                <div class="wcvip-modal">
                    <div class="wcvip-modal-header">
                        <h2>Manage Images: ${variationName}</h2>
                        <span class="wcvip-close">&times;</span>
                    </div>
                    <div class="wcvip-modal-body">
                        <div class="wcvip-image-uploader" id="wcvip-upload-area">
                            <p><strong>?? Click to Upload Images</strong></p>
                            <p>or drag and drop images here</p>
                            <p style="font-size: 12px; color: #666;">Free version: 1 image per variation</p>
                        </div>
                        
                        <div id="wcvip-gallery-container">
                            <h3>Current Images</h3>
                            <div class="wcvip-gallery-grid" id="wcvip-gallery">
                                ${renderImageGallery()}
                            </div>
                        </div>
                    </div>
                    <div class="wcvip-modal-footer">
                        <button class="wcvip-btn wcvip-btn-secondary" id="wcvip-modal-cancel">Cancel</button>
                        <button class="wcvip-btn wcvip-btn-primary" id="wcvip-modal-save">Save Changes</button>
                    </div>
                </div>
            </div>
        `;

        $('body').append(modalHTML);
        setupModalListeners();
    }

    /**
     * Render image gallery
     */
    function renderImageGallery() {
        if (uploadedImages.length === 0) {
            return '<p style="grid-column: 1/-1; text-align: center; color: #666;">No images uploaded yet.</p>';
        } let html = '';
        uploadedImages.forEach((image, index) => {
            html += `
            <div class="wcvip-gallery-item" data-index="${index}">
                <img src="${image.url}" alt="">
                <div class="wcvip-gallery-overlay">
                    <button class="wcvip-icon-btn wcvip-set-primary" data-index="${index}" title="Set as primary">
                        ${image.is_primary ? '?' : '?'}
                    </button>
                    <button class="wcvip-icon-btn wcvip-icon-btn-danger wcvip-remove-image" data-index="${index}" title="Remove">
                        ?
                    </button>
                </div>
                ${image.is_primary ? '<span class="wcvip-primary-badge">Primary</span>' : ''}
            </div>
        `;
        }); return html;
    }

    /**
* Setup modal event listeners
*/
    function setupModalListeners() {
        // Close modal
        $('.wcvip-close, #wcvip-modal-cancel').on('click', function () {
            closeModal();
        }); // Close on overlay click
        $('.wcvip-modal-overlay').on('click', function (e) {
            if (e.target === this) {
                closeModal();
            }
        }); // Upload images
        $('#wcvip-upload-area').on('click', function () {
            openMediaUploader();
        }); // Save images
        $('#wcvip-modal-save').on('click', function () {
            saveImages();
        });  // Remove image
        $(document).on('click', '.wcvip-remove-image', function () {
            const index = $(this).data('index');
            removeImage(index);
        }); // Set primary image
        $(document).on('click', '.wcvip-set-primary', function () {
            const index = $(this).data('index');
            setPrimaryImage(index);
        }); // Make gallery sortable
        $('#wcvip-gallery').sortable({
            update: function (event, ui) {
                updateImageOrder();
            }
        });
    }

    /**
     * Open WordPress media uploader
     */
    function openMediaUploader() {
        // Check limit for free version
        if (!wcvipData.isPro && uploadedImages.length >= 1) {
            alert('Free version is limited to 1 image per variation. Upgrade to Pro for unlimited images!');
            return;
        }

        // Create media uploader
        const mediaUploader = wp.media({
            title: 'Select Images',
            button: {
                text: 'Add to Variation'
            },
            multiple: !wcvipData.isPro // Only allow multiple in Pro
        });

        // When images are selected
        mediaUploader.on('select', function () {
            const selection = mediaUploader.state().get('selection');

            selection.forEach(function (attachment) {
                attachment = attachment.toJSON();

                // Check limit again
                if (!wcvipData.isPro && uploadedImages.length >= 1) {
                    alert('Free version is limited to 1 image per variation.');
                    return;
                }

                // Add image
                uploadedImages.push({
                    id: attachment.id,
                    url: attachment.url,
                    thumbnail: attachment.sizes.thumbnail ? attachment.sizes.thumbnail.url : attachment.url,
                    alt: attachment.alt || '',
                    is_primary: uploadedImages.length === 0 // First image is primary
                });
            });

            // Re-render gallery
            $('#wcvip-gallery').html(renderImageGallery());
        });

        // Open uploader
        mediaUploader.open();
    }

    /**
     * Remove image from gallery
     */
    function removeImage(index) {
        if (confirm('Remove this image?')) {
            uploadedImages.splice(index, 1);

            // If removed image was primary, make first image primary
            if (uploadedImages.length > 0) {
                const hasPrimary = uploadedImages.some(img => img.is_primary);
                if (!hasPrimary) {
                    uploadedImages[0].is_primary = true;
                }
            }

            // Re-render gallery
            $('#wcvip-gallery').html(renderImageGallery());
        }
    }

    /**
     * Set primary image
     */
    function setPrimaryImage(index) {
        // Remove primary from all images
        uploadedImages.forEach(img => {
            img.is_primary = false;
        });

        // Set new primary
        uploadedImages[index].is_primary = true;

        // Re-render gallery
        $('#wcvip-gallery').html(renderImageGallery());
    }

    /**
     * Update image order after drag and drop
     */
    function updateImageOrder() {
        const newOrder = [];
        $('#wcvip-gallery .wcvip-gallery-item').each(function () {
            const index = $(this).data('index');
            newOrder.push(uploadedImages[index]);
        });
        uploadedImages = newOrder;
    }

    /**
     * Save images
     */
    function saveImages() {
        const $saveBtn = $('#wcvip-modal-save');
        $saveBtn.prop('disabled', true).text('Saving...');

        $.ajax({
            url: wcvipData.ajaxurl,
            type: 'POST',
            data: {
                action: 'wcvip_save_images',
                nonce: wcvipData.nonce,
                variation_id: currentVariation,
                images: JSON.stringify(uploadedImages)
            },
            success: function (response) {
                if (response.success) {
                    alert('Images saved successfully!');
                    closeModal();
                    // Reload variations to show updated count
                    loadVariations(selectedProduct);
                } else {
                    alert('Error saving images: ' + response.data);
                    $saveBtn.prop('disabled', false).text('Save Changes');
                }
            },
            error: function () {
                alert('Error saving images. Please try again.');
                $saveBtn.prop('disabled', false).text('Save Changes');
            }
        });
    }

    /**
     * Close modal
     */
    function closeModal() {
        $('#wcvip-image-modal').remove();
        uploadedImages = [];
        currentVariation = null;
    }

    /**
     * Setup main event listeners
     */
    function setupEventListeners() {
        // Manage variations button
        $(document).on('click', '.wcvip-manage-variations', function () {
            const productId = $(this).data('product-id');
            loadVariations(productId);
        });

        // Back to products button
        $(document).on('click', '#wcvip-back-to-products', function () {
            loadProducts();
            currentView = 'products';
            selectedProduct = null;
        });

        // Manage images button
        $(document).on('click', '.wcvip-manage-images', function () {
            const variationId = $(this).data('variation-id');
            const variationName = $(this).data('variation-name');
            openImageModal(variationId, variationName);
        });
    }
});