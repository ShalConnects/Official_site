<?php
/**
 * Visual designer for variation images
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Visual designer class
 */
class WCVIP_Visual_Designer {

	/**
	 * Initialize visual designer
	 */
	public function __construct() {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_designer_assets' ) );
		add_action( 'wp_ajax_wcvip_get_product_variations_designer', array( $this, 'ajax_get_variations_for_designer' ) );
		add_action( 'wp_ajax_wcvip_save_designer_layout', array( $this, 'ajax_save_designer_layout' ) );
		add_action( 'wp_ajax_wcvip_preview_variation', array( $this, 'ajax_preview_variation' ) );
		add_action( 'wp_ajax_wcvip_refresh_selector_preview', array( $this, 'ajax_refresh_selector_preview' ) );
	}

	/**
	 * Enqueue designer assets
	 */
	public function enqueue_designer_assets( $hook ) {
		if ( strpos( $hook, 'wcvip' ) === false ) {
			return;
		}

		wp_enqueue_style(
			'wcvip-designer',
			WCVIP_PLUGIN_URL . 'admin/css/wcvip-designer.css',
			array(),
			WCVIP_VERSION
		);
		
		// Also load admin CSS for modal styles
		$admin_css = WCVIP_PLUGIN_DIR . 'admin/css/wcvip-admin.css';
		if ( file_exists( $admin_css ) ) {
			wp_enqueue_style(
				'wcvip-admin',
				WCVIP_PLUGIN_URL . 'admin/css/wcvip-admin.css',
				array(),
				WCVIP_VERSION
			);
		}

		wp_enqueue_media(); // Required for WordPress media uploader
		
		wp_enqueue_script(
			'wcvip-designer',
			WCVIP_PLUGIN_URL . 'admin/js/wcvip-designer.js',
			array( 'jquery', 'jquery-ui-sortable' ),
			WCVIP_VERSION,
			true
		);

		// Check if Pro features are enabled (Pro version only - testing option removed for free version)
		$is_pro_enabled = (bool) WCVIP_IS_PRO;
		
		// Get upgrade URL (can be filtered)
		$upgrade_url = apply_filters( 'wcvip_upgrade_url', 'https://store.shalconnects.com/variation-images-pro' );
		
		wp_localize_script(
			'wcvip-designer',
			'wcvipDesigner',
			array(
				'ajaxurl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'wcvip-designer-nonce' ),
				'nonce_images' => wp_create_nonce( 'wcvip-nonce' ), // For image save/get actions
				'isPro'   => $is_pro_enabled,
				'upgradeUrl' => $upgrade_url,
			)
		);
	}

	/**
	 * Render visual designer interface
	 */
	public function render_designer( $product_id ) {
		$product = wc_get_product( $product_id );
		if ( ! $product || ! $product->is_type( 'variable' ) ) {
			return;
		}

		// Get product information
		$product_title = $product->get_name();
		$variation_ids = $product->get_children();
		$variation_count = count( $variation_ids );
		$product_permalink = get_permalink( $product_id );

		?>
		<div class="wcvip-visual-designer" data-product-id="<?php echo esc_attr( $product_id ); ?>" data-product-permalink="<?php echo esc_url( $product_permalink ); ?>">
			<!-- Notification Container -->
			<div id="wcvip-notification-container" class="wcvip-notification-container"></div>
			
			<div class="wcvip-designer-header">
				<h2 class="wcvip-product-title">
					<?php echo esc_html( $product_title ); ?>
				</h2>
				<p class="wcvip-header-description">
					<?php 
					$text = sprintf(
						// translators: %s is the highlighted variation count
						__( 'Managing %s variation(s). Add images to variations, customize layout, and preview how it will look on the frontend.', 'wc-variation-images-pro' ),
						'<strong class="wcvip-variation-count">' . esc_html( $variation_count ) . '</strong>'
					);
					echo wp_kses_post( $text );
					?>
				</p>
			</div>

			<div class="wcvip-designer-layout">
				<!-- Left Panel: Variations List -->
				<div class="wcvip-designer-variations">
					<h3><?php esc_html_e( 'Variations', 'wc-variation-images-pro' ); ?></h3>
					<div class="wcvip-variations-list" id="wcvip-variations-list">
						<?php $this->render_variations_list( $product_id ); ?>
					</div>
				</div>

				<!-- Center Panel: Design Canvas -->
				<div class="wcvip-designer-canvas">
					<h3>
						<?php esc_html_e( 'Display Style Options', 'wc-variation-images-pro' ); ?>
						<?php
						$preview_url = get_permalink( $product_id );
						$current_style = get_option( 'wcvip_display_style', 'none' );
						// Check for product-specific style
						$product_style = get_post_meta( $product_id, '_wcvip_display_style', true );
						if ( ! empty( $product_style ) ) {
							$current_style = $product_style;
						}
						$preview_url = add_query_arg( array(
							'wcvip_preview' => 'true',
							'wcvip_style' => $current_style,
							'wcvip_nonce' => wp_create_nonce( 'wcvip-preview-' . $product_id ),
						), $preview_url );
						?>
						<a href="<?php echo esc_url( $preview_url ); ?>" target="_blank" class="button button-small wcvip-view-frontend-header" data-base-url="<?php echo esc_url( get_permalink( $product_id ) ); ?>" data-product-id="<?php echo esc_attr( $product_id ); ?>" data-current-style="<?php echo esc_attr( $current_style ); ?>" data-preview-nonce="<?php echo esc_attr( wp_create_nonce( 'wcvip-preview-' . $product_id ) ); ?>">
							<?php esc_html_e( 'Preview', 'wc-variation-images-pro' ); ?>
						</a>
					</h3>
					<div class="wcvip-canvas-area" id="wcvip-canvas-area">
						<?php $this->render_canvas( $product_id ); ?>
					</div>
				</div>
			</div>

			<!-- Live Preview Section -->
			<div class="wcvip-designer-preview" id="wcvip-designer-preview" style="display: none;">
				<h3><?php esc_html_e( 'Live Preview', 'wc-variation-images-pro' ); ?></h3>
				<div class="wcvip-preview-area" id="wcvip-preview-area">
					<?php $this->render_preview( $product_id ); ?>
				</div>
			</div>

			<!-- Actions -->
			<div class="wcvip-designer-actions">
				<button type="button" class="button button-secondary" id="wcvip-reset-designer">
					<?php esc_html_e( 'Reset', 'wc-variation-images-pro' ); ?>
				</button>
				<button type="button" class="button button-primary" id="wcvip-save-designer">
					<?php esc_html_e( 'Save', 'wc-variation-images-pro' ); ?>
				</button>
				<a href="<?php echo esc_url( $product_permalink ); ?>" target="_blank" rel="noopener noreferrer" class="button button-primary" id="wcvip-view-product" style="display: none;">
					<?php esc_html_e( 'View Product', 'wc-variation-images-pro' ); ?>
				</a>
			</div>
		</div>
		<?php
	}

	/**
	 * Render variations list
	 */
	private function render_variations_list( $product_id ) {
		$product = wc_get_product( $product_id );
		$variation_ids = $product->get_children();

		foreach ( $variation_ids as $variation_id ) {
			$variation = wc_get_product( $variation_id );
			if ( ! $variation ) {
				continue;
			}

			$custom_images = get_post_meta( $variation_id, '_wcvip_images', true );
			$image_count = is_array( $custom_images ) ? count( $custom_images ) : 0;
			
			// Get preview image - use custom images first, fallback to WooCommerce variation image
			$preview_image_url = '';
			if ( $image_count > 0 && ! empty( $custom_images[0]['thumbnail'] ) ) {
				$preview_image_url = $custom_images[0]['thumbnail'];
			} else {
				// Fallback to WooCommerce variation image
				$woo_image_id = $variation->get_image_id();
				if ( $woo_image_id ) {
					$preview_image_url = wp_get_attachment_image_url( $woo_image_id, 'thumbnail' );
				}
			}
			
			// Check if Pro features are enabled (Pro version only - testing option removed for free version)
			$pro_enabled = WCVIP_IS_PRO;

			?>
			<div class="wcvip-variation-item" data-variation-id="<?php echo esc_attr( $variation_id ); ?>">
				<div class="wcvip-variation-item-preview">
					<?php if ( ! empty( $preview_image_url ) ) : ?>
						<img src="<?php echo esc_url( $preview_image_url ); ?>" alt="">
					<?php else : ?>
						<div class="wcvip-no-image-preview"><?php esc_html_e( 'No image', 'wc-variation-images-pro' ); ?></div>
					<?php endif; ?>
				</div>
				<div class="wcvip-variation-item-content">
					<div class="wcvip-variation-item-header">
						<span class="wcvip-variation-name" title="<?php echo esc_attr( wc_get_formatted_variation( $variation, true ) ); ?>"><?php echo esc_html( wc_get_formatted_variation( $variation, true ) ); ?></span>
				</div>
				<div class="wcvip-variation-item-footer">
					<?php if ( $pro_enabled ) : ?>
							<span class="wcvip-variation-image-count"><?php echo esc_html( $image_count ); ?></span>
						<button type="button" class="button button-small wcvip-edit-variation-images" data-variation-id="<?php echo esc_attr( $variation_id ); ?>">
								<?php esc_html_e( 'Manage', 'wc-variation-images-pro' ); ?>
						</button>
					<?php else : ?>
						<button type="button" class="button button-small wcvip-upgrade-required" disabled>
							<?php esc_html_e( 'Upgrade', 'wc-variation-images-pro' ); ?>
						</button>
					<?php endif; ?>
					</div>
				</div>
			</div>
			<?php
		}
	}

	/**
	 * Render design canvas
	 */
	private function render_canvas( $product_id ) {
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce global $product is standard
		global $product;
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce global $product is standard
		$product = wc_get_product( $product_id );
		
		// Check if attribute sections format is enabled
		$use_attribute_sections = get_option( 'wcvip_use_attribute_sections', 'no' );
		
		// Get product attributes for per-attribute style configuration
		$product_attributes = array();
		if ( $product && $product->is_type( 'variable' ) ) {
			$variation_ids = $product->get_children();
			if ( ! empty( $variation_ids ) ) {
				$first_variation = wc_get_product( $variation_ids[0] );
				if ( $first_variation ) {
					$variation_attributes = $first_variation->get_variation_attributes();
					if ( ! empty( $variation_attributes ) && count( $variation_attributes ) > 1 ) {
						// Product has multiple attributes
						foreach ( $variation_attributes as $attr_key => $attr_value ) {
							$display_name = WCVIP_Attribute_Helper::get_attribute_display_name( $attr_key );
							$product_attributes[ $attr_key ] = $display_name;
						}
					}
				}
			}
		}
		
		// Get product-specific attribute styles
		$product_attribute_styles = get_post_meta( $product_id, '_wcvip_attribute_styles', true );
		if ( ! is_array( $product_attribute_styles ) ) {
			$product_attribute_styles = array();
		}
		
		// Check if Pro features are enabled for banner display (Pro version only - testing option removed for free version)
		$is_pro_enabled = (bool) WCVIP_IS_PRO;
		
		?>
		<div class="wcvip-canvas-dropzone">
			<?php if ( ! $is_pro_enabled ) : ?>
				<div class="wcvip-upgrade-banner" id="wcvip-upgrade-banner">
					<div class="wcvip-upgrade-banner-content">
						<div class="wcvip-upgrade-banner-icon">⭐</div>
						<div class="wcvip-upgrade-banner-text">
							<strong><?php esc_html_e( 'Unlock Pro Features', 'wc-variation-images-pro' ); ?></strong>
							<p><?php esc_html_e( 'Get access to advanced display styles, unlimited images per variation, and more customization options.', 'wc-variation-images-pro' ); ?></p>
						</div>
						<div class="wcvip-upgrade-banner-actions">
							<a href="<?php echo esc_url( apply_filters( 'wcvip_upgrade_url', 'https://store.shalconnects.com/variation-images-pro' ) ); ?>" target="_blank" class="button button-primary wcvip-upgrade-button">
								<?php esc_html_e( 'Upgrade to Pro', 'wc-variation-images-pro' ); ?>
							</a>
							<button type="button" class="wcvip-upgrade-banner-dismiss" aria-label="<?php esc_attr_e( 'Dismiss', 'wc-variation-images-pro' ); ?>">
								<span class="dashicons dashicons-no-alt"></span>
							</button>
						</div>
					</div>
				</div>
			<?php endif; ?>
			<div class="wcvip-canvas-options" id="wcvip-canvas-options">
				<div class="wcvip-style-options">
					<?php $this->render_all_style_options( $product_id ); ?>
				</div>
				
				<?php if ( 'yes' === $use_attribute_sections && ! empty( $product_attributes ) && count( $product_attributes ) > 1 ) : ?>
					<?php
					$default_style = get_option( 'wcvip_display_style', 'none' );
					// Check if Pro styles are available (class exists)
					$pro_available = class_exists( 'WCVIP_Pro_Styles' );
					$pro_enabled = $pro_available; // Keep for backward compatibility
					?>
					<div class="wcvip-attribute-styles-section" id="wcvip-attribute-styles-section">
						<h4>
							<?php esc_html_e( 'Per-Attribute Display Styles', 'wc-variation-images-pro' ); ?>
							<?php
							$preview_url = get_permalink( $product_id );
							$preview_url = add_query_arg( array(
								'wcvip_preview' => 'true',
								'wcvip_style' => $default_style,
								'wcvip_nonce' => wp_create_nonce( 'wcvip-preview-' . $product_id ),
							), $preview_url );
							?>
							<a href="<?php echo esc_url( $preview_url ); ?>" target="_blank" class="button button-small wcvip-attribute-preview-btn" data-base-url="<?php echo esc_url( get_permalink( $product_id ) ); ?>" data-product-id="<?php echo esc_attr( $product_id ); ?>" data-default-style="<?php echo esc_attr( $default_style ); ?>" data-preview-nonce="<?php echo esc_attr( wp_create_nonce( 'wcvip-preview-' . $product_id ) ); ?>">
								<?php esc_html_e( 'Preview', 'wc-variation-images-pro' ); ?>
							</a>
						</h4>
						<p class="description">
							<?php esc_html_e( 'Configure display style for each attribute. Leave empty to use the default display style. Styles are applied when "Separate Attribute Sections" format is enabled.', 'wc-variation-images-pro' ); ?>
						</p>
						<?php
						$available_styles = array(
							'horizontal_text' => __( 'Horizontal Text Boxes', 'wc-variation-images-pro' ),
							'vertical_text'   => __( 'Vertical Text List', 'wc-variation-images-pro' ),
							'color_swatches'  => __( 'Color Swatches', 'wc-variation-images-pro' ),
						);
						
						if ( $pro_enabled ) {
							$available_styles['square'] = __( 'Square Thumbnails', 'wc-variation-images-pro' );
							$available_styles['circular'] = __( 'Circular Thumbnails', 'wc-variation-images-pro' );
							$available_styles['buttons'] = __( 'Button Style (Image First)', 'wc-variation-images-pro' );
							$available_styles['buttons_text_first'] = __( 'Button Style (Text First)', 'wc-variation-images-pro' );
						}
						
						$default_style_label = isset( $available_styles[ $default_style ] ) ? $available_styles[ $default_style ] : ( 'none' === $default_style ? __( 'No option (default)', 'wc-variation-images-pro' ) : $default_style );
						?>
						<p class="description">
							<strong><?php esc_html_e( 'Default style:', 'wc-variation-images-pro' ); ?></strong>
							<?php echo esc_html( $default_style_label ); ?>
						</p>
						<div class="wcvip-attribute-styles-list">
							<?php foreach ( $product_attributes as $attr_key => $attr_name ) : ?>
								<?php
								$current_attr_style = ! empty( $product_attribute_styles[ $attr_key ] ) ? $product_attribute_styles[ $attr_key ] : '';
								?>
								<div class="wcvip-attribute-style-item" data-attribute-key="<?php echo esc_attr( $attr_key ); ?>">
									<label class="wcvip-attribute-style-label">
										<span class="wcvip-attribute-name"><?php echo esc_html( $attr_name ); ?>:</span>
										<select class="wcvip-attribute-style-select" name="attribute_styles[<?php echo esc_attr( $attr_key ); ?>]" data-attribute-key="<?php echo esc_attr( $attr_key ); ?>">
											<option value=""><?php esc_html_e( 'Use Default Style', 'wc-variation-images-pro' ); ?></option>
											<?php $this->render_attribute_style_options( $current_attr_style ); ?>
										</select>
									</label>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}
	
	/**
	 * Render style options for attribute style selector
	 */
	private function render_attribute_style_options( $selected_style = '' ) {
		// Check if Pro styles are available (class exists)
		$pro_available = class_exists( 'WCVIP_Pro_Styles' );
		$pro_enabled = $pro_available; // Keep for backward compatibility
		
		// Free styles
		$free_styles = array(
			'horizontal_text' => __( 'Horizontal Text Boxes', 'wc-variation-images-pro' ),
			'vertical_text'   => __( 'Vertical Text List', 'wc-variation-images-pro' ),
			'color_swatches'  => __( 'Color Swatches', 'wc-variation-images-pro' ),
		);
		
		// Pro styles: show as preview even in free version (non-functional)
		$pro_styles = array();
		if ( class_exists( 'WCVIP_Pro_Styles' ) ) {
			// Pro version - fully functional
			$pro_styles = WCVIP_Pro_Styles::get_pro_styles();
		} else {
			// Free version - show as preview only
			$pro_styles = array(
				'buttons' => __( 'Button Style (Image First)', 'wc-variation-images-pro' ),
				'buttons_text_first' => __( 'Button Style (Text First)', 'wc-variation-images-pro' ),
				'square' => __( 'Square Thumbnails', 'wc-variation-images-pro' ),
				'circular' => __( 'Circular Thumbnails', 'wc-variation-images-pro' ),
			);
		}
		
		if ( ! empty( $free_styles ) ) : ?>
			<optgroup label="<?php esc_attr_e( 'Free Styles', 'wc-variation-images-pro' ); ?>">
				<?php foreach ( $free_styles as $key => $label ) : ?>
					<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $selected_style, $key ); ?>>
						<?php echo esc_html( $label ); ?>
					</option>
				<?php endforeach; ?>
			</optgroup>
		<?php endif; ?>
		
		<?php if ( ! empty( $pro_styles ) ) : ?>
			<optgroup label="<?php esc_attr_e( 'Pro Styles', 'wc-variation-images-pro' ); ?>">
				<?php foreach ( $pro_styles as $key => $label ) : ?>
					<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $selected_style, $key ); ?>>
						<?php echo esc_html( $label ); ?>
					</option>
				<?php endforeach; ?>
			</optgroup>
		<?php endif;
	}

	/**
	 * Render style options for Pro users
	 */
	private function render_style_options() {
		$current_style = get_option( 'wcvip_display_style', 'none' );
		$styles = array(
			'circular'     => __( 'Circular Thumbnails', 'wc-variation-images-pro' ),
			'square'       => __( 'Square Thumbnails', 'wc-variation-images-pro' ),
			'rectangular'  => __( 'Rectangular with Labels', 'wc-variation-images-pro' ),
			'dropdown'     => __( 'Dropdown with Images', 'wc-variation-images-pro' ),
			'buttons'      => __( 'Button Style', 'wc-variation-images-pro' ),
			'grid'         => __( 'Grid Layout', 'wc-variation-images-pro' ),
			'strip'        => __( 'Horizontal Strip', 'wc-variation-images-pro' ),
			'radio'        => __( 'Radio Buttons', 'wc-variation-images-pro' ),
			'custom'       => __( 'Custom Hybrid', 'wc-variation-images-pro' ),
		);
		?>
		<div class="wcvip-style-grid">
			<?php foreach ( $styles as $key => $label ) : ?>
				<div class="wcvip-style-option wcvip-style-<?php echo esc_attr( $key ); ?> <?php echo $current_style === $key ? 'active' : ''; ?>" data-style="<?php echo esc_attr( $key ); ?>">
					<div class="wcvip-style-preview">
						<?php echo wp_kses_post( $this->get_style_preview_html( $key ) ); ?>
					</div>
					<span class="wcvip-style-label"><?php echo esc_html( $label ); ?></span>
					<?php if ( in_array( $key, array( 'circular', 'rectangular', 'grid', 'strip', 'radio', 'custom' ), true ) ) : ?>
						<span class="wcvip-pro-badge">⭐ Pro</span>
					<?php endif; ?>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Render free style options
	 */
	private function render_free_style_options() {
		$current_style = get_option( 'wcvip_display_style', 'none' );
		$free_styles = array(
			'horizontal_text' => __( 'Horizontal Text Boxes', 'wc-variation-images-pro' ),
			'vertical_text'   => __( 'Vertical Text List', 'wc-variation-images-pro' ),
			'color_swatches'  => __( 'Color Swatches', 'wc-variation-images-pro' ),
		);
		?>
		<div class="wcvip-style-grid">
			<?php foreach ( $free_styles as $key => $label ) : ?>
				<div class="wcvip-style-option wcvip-style-<?php echo esc_attr( $key ); ?> <?php echo $current_style === $key ? 'active' : ''; ?>" data-style="<?php echo esc_attr( $key ); ?>">
					<div class="wcvip-style-preview">
						<?php echo wp_kses_post( $this->get_style_preview_html( $key ) ); ?>
					</div>
					<span class="wcvip-style-label"><?php echo esc_html( $label ); ?></span>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Render all style options (free + paid) with Pro options greyed out
	 */
	private function render_all_style_options( $product_id = null ) {
		// Check for product-specific style first, then fall back to global
		$current_style = get_option( 'wcvip_display_style', 'none' );
		if ( $product_id ) {
			$product_style = get_post_meta( $product_id, '_wcvip_display_style', true );
			if ( ! empty( $product_style ) ) {
				$current_style = $product_style;
			}
		}
		// Check if Pro styles are available (class exists)
		$pro_available = class_exists( 'WCVIP_Pro_Styles' );
		$pro_enabled = $pro_available; // Keep for backward compatibility
		
		// Free options with descriptions
		$free_styles = array(
			'horizontal_text' => array(
				'label' => __( 'Horizontal Text Boxes', 'wc-variation-images-pro' ),
				'description' => __( 'Text-only buttons in a horizontal row', 'wc-variation-images-pro' ),
				'icon' => '↔',
				'best_for' => __( 'Simple attributes', 'wc-variation-images-pro' ),
			),
			'vertical_text' => array(
				'label' => __( 'Vertical Text List', 'wc-variation-images-pro' ),
				'description' => __( 'Text-only buttons in a vertical list', 'wc-variation-images-pro' ),
				'icon' => '↕',
				'best_for' => __( 'Simple attributes', 'wc-variation-images-pro' ),
			),
			'color_swatches' => array(
				'label' => __( 'Color Swatches', 'wc-variation-images-pro' ),
				'description' => __( 'Circular color dots for color attributes (falls back to Horizontal if no color attribute)', 'wc-variation-images-pro' ),
				'icon' => '●',
				'best_for' => __( 'Color attributes', 'wc-variation-images-pro' ),
			),
		);
		
		// Paid options with descriptions - show as preview in free version
		$paid_styles = array();
		$pro_available = class_exists( 'WCVIP_Pro_Styles' );
		
		$paid_styles = array(
			'buttons' => array(
				'label' => __( 'Button Style (Image First)', 'wc-variation-images-pro' ),
				'description' => __( 'Vertical boxes with image thumbnails and labels', 'wc-variation-images-pro' ),
				'icon' => '📦',
				'best_for' => __( 'All attributes', 'wc-variation-images-pro' ),
			),
			'buttons_text_first' => array(
				'label' => __( 'Button Style (Text First)', 'wc-variation-images-pro' ),
				'description' => __( 'Vertical boxes with labels and image thumbnails', 'wc-variation-images-pro' ),
				'icon' => '📦',
				'best_for' => __( 'All attributes', 'wc-variation-images-pro' ),
			),
			'square' => array(
				'label' => __( 'Square Thumbnails', 'wc-variation-images-pro' ),
				'description' => __( 'Square image boxes in a horizontal row', 'wc-variation-images-pro' ),
				'icon' => '⬜',
				'best_for' => __( 'Visual products', 'wc-variation-images-pro' ),
			),
			'circular' => array(
				'label' => __( 'Circular Thumbnails', 'wc-variation-images-pro' ),
				'description' => __( 'Circular image boxes in a horizontal row', 'wc-variation-images-pro' ),
				'icon' => '⭕',
				'best_for' => __( 'Visual products', 'wc-variation-images-pro' ),
			),
		);
		?>
		<div class="wcvip-style-options-container">
			<!-- Free Options Section -->
			<div class="wcvip-style-section wcvip-style-section-free">
				<div class="wcvip-style-section-header">
					<h5 class="wcvip-style-section-title">
						<span class="wcvip-section-icon">✨</span>
						<?php esc_html_e( 'Free Options', 'wc-variation-images-pro' ); ?>
					</h5>
					<p class="wcvip-style-section-description">
						<?php esc_html_e( 'Choose from these free display styles for your product variations', 'wc-variation-images-pro' ); ?>
					</p>
				</div>
				<div class="wcvip-style-grid wcvip-style-grid-free">
					<?php foreach ( $free_styles as $key => $style_data ) : ?>
						<div class="wcvip-style-card wcvip-style-<?php echo esc_attr( $key ); ?> <?php echo $current_style === $key ? 'active' : ''; ?>" data-style="<?php echo esc_attr( $key ); ?>" role="button" tabindex="0" aria-label="<?php echo esc_attr( $style_data['label'] ); ?>">
							<div class="wcvip-style-preview">
								<?php echo wp_kses_post( $this->get_style_preview_html( $key, $product_id ) ); ?>
							</div>
							<div class="wcvip-style-card-body">
								<h6 class="wcvip-style-label"><?php echo esc_html( $style_data['label'] ); ?></h6>
								<p class="wcvip-style-description"><?php echo esc_html( $style_data['description'] ); ?></p>
								<span class="wcvip-style-best-for">
									<span class="wcvip-best-for-icon">💡</span>
									<?php echo esc_html( $style_data['best_for'] ); ?>
								</span>
							</div>
							<div class="wcvip-style-card-actions">
								<?php
								$preview_url = get_permalink( $product_id );
								$preview_url = add_query_arg( array(
									'wcvip_preview' => 'true',
									'wcvip_style' => $key,
									'wcvip_nonce' => wp_create_nonce( 'wcvip-preview-' . $product_id ),
								), $preview_url );
								?>
								<a href="<?php echo esc_url( $preview_url ); ?>" target="_blank" class="button button-small wcvip-card-preview-btn" data-base-url="<?php echo esc_url( get_permalink( $product_id ) ); ?>" data-product-id="<?php echo esc_attr( $product_id ); ?>" data-style="<?php echo esc_attr( $key ); ?>" data-preview-nonce="<?php echo esc_attr( wp_create_nonce( 'wcvip-preview-' . $product_id ) ); ?>">
									<?php esc_html_e( 'Preview', 'wc-variation-images-pro' ); ?>
								</a>
								<button type="button" class="button button-primary button-small wcvip-card-save-btn" data-product-id="<?php echo esc_attr( $product_id ); ?>" data-style="<?php echo esc_attr( $key ); ?>">
									<?php esc_html_e( 'Save', 'wc-variation-images-pro' ); ?>
								</button>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			</div>

			<!-- Pro Options Section -->
			<div class="wcvip-style-section wcvip-style-section-pro">
				<div class="wcvip-style-section-header">
					<h5 class="wcvip-style-section-title">
						<span class="wcvip-section-icon">⭐</span>
						<?php esc_html_e( 'Pro Options (Preview)', 'wc-variation-images-pro' ); ?>
						<?php if ( ! $pro_available ) : ?>
							<span class="wcvip-pro-section-badge"><?php esc_html_e( 'Preview Only', 'wc-variation-images-pro' ); ?></span>
						<?php endif; ?>
					</h5>
					<p class="wcvip-style-section-description">
						<?php if ( $pro_available ) : ?>
							<?php esc_html_e( 'Advanced display styles with image support', 'wc-variation-images-pro' ); ?>
						<?php else : ?>
							<?php esc_html_e( 'Preview of advanced styles available in Pro version. Upgrade to unlock these features.', 'wc-variation-images-pro' ); ?>
						<?php endif; ?>
					</p>
				</div>
				<div class="wcvip-style-grid wcvip-style-grid-pro">
					<?php foreach ( $paid_styles as $key => $style_data ) : ?>
						<div class="wcvip-style-card wcvip-style-<?php echo esc_attr( $key ); ?> <?php echo $current_style === $key ? 'active' : ''; ?> <?php echo ! $pro_available ? 'wcvip-pro-disabled' : ''; ?>" data-style="<?php echo esc_attr( $key ); ?>" role="button" tabindex="<?php echo $pro_available ? '0' : '-1'; ?>" aria-label="<?php echo esc_attr( $style_data['label'] ); ?>" <?php echo ! $pro_available ? 'aria-disabled="true" title="' . esc_attr__( 'Available in Pro version', 'wc-variation-images-pro' ) . '"' : ''; ?>>
							<div class="wcvip-style-preview">
								<?php echo wp_kses_post( $this->get_style_preview_html( $key, $product_id ) ); ?>
							</div>
							<div class="wcvip-style-card-body">
								<h6 class="wcvip-style-label"><?php echo esc_html( $style_data['label'] ); ?></h6>
								<p class="wcvip-style-description"><?php echo esc_html( $style_data['description'] ); ?></p>
								<span class="wcvip-style-best-for">
									<span class="wcvip-best-for-icon">💡</span>
									<?php echo esc_html( $style_data['best_for'] ); ?>
								</span>
								<?php if ( ! $pro_available ) : ?>
									<span class="wcvip-pro-badge">⭐ <?php esc_html_e( 'Pro Only', 'wc-variation-images-pro' ); ?></span>
								<?php endif; ?>
							</div>
							<?php if ( $pro_available ) : ?>
								<div class="wcvip-style-card-actions">
									<?php
									$preview_url = get_permalink( $product_id );
									$preview_url = add_query_arg( array(
										'wcvip_preview' => 'true',
										'wcvip_style' => $key,
										'wcvip_nonce' => wp_create_nonce( 'wcvip-preview-' . $product_id ),
									), $preview_url );
									?>
									<a href="<?php echo esc_url( $preview_url ); ?>" target="_blank" class="button button-small wcvip-card-preview-btn" data-base-url="<?php echo esc_url( get_permalink( $product_id ) ); ?>" data-product-id="<?php echo esc_attr( $product_id ); ?>" data-style="<?php echo esc_attr( $key ); ?>" data-preview-nonce="<?php echo esc_attr( wp_create_nonce( 'wcvip-preview-' . $product_id ) ); ?>">
										<?php esc_html_e( 'Preview', 'wc-variation-images-pro' ); ?>
									</a>
									<button type="button" class="button button-primary button-small wcvip-card-save-btn" data-product-id="<?php echo esc_attr( $product_id ); ?>" data-style="<?php echo esc_attr( $key ); ?>">
										<?php esc_html_e( 'Save', 'wc-variation-images-pro' ); ?>
									</button>
								</div>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Get best image URL for preview (variation image → product featured image → placeholder)
	 */
	private function get_preview_image_url( $product_id = null ) {
		// Try to get variation image first
		if ( $product_id ) {
			$product = wc_get_product( $product_id );
			if ( $product ) {
				if ( $product->is_type( 'variable' ) ) {
					$variations = $product->get_available_variations();
					if ( ! empty( $variations ) ) {
						foreach ( $variations as $variation_data ) {
							if ( ! empty( $variation_data['image'] ) && ! empty( $variation_data['image']['src'] ) ) {
								return $variation_data['image']['src'];
							}
						}
					}
					
					// Try custom variation images
					$variation_ids = $product->get_children();
					if ( ! empty( $variation_ids ) ) {
						foreach ( $variation_ids as $variation_id ) {
							$custom_images = get_post_meta( $variation_id, '_wcvip_images', true );
							if ( ! empty( $custom_images ) && is_array( $custom_images ) ) {
								$first_image = reset( $custom_images );
								if ( ! empty( $first_image['id'] ) ) {
									$image_url = wp_get_attachment_image_url( $first_image['id'], 'thumbnail' );
									if ( $image_url ) {
										return $image_url;
									}
								}
							}
						}
					}
				}
				
				// Try product featured image
				$featured_image_id = $product->get_image_id();
				if ( $featured_image_id ) {
					$image_url = wp_get_attachment_image_url( $featured_image_id, 'thumbnail' );
					if ( $image_url ) {
						return $image_url;
					}
				}
			}
		}
		
		// Fallback to WooCommerce placeholder
		return wc_placeholder_img_src( 'thumbnail' );
	}

	/**
	 * Get HTML for style preview
	 */
	private function get_style_preview_html( $style_key, $product_id = null ) {
		$html = '';
		
		switch ( $style_key ) {
			case 'square':
				// Use real product image if available
				$image_url = $this->get_preview_image_url( $product_id );
				$html = '<div class="wcvip-preview-square-thumbs">
					<div class="wcvip-preview-thumb active">
						<img src="' . esc_url( $image_url ) . '" alt="' . esc_attr__( 'Product image', 'wc-variation-images-pro' ) . '" />
					</div>
					<div class="wcvip-preview-thumb">
						<img src="' . esc_url( $image_url ) . '" alt="' . esc_attr__( 'Product image', 'wc-variation-images-pro' ) . '" />
					</div>
					<div class="wcvip-preview-thumb">
						<img src="' . esc_url( $image_url ) . '" alt="' . esc_attr__( 'Product image', 'wc-variation-images-pro' ) . '" />
					</div>
				</div>';
				break;
				
			case 'circular':
				// Use real product image if available
				$image_url = $this->get_preview_image_url( $product_id );
				$html = '<div class="wcvip-preview-circular-thumbs">
					<div class="wcvip-preview-circle active">
						<img src="' . esc_url( $image_url ) . '" alt="' . esc_attr__( 'Product image', 'wc-variation-images-pro' ) . '" />
					</div>
					<div class="wcvip-preview-circle">
						<img src="' . esc_url( $image_url ) . '" alt="' . esc_attr__( 'Product image', 'wc-variation-images-pro' ) . '" />
					</div>
					<div class="wcvip-preview-circle">
						<img src="' . esc_url( $image_url ) . '" alt="' . esc_attr__( 'Product image', 'wc-variation-images-pro' ) . '" />
					</div>
				</div>';
				break;
				
			case 'rectangular':
				$html = '<div class="wcvip-preview-rectangular">
					<div class="wcvip-preview-rect-item">
						<div class="wcvip-preview-rect-image"></div>
						<div class="wcvip-preview-rect-label">Color</div>
					</div>
					<div class="wcvip-preview-rect-item">
						<div class="wcvip-preview-rect-image"></div>
						<div class="wcvip-preview-rect-label">Size</div>
					</div>
				</div>';
				break;
				
			case 'dropdown':
				$html = '<div class="wcvip-preview-dropdown">
					<div class="wcvip-preview-dropdown-select">
						<span>Choose option</span>
						<span class="wcvip-preview-dropdown-arrow">▼</span>
					</div>
					<div class="wcvip-preview-dropdown-thumb"></div>
				</div>';
				break;
				
			case 'buttons':
				// Use real product image if available
				$image_url = $this->get_preview_image_url( $product_id );
				$html = '<div class="wcvip-preview-buttons">
					<div class="wcvip-preview-button active">
						<div class="wcvip-preview-button-thumb">
							<img src="' . esc_url( $image_url ) . '" alt="' . esc_attr__( 'Product image', 'wc-variation-images-pro' ) . '" />
						</div>
						<span>Small</span>
					</div>
					<div class="wcvip-preview-button">
						<div class="wcvip-preview-button-thumb">
							<img src="' . esc_url( $image_url ) . '" alt="' . esc_attr__( 'Product image', 'wc-variation-images-pro' ) . '" />
						</div>
						<span>Large</span>
					</div>
				</div>';
				break;
				
			case 'buttons_text_first':
				// Use real product image if available
				$image_url = $this->get_preview_image_url( $product_id );
				$html = '<div class="wcvip-preview-buttons wcvip-preview-buttons-text-first">
					<div class="wcvip-preview-button active">
						<span>Small</span>
						<div class="wcvip-preview-button-thumb">
							<img src="' . esc_url( $image_url ) . '" alt="' . esc_attr__( 'Product image', 'wc-variation-images-pro' ) . '" />
						</div>
					</div>
					<div class="wcvip-preview-button">
						<span>Large</span>
						<div class="wcvip-preview-button-thumb">
							<img src="' . esc_url( $image_url ) . '" alt="' . esc_attr__( 'Product image', 'wc-variation-images-pro' ) . '" />
						</div>
					</div>
				</div>';
				break;
				
			case 'vertical':
				$html = '<div class="wcvip-preview-vertical">
					<div class="wcvip-preview-vertical-item active"></div>
					<div class="wcvip-preview-vertical-item"></div>
					<div class="wcvip-preview-vertical-item"></div>
				</div>';
				break;
				
			case 'horizontal_text':
				$html = '<div class="wcvip-preview-horizontal-text">
					<div class="wcvip-preview-text-box active">Var 1</div>
					<div class="wcvip-preview-text-box">Var 2</div>
					<div class="wcvip-preview-text-box">Var 3</div>
				</div>';
				break;
				
			case 'vertical_text':
				$html = '<div class="wcvip-preview-vertical-text">
					<div class="wcvip-preview-text-box active">Var 1</div>
					<div class="wcvip-preview-text-box">Var 2</div>
					<div class="wcvip-preview-text-box">Var 3</div>
				</div>';
				break;
				
			case 'color_swatches':
				$html = '<div class="wcvip-preview-color-swatches">
					<div class="wcvip-preview-color-circle" style="background-color: #ff0000;"></div>
					<div class="wcvip-preview-color-circle active" style="background-color: #00ff00;"></div>
					<div class="wcvip-preview-color-circle" style="background-color: #0000ff;"></div>
				</div>';
				break;
				
			case 'grid':
				$html = '<div class="wcvip-preview-grid">
					<div class="wcvip-preview-grid-item active"></div>
					<div class="wcvip-preview-grid-item"></div>
					<div class="wcvip-preview-grid-item"></div>
					<div class="wcvip-preview-grid-item"></div>
				</div>';
				break;
				
			case 'strip':
				$html = '<div class="wcvip-preview-strip">
					<div class="wcvip-preview-strip-item active"></div>
					<div class="wcvip-preview-strip-item"></div>
					<div class="wcvip-preview-strip-item"></div>
					<div class="wcvip-preview-strip-item"></div>
				</div>';
				break;
				
			case 'radio':
				$html = '<div class="wcvip-preview-radio">
					<div class="wcvip-preview-radio-item active">
						<span class="wcvip-radio-circle">●</span>
						<div class="wcvip-preview-radio-thumb"></div>
					</div>
					<div class="wcvip-preview-radio-item">
						<span class="wcvip-radio-circle">○</span>
						<div class="wcvip-preview-radio-thumb"></div>
					</div>
				</div>';
				break;
				
			case 'custom':
				$html = '<div class="wcvip-preview-custom">
					<div class="wcvip-preview-custom-icon">∞</div>
					<div class="wcvip-preview-custom-label">Custom Mix</div>
				</div>';
				break;
				
			default:
				$html = '<div class="wcvip-preview-default"></div>';
		}
		
		return $html;
	}

	/**
	 * Render live preview
	 */
	private function render_preview( $product_id ) {
		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return;
		}

		// Get product data
		$product_name = $product->get_name();
		$product_price = $product->get_price_html();
		$product_description = $product->get_short_description() ? $product->get_short_description() : $product->get_description();
		
		// Get product gallery images
		$gallery_image_ids = $product->get_gallery_image_ids();
		$featured_image_id = $product->get_image_id();
		
		// Combine featured image with gallery
		$all_image_ids = array();
		if ( $featured_image_id ) {
			$all_image_ids[] = $featured_image_id;
		}
		if ( ! empty( $gallery_image_ids ) ) {
			$all_image_ids = array_merge( $all_image_ids, $gallery_image_ids );
		}
		
		?>
		<div class="wcvip-preview-container">
			<div class="wcvip-preview-product-page">
				<!-- Product Images Gallery -->
				<?php if ( ! empty( $all_image_ids ) ) : ?>
					<div class="wcvip-preview-gallery">
						<div class="wcvip-preview-main-image">
							<?php 
							$main_image_id = $all_image_ids[0];
							echo wp_get_attachment_image( $main_image_id, 'woocommerce_single', false, array( 'class' => 'wcvip-preview-featured-image' ) );
							?>
						</div>
						<?php if ( count( $all_image_ids ) > 1 ) : ?>
							<div class="wcvip-preview-thumbnails">
								<?php foreach ( $all_image_ids as $index => $image_id ) : ?>
									<div class="wcvip-preview-thumbnail <?php echo $index === 0 ? 'active' : ''; ?>">
										<?php echo wp_get_attachment_image( $image_id, 'woocommerce_gallery_thumbnail', false ); ?>
									</div>
								<?php endforeach; ?>
							</div>
						<?php endif; ?>
					</div>
				<?php endif; ?>

				<!-- Product Info -->
				<div class="wcvip-preview-product-info">
					<h2 class="wcvip-preview-product-title"><?php echo esc_html( $product_name ); ?></h2>
					
					<?php if ( $product_price ) : ?>
						<div class="wcvip-preview-product-price">
							<?php echo wp_kses_post( $product_price ); ?>
						</div>
					<?php endif; ?>

					<?php if ( $product_description ) : ?>
						<div class="wcvip-preview-product-description">
							<?php echo wp_kses_post( wpautop( $product_description ) ); ?>
						</div>
					<?php endif; ?>

					<!-- Variation Selector -->
					<div class="wcvip-preview-selector" id="wcvip-live-preview-selector">
						<?php $this->render_live_preview_selector( $product_id ); ?>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render live preview selector using frontend renderer
	 */
	private function render_live_preview_selector( $product_id ) {
		// Temporarily set global product for frontend renderer
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce global $product is standard
		global $product;
		$original_product = isset( $product ) ? $product : null;
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce global $product is standard
		$product = wc_get_product( $product_id );

		if ( ! $product || ! $product->is_type( 'variable' ) ) {
			echo '<p>' . esc_html__( 'Preview not available for this product.', 'wc-variation-images-pro' ) . '</p>';
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce global $product is standard
			$product = $original_product;
			return;
		}

		// Use the frontend product page class to render selector
		$product_page = new WCVIP_Product_Page();
		
		// Capture output
		ob_start();
		$product_page->render_custom_variation_selector();
		$selector_html = ob_get_clean();

		if ( ! empty( $selector_html ) ) {
			echo wp_kses_post( $selector_html );
		} else {
			echo '<p class="description">' . esc_html__( 'No variation images configured yet. Add images to variations to see preview.', 'wc-variation-images-pro' ) . '</p>';
		}

		// Restore original product
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce global $product is standard
		$product = $original_product;
	}

	/**
	 * AJAX: Get variations for designer
	 */
	public function ajax_get_variations_for_designer() {
		// Check nonce and log failures
		if ( ! check_ajax_referer( 'wcvip-designer-nonce', 'nonce', false ) ) {
			WCVIP_Security_Logger::log(
				'nonce_failed',
				'Failed nonce verification for ajax_get_variations_for_designer',
				array(
					'action' => 'ajax_get_variations_for_designer',
					'nonce' => isset( $_POST['nonce'] ) ? 'present' : 'missing',
				)
			);
			wp_send_json_error( array( 'message' => __( 'Security check failed', 'wc-variation-images-pro' ) ) );
		}

		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		if ( ! $product_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid product ID', 'wc-variation-images-pro' ) ) );
		}

		$product = wc_get_product( $product_id );
		if ( ! $product || ! $product->is_type( 'variable' ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid product', 'wc-variation-images-pro' ) ) );
		}

		// Verify user can edit this product
		if ( ! current_user_can( 'edit_product', $product_id ) ) {
			WCVIP_Security_Logger::log(
				'permission_denied',
				'User attempted to get variations for designer without permission',
				array(
					'product_id' => $product_id,
					'user_id' => get_current_user_id(),
				)
			);
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions', 'wc-variation-images-pro' ) ) );
		}

		$variation_ids = $product->get_children();
		$variations = array();

		foreach ( $variation_ids as $variation_id ) {
			$variation = wc_get_product( $variation_id );
			if ( ! $variation ) {
				continue;
			}

			$custom_images = get_post_meta( $variation_id, '_wcvip_images', true );
			if ( ! is_array( $custom_images ) ) {
				$custom_images = array();
			}

			// If no custom images, check for WooCommerce variation image as fallback
			$images_for_display = $custom_images;
			if ( empty( $custom_images ) ) {
				$woo_image_id = $variation->get_image_id();
				if ( $woo_image_id ) {
					$woo_thumbnail_url = wp_get_attachment_image_url( $woo_image_id, 'thumbnail' );
					if ( $woo_thumbnail_url ) {
						$images_for_display = array(
							array(
								'id'        => $woo_image_id,
								'thumbnail' => $woo_thumbnail_url,
								'url'       => wp_get_attachment_image_url( $woo_image_id, 'full' ),
								'alt'       => get_post_meta( $woo_image_id, '_wp_attachment_image_alt', true ),
							),
						);
					}
				}
			}

			$variations[] = array(
				'id'            => $variation->get_id(),
				'name'          => wc_get_formatted_variation( $variation, true ),
				'attributes'    => $variation->get_variation_attributes(),
				'images'        => $images_for_display,
				'image_count'   => count( $custom_images ),
			);
		}

		wp_send_json_success( $variations );
	}

	/**
	 * AJAX: Save designer layout
	 */
	public function ajax_save_designer_layout() {
		// Check nonce and log failures
		if ( ! check_ajax_referer( 'wcvip-designer-nonce', 'nonce', false ) ) {
			WCVIP_Security_Logger::log(
				'nonce_failed',
				'Failed nonce verification for ajax_save_designer_layout',
				array(
					'action' => 'ajax_save_designer_layout',
					'nonce' => isset( $_POST['nonce'] ) ? 'present' : 'missing',
				)
			);
			wp_send_json_error( array( 'message' => __( 'Security check failed', 'wc-variation-images-pro' ) ) );
		}

		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		
		if ( ! $product_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid product ID', 'wc-variation-images-pro' ) ) );
		}

		// Verify product exists and user can edit it
		$product = wc_get_product( $product_id );
		if ( ! $product || ! current_user_can( 'edit_product', $product_id ) ) {
			WCVIP_Security_Logger::log(
				'permission_denied',
				'User attempted to save designer layout without permission',
				array(
					'product_id' => $product_id,
					'user_id' => get_current_user_id(),
				)
			);
			wp_send_json_error( array( 'message' => __( 'Invalid product or insufficient permissions', 'wc-variation-images-pro' ) ) );
		}

		// Decode and validate layout data
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON data must be decoded before sanitization
		$layout_raw = isset( $_POST['layout'] ) ? wp_unslash( $_POST['layout'] ) : '';
		$layout = json_decode( $layout_raw, true );

		// Validate JSON structure
		if ( json_last_error() !== JSON_ERROR_NONE ) {
			wp_send_json_error( array( 'message' => __( 'Invalid layout data format', 'wc-variation-images-pro' ) ) );
		}

		// Ensure layout is an array
		if ( ! is_array( $layout ) ) {
			$layout = array();
		}

		// Sanitize layout data recursively (handles nested arrays and sanitizes all string values)
		$layout = $this->sanitize_layout_data( $layout );

		// Save layout configuration
		update_post_meta( $product_id, '_wcvip_designer_layout', $layout );

		// Save attribute styles if provided
		if ( isset( $_POST['attribute_styles'] ) && is_array( $_POST['attribute_styles'] ) ) {
			$attribute_styles = array();
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Array values are sanitized in the loop below
			$attribute_styles_raw = wp_unslash( $_POST['attribute_styles'] );
			foreach ( $attribute_styles_raw as $attr_key => $style ) {
				$attr_key = sanitize_text_field( $attr_key );
				$style = sanitize_text_field( $style );
				if ( ! empty( $style ) ) {
					$attribute_styles[ $attr_key ] = $style;
				}
				// Note: Empty values are intentionally not added to the array,
				// which means they will be removed from stored settings (fallback to default)
			}
			update_post_meta( $product_id, '_wcvip_attribute_styles', $attribute_styles );
		}

		wp_send_json_success( array( 'message' => __( 'Design saved successfully', 'wc-variation-images-pro' ) ) );
	}

	/**
	 * Recursively sanitize layout data
	 *
	 * @param mixed $data Data to sanitize.
	 * @return mixed Sanitized data.
	 */
	private function sanitize_layout_data( $data ) {
		if ( is_array( $data ) ) {
			$sanitized = array();
			foreach ( $data as $key => $value ) {
				$sanitized_key = sanitize_key( $key );
				$sanitized[ $sanitized_key ] = $this->sanitize_layout_data( $value );
			}
			return $sanitized;
		} elseif ( is_string( $data ) ) {
			return sanitize_text_field( $data );
		} elseif ( is_numeric( $data ) ) {
			return is_float( $data ) ? floatval( $data ) : intval( $data );
		} elseif ( is_bool( $data ) ) {
			return (bool) $data;
		}
		return $data;
	}

	/**
	 * AJAX: Preview variation
	 */
	public function ajax_preview_variation() {
		// Check nonce and log failures
		if ( ! check_ajax_referer( 'wcvip-designer-nonce', 'nonce', false ) ) {
			WCVIP_Security_Logger::log(
				'nonce_failed',
				'Failed nonce verification for ajax_preview_variation',
				array(
					'action' => 'ajax_preview_variation',
					'nonce' => isset( $_POST['nonce'] ) ? 'present' : 'missing',
				)
			);
			wp_send_json_error( array( 'message' => __( 'Security check failed', 'wc-variation-images-pro' ) ) );
		}

		$variation_id = isset( $_POST['variation_id'] ) ? absint( $_POST['variation_id'] ) : 0;
		if ( ! $variation_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid variation ID', 'wc-variation-images-pro' ) ) );
		}

		$custom_images = get_post_meta( $variation_id, '_wcvip_images', true );
		if ( ! is_array( $custom_images ) ) {
			$custom_images = array();
		}

		wp_send_json_success( $custom_images );
	}

	/**
	 * AJAX: Refresh selector preview
	 */
	public function ajax_refresh_selector_preview() {
		// Check nonce and log failures
		if ( ! check_ajax_referer( 'wcvip-designer-nonce', 'nonce', false ) ) {
			WCVIP_Security_Logger::log(
				'nonce_failed',
				'Failed nonce verification for ajax_refresh_selector_preview',
				array(
					'action' => 'ajax_refresh_selector_preview',
					'nonce' => isset( $_POST['nonce'] ) ? 'present' : 'missing',
				)
			);
			wp_send_json_error( array( 'message' => __( 'Security check failed', 'wc-variation-images-pro' ) ) );
		}

		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		$display_style = isset( $_POST['display_style'] ) ? sanitize_text_field( wp_unslash( $_POST['display_style'] ) ) : '';
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Array values are sanitized in the loop below
		$attribute_styles_raw = isset( $_POST['attribute_styles'] ) && is_array( $_POST['attribute_styles'] ) ? wp_unslash( $_POST['attribute_styles'] ) : array();
		$attribute_styles = array();
		foreach ( $attribute_styles_raw as $attr_key => $style ) {
			$attr_key = sanitize_text_field( $attr_key );
			$style = sanitize_text_field( $style );
			if ( ! empty( $style ) ) {
				$attribute_styles[ $attr_key ] = $style;
			}
		}

		if ( ! $product_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid product ID', 'wc-variation-images-pro' ) ) );
		}

		// Temporarily update display style if provided
		$original_style = null;
		if ( ! empty( $display_style ) ) {
			$original_style = get_option( 'wcvip_display_style', 'none' );
			update_option( 'wcvip_display_style', $display_style );
		}

		// Temporarily update attribute styles if provided
		$original_attribute_styles = null;
		$has_attribute_styles = false;
		if ( ! empty( $attribute_styles ) ) {
			$original_attribute_styles = get_post_meta( $product_id, '_wcvip_attribute_styles', true );
			$has_attribute_styles = true;
			if ( ! is_array( $original_attribute_styles ) ) {
				$original_attribute_styles = array();
			}
			
			// Sanitize and prepare attribute styles for temporary storage
			$temp_attribute_styles = array();
			foreach ( $attribute_styles as $attr_key => $style ) {
				$attr_key = sanitize_text_field( $attr_key );
				$style = sanitize_text_field( $style );
				if ( ! empty( $style ) ) {
					$temp_attribute_styles[ $attr_key ] = $style;
				}
			}
			update_post_meta( $product_id, '_wcvip_attribute_styles', $temp_attribute_styles );
		}

		// Temporarily set global product for frontend renderer
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce global $product is standard
		global $product;
		$original_product = isset( $product ) ? $product : null;
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce global $product is standard
		$product = wc_get_product( $product_id );

		if ( ! $product || ! $product->is_type( 'variable' ) ) {
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce global $product is standard
			$product = $original_product;
			if ( ! empty( $display_style ) && null !== $original_style ) {
				update_option( 'wcvip_display_style', $original_style );
			}
			if ( $has_attribute_styles ) {
				if ( empty( $original_attribute_styles ) ) {
					delete_post_meta( $product_id, '_wcvip_attribute_styles' );
				} else {
					update_post_meta( $product_id, '_wcvip_attribute_styles', $original_attribute_styles );
				}
			}
			wp_send_json_error( array( 'message' => __( 'Invalid product', 'wc-variation-images-pro' ) ) );
		}

		// Use the frontend product page class to render selector
		$product_page = new WCVIP_Product_Page();
		
		// Capture output
		ob_start();
		$product_page->render_custom_variation_selector();
		$selector_html = ob_get_clean();

		// Restore original product, style, and attribute styles
		// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce global $product is standard
		$product = $original_product;
		if ( ! empty( $display_style ) && null !== $original_style ) {
			update_option( 'wcvip_display_style', $original_style );
		}
		if ( $has_attribute_styles ) {
			if ( empty( $original_attribute_styles ) ) {
				delete_post_meta( $product_id, '_wcvip_attribute_styles' );
			} else {
				update_post_meta( $product_id, '_wcvip_attribute_styles', $original_attribute_styles );
			}
		}

		if ( ! empty( $selector_html ) ) {
			wp_send_json_success( array( 'html' => $selector_html ) );
		} else {
			wp_send_json_success( array( 'html' => '<p class="description">' . esc_html__( 'No variation images configured yet. Add images to variations to see preview.', 'wc-variation-images-pro' ) . '</p>' ) );
		}
	}
}

