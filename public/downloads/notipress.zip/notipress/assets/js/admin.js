(function($) {
	function hash(s) { var h = 0; for (var i = 0; i < s.length; i++) h = ((h << 5) - h) + s.charCodeAt(i) | 0; return (h >>> 0).toString(36); }
	function norm(s) { return s.replace(/\s+/g, ' ').trim().replace(/\s*(Dismiss|Close|×)\s*/gi, ' ').replace(/\s+/g, ' ').trim(); }
	function getNoticeId($n) { var t = norm($n.text().trim().substring(0, 200)); return $n.attr('id') || $n.attr('data-notice-id') || hash(t); }
	function isCore($n) { return $n.hasClass('notice-error') || $n.hasClass('notice-warning') || $n.hasClass('update-nag') || $n.hasClass('settings-error'); }
	function addHideBtn($el, data) {
		if ($el.find('.notipress-hide-btn').length || data.isSettingsPage) return;
		var id = $el.attr('data-notipress-id') || getNoticeId($el), label = $el.text().trim().substring(0, 100);
		$el.attr('data-notipress-id', id).css('position', 'relative')
			.append($('<button class="notipress-hide-btn" type="button" title="Hide this notice permanently" aria-label="Hide this notice permanently">×</button>').on('click', function(e) {
				e.preventDefault();
				$.post(data.ajaxurl, { action: data.hideAction, nonce: data.nonce, notice_id: id, notice_label: label }, function(r) {
					if (r.success) $el.slideUp(300, function() { $(this).remove(); });
				});
			}));
	}
	$(function() {
		if (typeof notipressData === 'undefined') return;
		var d = notipressData, hiddenIds = d.hiddenIds || [];
		$('.notice, .updated').each(function() {
			var $n = $(this), id = getNoticeId($n);
			$n.attr('data-notipress-id', id);
			if (hiddenIds.indexOf(id) !== -1) $n.hide();
			else if (!isCore($n)) addHideBtn($n, d);
		});
		$('#notipress-clear-hidden').on('click', function() {
			if (!d.clearAction || !confirm(d.confirmClear || 'Are you sure you want to clear all hidden notices? They will appear again.')) return;
			$.post(d.ajaxurl, { action: d.clearAction, nonce: d.nonce }, function(r) { if (r.success) location.reload(); });
		});
		var wrap = document.querySelector('.wrap');
		if (wrap) {
			new MutationObserver(function(mutations) {
				mutations.forEach(function(m) {
					[].forEach.call(m.addedNodes, function(node) {
						if (node.nodeType !== 1) return;
						var $node = $(node);
						if (($node.hasClass('notice') || $node.hasClass('updated')) && !isCore($node)) addHideBtn($node, d);
					});
				});
			}).observe(wrap, { childList: true, subtree: true });
		}
	});
})(jQuery);
