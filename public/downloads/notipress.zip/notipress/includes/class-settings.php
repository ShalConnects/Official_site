<?php
if (!defined('ABSPATH')) exit;

class Notipress_Settings {

	public function __construct() {
		add_action('admin_menu', array($this, 'add_settings_page'));
		add_action('admin_menu', array($this, 'menu_title_with_count'), 99);
		add_action('admin_init', array($this, 'register_settings'));
	}

	public function add_settings_page() {
		$d = Notipress::TEXT_DOMAIN;
		add_options_page(__('Notipress Settings', $d), __('Notipress', $d), Notipress::CAP, Notipress::SLUG, array($this, 'render_settings_page'));
	}

	public function menu_title_with_count() {
		global $submenu;
		$c = Notipress::get_hidden_count();
		if ($c <= 0 || empty($submenu['options-general.php'])) return;
		foreach ($submenu['options-general.php'] as &$item) {
			if (isset($item[2]) && $item[2] === Notipress::SLUG) {
				$item[0] .= ' (' . number_format_i18n($c) . ')';
				break;
			}
		}
	}

	public function register_settings() {
		$bool = array('sanitize_callback' => array('Notipress', 'sanitize_bool'));
		register_setting(Notipress::SETTINGS_GROUP, Notipress::OPT_HIDE_ALL, $bool);
		register_setting(Notipress::SETTINGS_GROUP, Notipress::OPT_HIDDEN, array('sanitize_callback' => array($this, 'sanitize_hidden')));
	}

	public function sanitize_hidden($v) {
		if (!is_array($v)) return array();
		$out = array();
		foreach ($v as $n) {
			$item = Notipress::normalize_hidden_item($n);
			if ($item) $out[] = $item;
		}
		return $out;
	}

	public function render_settings_page() {
		if (!current_user_can(Notipress::CAP)) return;
		$hidden = Notipress::get(Notipress::OPT_HIDDEN);
		$count = Notipress::get_hidden_count();
		$d = Notipress::TEXT_DOMAIN;
		?>
		<div class="wrap">
			<h1><?php echo esc_html(get_admin_page_title()); ?></h1>
			<?php if ($count > 0) echo '<p>' . esc_html(sprintf(__('You have hidden %s notification(s).', $d), number_format_i18n($count))) . '</p>'; ?>
			<form method="post" action="options.php">
				<?php settings_fields(Notipress::SETTINGS_GROUP); ?>
				<table class="form-table">
					<tr>
						<th scope="row"><?php echo esc_html(__('Hide All Plugin Notices', $d)); ?></th>
						<td>
							<input type="hidden" name="<?php echo esc_attr(Notipress::OPT_HIDE_ALL); ?>" value="0">
							<label><input type="checkbox" name="<?php echo esc_attr(Notipress::OPT_HIDE_ALL); ?>" value="1" <?php checked(Notipress::get(Notipress::OPT_HIDE_ALL), '1'); ?>>
								<?php echo esc_html(__('Hide all third-party plugin notices (rating requests, updates, etc.)', $d)); ?></label>
							<p class="description"><?php echo esc_html(__('WordPress core notices (errors, warnings) will still be visible.', $d)); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php echo esc_html(__('Hidden Notices', $d)); ?></th>
						<td>
							<?php
							if (!empty($hidden)) {
								echo '<ul style="list-style: disc; padding-left: 20px;">';
								foreach ($hidden as $n) {
									$label = is_array($n) ? ($n['label'] ?? '') : (string) $n;
									echo '<li>' . esc_html($label) . '</li>';
								}
								echo '</ul>';
							} else {
								echo '<p>' . esc_html(__('No notices hidden yet. Click the × button on any notice to hide it.', $d)) . '</p>';
							}
							?>
							<button type="button" class="button" id="notipress-clear-hidden"><?php echo esc_html(__('Clear All Hidden Notices', $d)); ?></button>
						</td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>
			<hr><h2><?php echo esc_html(__('How to Use', $d)); ?></h2>
			<ol>
				<li><strong><?php echo esc_html(__('Hide All Notices:', $d)); ?></strong> <?php echo esc_html(__('Enable the checkbox above to hide all third-party plugin notices automatically.', $d)); ?></li>
				<li><strong><?php echo esc_html(__('Hide Individual Notices:', $d)); ?></strong> <?php echo esc_html(__('Click the × button that appears on any notice to hide it permanently.', $d)); ?></li>
			</ol>
			<p><em><?php echo esc_html(__('Note: Important WordPress error and warning messages will always be visible for your safety.', $d)); ?></em></p>
		</div>
		<?php
	}
}
