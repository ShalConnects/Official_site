<?php
if (!defined('ABSPATH')) exit;

class Notipress_Notice_Hider {

	public function __construct() {
		add_action('admin_head', array($this, 'admin_head'), 1);
		add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
		add_action('wp_ajax_' . Notipress::AJAX_HIDE, array($this, 'ajax_hide_notice'));
		add_action('wp_ajax_' . Notipress::AJAX_CLEAR, array($this, 'ajax_clear_notices'));
	}

	public function admin_head() {
		if (Notipress::get(Notipress::OPT_HIDE_ALL) !== '1') return;
		add_filter('admin_body_class', function ($c) { return $c . ' notipress-hide-all'; });
		echo '<style id="notipress-hide-all">';
		echo '.notice:not(.notice-error):not(.notice-warning):not(.update-nag),.updated:not(.settings-error),div[class*="rating-"],div[class*="review-"],.woocommerce-message,.wc-admin-notice{display:none!important;}';
		echo '.notice-error,.notice-warning,.update-nag,.settings-error{display:block!important;}';
		echo '</style>';
	}

	public function enqueue_scripts($hook) {
		$hidden = Notipress::get_hidden_ids();
		$need_assets = ($hook === 'settings_page_' . Notipress::SLUG)
			|| Notipress::get(Notipress::OPT_HIDE_ALL) === '1'
			|| !empty($hidden);
		if (!$need_assets) return;

		$u = NOTIPRESS_PLUGIN_URL;
		$v = NOTIPRESS_VERSION;
		wp_enqueue_script('notipress-admin', $u . 'assets/js/admin.js', array('jquery'), $v, true);
		wp_enqueue_style('notipress-admin', $u . 'assets/css/admin.css', array(), $v);
		wp_localize_script('notipress-admin', 'notipressData', array(
			'ajaxurl' => admin_url('admin-ajax.php'),
			'nonce' => wp_create_nonce(Notipress::NONCE),
			'hiddenIds' => $hidden,
			'isSettingsPage' => $hook === 'settings_page_' . Notipress::SLUG,
			'hideAction' => Notipress::AJAX_HIDE,
			'clearAction' => Notipress::AJAX_CLEAR,
			'confirmClear' => __('Are you sure you want to clear all hidden notices? They will appear again.', Notipress::TEXT_DOMAIN),
		));
	}

	public function ajax_hide_notice() {
		$this->ajax_auth();
		$id = isset($_POST['notice_id']) ? preg_replace('/[^a-zA-Z0-9_-]/', '', (string) $_POST['notice_id']) : '';
		$label = substr(sanitize_text_field((string) ($_POST['notice_label'] ?? '')), 0, 200);
		if ($id === '') wp_send_json_error();

		$hidden = (array) Notipress::get(Notipress::OPT_HIDDEN);
		$ids = Notipress::get_hidden_ids();
		if (!in_array($id, $ids, true)) {
			$hidden[] = array('id' => $id, 'label' => $label);
			update_option(Notipress::OPT_HIDDEN, array_slice($hidden, -50));
		}
		wp_send_json_success();
	}

	public function ajax_clear_notices() {
		$this->ajax_auth();
		update_option(Notipress::OPT_HIDDEN, array());
		wp_send_json_success();
	}

	private function ajax_auth() {
		check_ajax_referer(Notipress::NONCE, 'nonce');
		if (!current_user_can(Notipress::CAP)) wp_send_json_error();
	}
}
