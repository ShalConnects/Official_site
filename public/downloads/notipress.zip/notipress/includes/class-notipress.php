<?php
if (!defined('ABSPATH')) exit;

final class Notipress {
	const TEXT_DOMAIN = 'notipress';
	const OPT_HIDE_ALL = 'notipress_hide_all';
	const OPT_HIDDEN = 'notipress_hidden';
	const SLUG = 'notipress';
	const CAP = 'manage_options';
	const NONCE = 'notipress_nonce';
	const AJAX_HIDE = 'notipress_hide_notice';
	const AJAX_CLEAR = 'notipress_clear_notices';
	const SETTINGS_GROUP = 'notipress_settings';

	private static $defaults = array(
		self::OPT_HIDE_ALL => '0',
		self::OPT_HIDDEN   => array(),
	);

	public static function get($key) {
		return get_option($key, isset(self::$defaults[$key]) ? self::$defaults[$key] : null);
	}

	public static function sanitize_bool($v) {
		return $v === '1' ? '1' : '0';
	}

	/** @return array{id:string, label:string}|null */
	public static function normalize_hidden_item($n) {
		if (is_array($n) && !empty($n['id'])) {
			$id = preg_replace('/[^a-zA-Z0-9_-]/', '', (string) $n['id']);
			if ($id !== '') return array('id' => $id, 'label' => sanitize_text_field(substr((string) ($n['label'] ?? ''), 0, 200)));
		}
		if (is_string($n) && $n !== '') {
			$s = sanitize_text_field(substr($n, 0, 200));
			return array('id' => md5($s), 'label' => $s);
		}
		return null;
	}

	public static function get_hidden_ids() {
		$ids = array();
		foreach ((array) self::get(self::OPT_HIDDEN) as $n) {
			$item = self::normalize_hidden_item($n);
			if ($item) $ids[] = $item['id'];
		}
		return $ids;
	}

	public static function get_hidden_count() {
		return count(self::get_hidden_ids());
	}

	public static function get_option_keys() {
		return array(self::OPT_HIDE_ALL, self::OPT_HIDDEN);
	}
}
