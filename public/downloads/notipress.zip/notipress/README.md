# Notipress

A WordPress plugin to hide annoying admin notifications for a cleaner admin experience.

## Features

- **Hide All Plugin Notices**: Toggle to automatically hide all third-party plugin notices (rating requests, promotional messages, update reminders)
- **Individual Notice Hiding**: Click the × button on any notice to hide it permanently
- **Safe Mode**: WordPress core errors and warnings remain visible for security
- **Easy Management**: Simple settings page to manage all options

## Installation

1. Download the `notipress.zip` file
2. Go to WordPress Admin → Plugins → Add New
3. Click "Upload Plugin"
4. Choose the zip file and click "Install Now"
5. Activate the plugin
6. Go to Settings → Notipress to configure

## Manual Installation

1. Extract the zip file
2. Upload the `notipress` folder to `/wp-content/plugins/`
3. Activate the plugin through the 'Plugins' menu in WordPress
4. Configure settings at Settings → Notipress

## Other ways to distribute (small codebase)

Because Notipress is lightweight, you can share it without the full WordPress.org flow:

- **GitHub / GitLab**: Host the repo and let users clone or download a ZIP from the "Code" button. They can drop the `notipress` folder into `wp-content/plugins/` or upload the ZIP via Plugins → Add New → Upload.
- **Gist**: Paste the main plugin file (or a minimal single-file version) as a Gist; users can copy the code into a new file under `wp-content/plugins/notipress/` (they’ll need to create the folder and any subfolders to match the structure).
- **Direct ZIP**: Share a `notipress.zip` of the plugin folder (e.g. via email, cloud link, or your site). Users install via Plugins → Add New → Upload Plugin.
- **Must-Use (MU) plugin**: For a single site you control, you can put a single PHP file in `wp-content/mu-plugins/` and it will load automatically (no activation). This only works if you collapse the plugin into one file or symlink/copy the folder; the `mu-plugins` directory does not load from subfolders.
- **Snippet plugin**: If you use a “code snippets” plugin (e.g. Code Snippets, WPCode), you can paste the core logic as a snippet. You lose the proper plugin structure and updates, but it’s fine for quick use on your own site.

For most users, **GitHub (or similar) + a downloadable ZIP** is the simplest way to distribute outside the WordPress.org directory.

## Usage

### Hide All Notices
1. Go to Settings → Notipress
2. Check "Hide All Plugin Notices"
3. Click "Save Changes"

### Hide Individual Notices
1. When you see a notice you want to hide, click the × button in the top-right corner
2. The notice will be hidden permanently
3. View hidden notices in Settings → Notipress

### Clear Hidden Notices
1. Go to Settings → Notipress
2. Click "Clear All Hidden Notices"
3. Previously hidden notices will appear again

## What Gets Hidden?

The plugin hides:
- Plugin rating requests
- Update notifications from third-party plugins
- Promotional messages
- Theme recommendations
- WooCommerce admin notices

The plugin DOES NOT hide:
- WordPress core error messages
- WordPress core warning messages
- Security warnings
- Critical update notices

## Requirements

- WordPress 5.0 or higher
- PHP 7.0 or higher

## Support

For support, visit [ShalConnects](https://shalconnects.com/) or the [WordPress.org profile](https://profiles.wordpress.org/shalconnects/).

## License

GPL v2 or later

## Changelog

### Version 1.0.0
- Initial release
- Hide all notices feature
- Individual notice hiding
- Settings page

## Credits

Developed by [ShalConnects](https://shalconnects.com/) · [WordPress.org profile](https://profiles.wordpress.org/shalconnects/)
