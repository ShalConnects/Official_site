<?php
/**
 * Plugin Name: Notipress
 * Plugin URI: https://shalconnects.com/
 * Description: Hide annoying admin notifications for a cleaner admin experience
 * Version: 1.0.0
 * Author: ShalConnects
 * Author URI: https://profiles.wordpress.org/shalconnects/
 * License: GPL v2 or later
 * Text Domain: notipress
 */
if (!defined('ABSPATH')) exit;

define('NOTIPRESS_VERSION', '1.0.0');
define('NOTIPRESS_PLUGIN_URL', plugin_dir_url(__FILE__));

require_once plugin_dir_path(__FILE__) . 'includes/class-notipress.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-notice-hider.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-settings.php';

add_action('plugins_loaded', function () {
	new Notipress_Notice_Hider();
	new Notipress_Settings();
});

register_activation_hook(__FILE__, function () {
	foreach (array(Notipress::OPT_HIDE_ALL => '0', Notipress::OPT_HIDDEN => array()) as $key => $default) {
		add_option($key, $default);
	}
});
