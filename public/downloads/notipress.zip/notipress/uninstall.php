<?php
if (!defined('WP_UNINSTALL_PLUGIN')) exit;
foreach (array('notipress_hide_all', 'notipress_hidden') as $key) {
	delete_option($key);
}
