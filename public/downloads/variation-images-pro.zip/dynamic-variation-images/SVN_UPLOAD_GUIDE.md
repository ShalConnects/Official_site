# Step-by-Step SVN Upload Guide for WordPress.org

## Prerequisites
- SVN access activated (you have this ✓)
- SVN password set up (you have this ✓)
- SVN client installed (we'll check this)

---

## Step 1: Check if SVN is Installed

Open PowerShell or Command Prompt and run:
```bash
svn --version
```

**If SVN is NOT installed:**
- Download TortoiseSVN (Windows GUI): https://tortoisesvn.net/downloads.html
- OR install SVN command line tools
- After installation, restart your terminal

---

## Step 2: Create a Working Directory

Create a folder where you'll work with SVN (outside your plugin folder):

```bash
cd C:\Users\salau\Downloads\Projects
mkdir wp-plugin-svn
cd wp-plugin-svn
```

---

## Step 3: Check Out the SVN Repository

Check out the repository (this downloads the empty structure):

```bash
svn checkout https://plugins.svn.wordpress.org/dynamic-variation-images
```

This will:
- Create a `dynamic-variation-images` folder
- Download the SVN structure (trunk, tags, branches folders)

**Enter your SVN credentials when prompted:**
- Username: `shalconnects`
- Password: (your SVN password)

---

## Step 4: Understand the SVN Structure

After checkout, you'll see:
```
dynamic-variation-images/
├── trunk/          ← Your main plugin code goes here
├── tags/           ← Version releases go here (1.0.1, 1.0.2, etc.)
└── branches/       ← Optional: for development branches
```

---

## Step 5: Copy Your Plugin Files to Trunk

**IMPORTANT:** Only copy the files needed for the free version (remove Pro-only files if this is the free version).

Navigate to your plugin directory and copy files:

```bash
# Navigate to trunk
cd dynamic-variation-images/trunk

# Copy all plugin files (from your plugin directory)
# You can do this manually in File Explorer or use PowerShell:

# From PowerShell, run this (adjust the source path):
Copy-Item -Path "C:\Users\salau\Downloads\Projects\Variation Images Pro\wc-variation-images-pro\*" -Destination "." -Recurse -Exclude @("*.zip", "*.md", "BUILD_INSTRUCTIONS.md", "build-*.sh", "build-*.ps1", "REVIEW_REPLY_EMAIL.txt", "SVN_UPLOAD_GUIDE.md", ".git", ".gitignore")
```

**OR manually copy these files/folders to trunk:**
- ✅ `wc-variation-images-pro.php` (main plugin file)
- ✅ `readme.txt`
- ✅ `uninstall.php`
- ✅ `LICENSE.txt`
- ✅ `includes/` folder
- ✅ `admin/` folder
- ✅ `public/` folder
- ✅ `assets/` folder
- ✅ `languages/` folder

**DO NOT copy:**
- ❌ `.git/` folder
- ❌ `*.zip` files
- ❌ Build scripts (`build-*.sh`, `build-*.ps1`)
- ❌ Documentation files (unless needed)
- ❌ Pro-only files (if this is the free version)

---

## Step 6: Check What Will Be Committed

Before committing, check what files SVN sees:

```bash
cd dynamic-variation-images
svn status
```

This shows:
- `?` = New files (will be added)
- `A` = Files marked for addition
- `M` = Modified files
- `D` = Deleted files

---

## Step 7: Add New Files to SVN

Add all new files to SVN:

```bash
cd dynamic-variation-images
svn add trunk/*
```

If you have subdirectories, add them recursively:

```bash
svn add trunk/* --force
```

---

## Step 8: Commit to Trunk

Commit your files to trunk (this uploads them):

```bash
cd dynamic-variation-images
svn commit -m "Initial plugin upload - Version 1.0.1"
```

**Enter your SVN password when prompted.**

---

## Step 9: Create a Version Tag

After trunk is committed, create a tag for version 1.0.1:

```bash
cd dynamic-variation-images
svn copy trunk tags/1.0.1
svn commit -m "Tagging version 1.0.1"
```

**Why tags?** WordPress.org uses tags to serve specific versions to users.

---

## Step 10: Verify Upload

Check your plugin on WordPress.org:
- Visit: https://wordpress.org/plugins/dynamic-variation-images
- It may take a few minutes to appear

---

## Common Commands Reference

```bash
# Check status
svn status

# Add files
svn add filename
svn add folder/* --force

# Commit changes
svn commit -m "Your commit message"

# Update from repository
svn update

# View differences
svn diff

# Remove file (then commit)
svn delete filename
```

---

## Troubleshooting

**Issue: "Authentication failed"**
- Double-check username: `shalconnects` (case-sensitive)
- Verify SVN password in WordPress.org profile
- Try: `svn checkout --username shalconnects https://plugins.svn.wordpress.org/dynamic-variation-images`

**Issue: "File already exists"**
- Use `svn update` first
- Then add your files

**Issue: "Working copy locked"**
- Run: `svn cleanup`

**Issue: Need to update later**
```bash
cd dynamic-variation-images/trunk
# Make your changes
svn status
svn add new-files (if any)
svn commit -m "Updated to version 1.0.2"
```

---

## Next Steps After Upload

1. **Wait 5-10 minutes** for WordPress.org to process
2. **Check your plugin page**: https://wordpress.org/plugins/dynamic-variation-images
3. **Add plugin assets** (banner, icons) if needed
4. **Test the download** from WordPress.org

---

## Quick Start (All-in-One Commands)

If you want to do it all at once:

```powershell
# 1. Create working directory
cd C:\Users\salau\Downloads\Projects
mkdir wp-plugin-svn
cd wp-plugin-svn

# 2. Checkout repository
svn checkout https://plugins.svn.wordpress.org/dynamic-variation-images

# 3. Copy files (adjust source path)
$source = "C:\Users\salau\Downloads\Projects\Variation Images Pro\wc-variation-images-pro"
$dest = ".\dynamic-variation-images\trunk"
Copy-Item -Path "$source\*" -Destination $dest -Recurse -Exclude @("*.zip", "*.md", "BUILD_INSTRUCTIONS.md", "build-*.sh", "build-*.ps1", "REVIEW_REPLY_EMAIL.txt", "SVN_UPLOAD_GUIDE.md", ".git", ".gitignore")

# 4. Navigate and add files
cd dynamic-variation-images
svn add trunk/* --force

# 5. Commit
svn commit -m "Initial plugin upload - Version 1.0.1"

# 6. Create tag
svn copy trunk tags/1.0.1
svn commit -m "Tagging version 1.0.1"
```

---

**Need help?** Let me know if you encounter any issues!

