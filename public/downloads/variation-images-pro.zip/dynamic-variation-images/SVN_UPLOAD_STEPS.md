# Quick SVN Upload Steps (TortoiseSVN GUI Method)

## Step 1: Create a Working Folder

1. Open File Explorer
2. Navigate to: `C:\Users\salau\Downloads\Projects`
3. Create a new folder: `wp-plugin-svn`
4. Open that folder

---

## Step 2: Check Out the Repository

1. **Right-click** in the empty `wp-plugin-svn` folder
2. Select **"SVN Checkout..."**
3. In the dialog:
   - **URL of repository**: `https://plugins.svn.wordpress.org/dynamic-variation-images`
   - **Checkout directory**: `C:\Users\salau\Downloads\Projects\wp-plugin-svn\dynamic-variation-images`
   - Click **OK**
4. Enter credentials when prompted:
   - **Username**: `shalconnects`
   - **Password**: (your SVN password)
   - Check "Save authentication" if you want
5. Click **OK** and wait for checkout to complete

You should now see a `dynamic-variation-images` folder with `trunk`, `tags`, and `branches` subfolders.

---

## Step 3: Copy Your Plugin Files to Trunk

1. Open the `trunk` folder: `wp-plugin-svn\dynamic-variation-images\trunk`
2. Copy these files/folders from your plugin directory:
   - `wc-variation-images-pro.php`
   - `readme.txt`
   - `uninstall.php`
   - `LICENSE.txt`
   - `includes/` folder
   - `admin/` folder
   - `public/` folder
   - `assets/` folder
   - `languages/` folder

**DO NOT copy:**
   - `.git/` folder
   - `*.zip` files
   - Build scripts
   - Documentation files (unless needed)

---

## Step 4: Add Files to SVN

1. **Right-click** in the `trunk` folder
2. Select **"TortoiseSVN" → "Add..."**
3. Select all the files you copied (or just select the folder and it will add everything)
4. Click **OK**
5. You'll see files marked with a "+" icon (new files to be added)

---

## Step 5: Commit to Trunk

1. **Right-click** in the `trunk` folder
2. Select **"SVN Commit..."**
3. In the commit message box, type: `Initial plugin upload - Version 1.0.1`
4. Review the files list (should show all your plugin files)
5. Click **OK**
6. Enter your SVN password if prompted
7. Wait for commit to complete (you'll see progress)

---

## Step 6: Create Version Tag

1. **Right-click** on the `trunk` folder
2. Select **"TortoiseSVN" → "Branch/tag..."**
3. In the dialog:
   - **To path**: `tags/1.0.1`
   - **Create copy in the repository from**: Select "HEAD revision in the repository"
   - **Log message**: `Tagging version 1.0.1`
4. Click **OK**
5. This creates the tag in the repository

---

## Step 7: Verify

1. Wait 5-10 minutes
2. Visit: https://wordpress.org/plugins/dynamic-variation-images
3. Your plugin should appear!

---

## Visual Guide - TortoiseSVN Icons

- **Green checkmark** = File is up to date
- **Red exclamation** = File has conflicts
- **Blue plus** = File is scheduled for addition
- **Yellow exclamation** = File has been modified
- **Question mark** = File is not under version control

---

## Troubleshooting

**Can't see "SVN Checkout" option?**
- Make sure TortoiseSVN is fully installed
- Try restarting your computer
- Right-click should show "TortoiseSVN" submenu

**Authentication failed?**
- Double-check username: `shalconnects` (case-sensitive)
- Verify password in WordPress.org profile → Account & Security

**Files not showing in commit?**
- Make sure you "Add" them first (Step 4)
- Check that files aren't in `.svn` ignore list

---

**That's it!** Your plugin will be live on WordPress.org shortly.

