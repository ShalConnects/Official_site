<?php
/**
 * Define the internationalization functionality
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Define the internationalization functionality
 */
class WCVIP_i18n {

	/**
	 * Load the plugin text domain for translation
	 * 
	 * Note: For WordPress.org hosted plugins, translations are automatically loaded
	 * since WordPress 4.6, so no manual loading is needed.
	 */
	public function load_plugin_textdomain() {
		// Translations are automatically loaded by WordPress.org
	}
}

