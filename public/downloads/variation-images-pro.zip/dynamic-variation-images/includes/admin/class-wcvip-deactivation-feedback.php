<?php
/**
 * Deactivation Feedback Handler
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles deactivation feedback collection
 */
class WCVIP_Deactivation_Feedback {

	/**
	 * Initialize the feedback system
	 */
	public function __construct() {
		add_action( 'admin_footer', array( $this, 'render_feedback_modal' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		add_action( 'wp_ajax_wcvip_submit_deactivation_feedback', array( $this, 'handle_feedback_submission' ) );
	}

	/**
	 * Enqueue scripts and styles for feedback modal
	 */
	public function enqueue_scripts( $hook ) {
		// Only load on plugins page
		if ( 'plugins.php' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'wcvip-deactivation-feedback',
			WCVIP_PLUGIN_URL . 'assets/admin/css/deactivation-feedback.css',
			array(),
			WCVIP_VERSION
		);

		wp_enqueue_script(
			'wcvip-deactivation-feedback',
			WCVIP_PLUGIN_URL . 'assets/admin/js/deactivation-feedback.js',
			array( 'jquery' ),
			WCVIP_VERSION,
			true
		);

		wp_localize_script(
			'wcvip-deactivation-feedback',
			'wcvipDeactivationFeedback',
			array(
				'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
				'nonce'      => wp_create_nonce( 'wcvip_deactivation_feedback' ),
				'plugin'     => WCVIP_PLUGIN_BASENAME,
				'submitting' => __( 'Submitting...', 'dynamic-variation-images' ),
			)
		);
	}

	/**
	 * Render feedback modal HTML
	 */
	public function render_feedback_modal() {
		$screen = get_current_screen();
		if ( ! $screen || 'plugins' !== $screen->id ) {
			return;
		}
		?>
		<div id="wcvip-deactivation-feedback-modal" class="wcvip-feedback-modal" style="display: none;">
			<div class="wcvip-feedback-modal-overlay"></div>
			<div class="wcvip-feedback-modal-content">
				<div class="wcvip-feedback-modal-header">
					<h2><?php esc_html_e( 'If you have a moment, please let us know why you are deactivating:', 'dynamic-variation-images' ); ?></h2>
				</div>
				<div class="wcvip-feedback-modal-body">
					<form id="wcvip-deactivation-feedback-form">
						<ul class="wcvip-feedback-reasons">
							<li>
								<label>
									<input type="radio" name="reason" value="couldnt_understand" />
									<span><?php esc_html_e( 'I couldn\'t understand how to make it work', 'dynamic-variation-images' ); ?></span>
								</label>
							</li>
							<li>
								<label>
									<input type="radio" name="reason" value="found_better" />
									<span><?php esc_html_e( 'I found a better plugin', 'dynamic-variation-images' ); ?></span>
								</label>
							</li>
							<li>
								<label>
									<input type="radio" name="reason" value="missing_feature" />
									<span><?php esc_html_e( 'The plugin is great, but I need specific feature that you don\'t support', 'dynamic-variation-images' ); ?></span>
								</label>
							</li>
							<li>
								<label>
									<input type="radio" name="reason" value="not_working" />
									<span><?php esc_html_e( 'The plugin is not working', 'dynamic-variation-images' ); ?></span>
								</label>
							</li>
							<li>
								<label>
									<input type="radio" name="reason" value="not_looking_for" />
									<span><?php esc_html_e( 'It\'s not what I was looking for', 'dynamic-variation-images' ); ?></span>
								</label>
							</li>
							<li>
								<label>
									<input type="radio" name="reason" value="didnt_work_as_expected" />
									<span><?php esc_html_e( 'The plugin didn\'t work as expected', 'dynamic-variation-images' ); ?></span>
								</label>
							</li>
							<li>
								<label>
									<input type="radio" name="reason" value="other" />
									<span><?php esc_html_e( 'Other', 'dynamic-variation-images' ); ?></span>
								</label>
							</li>
						</ul>
						<div id="wcvip-feedback-additional" class="wcvip-feedback-additional" style="display: none;">
							<textarea name="additional" placeholder="<?php esc_attr_e( 'Please share your feedback...', 'dynamic-variation-images' ); ?>" rows="4"></textarea>
						</div>
					</form>
				</div>
				<div class="wcvip-feedback-modal-footer">
					<a href="#" class="wcvip-feedback-skip"><?php esc_html_e( 'I rather wouldn\'t say', 'dynamic-variation-images' ); ?></a>
					<button type="button" class="button button-secondary wcvip-feedback-cancel"><?php esc_html_e( 'Cancel', 'dynamic-variation-images' ); ?></button>
					<button type="button" class="button button-primary wcvip-feedback-submit" disabled><?php esc_html_e( 'Submit & Deactivate', 'dynamic-variation-images' ); ?></button>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Handle feedback submission via AJAX
	 */
	public function handle_feedback_submission() {
		// Verify nonce
		if ( ! check_ajax_referer( 'wcvip_deactivation_feedback', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed', 'dynamic-variation-images' ) ) );
		}

		// Check user capability
		if ( ! current_user_can( 'activate_plugins' ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions', 'dynamic-variation-images' ) ) );
		}

		$reason = isset( $_POST['reason'] ) ? sanitize_text_field( wp_unslash( $_POST['reason'] ) ) : '';
		$additional = isset( $_POST['additional'] ) ? sanitize_textarea_field( wp_unslash( $_POST['additional'] ) ) : '';

		// Log feedback (you can extend this to send to your server or store in database)
		$this->log_feedback( $reason, $additional );

		wp_send_json_success( array( 'message' => __( 'Thank you for your feedback!', 'dynamic-variation-images' ) ) );
	}

	/**
	 * Log feedback (can be extended to send to server or store in database)
	 *
	 * @param string $reason The deactivation reason.
	 * @param string $additional Additional feedback text.
	 */
	private function log_feedback( $reason, $additional ) {
		// For WordPress.org compliance, we'll just log locally
		// You can extend this to send to your server if needed (with user consent)
		$feedback_data = array(
			'reason'     => $reason,
			'additional' => $additional,
			'timestamp'  => current_time( 'mysql' ),
			'site_url'   => home_url(),
			'wp_version' => get_bloginfo( 'version' ),
			'wc_version' => defined( 'WC_VERSION' ) ? WC_VERSION : 'N/A',
		);

		// Store in transient for potential retrieval (optional)
		// For WordPress.org, you might want to send this via admin email or store in options
		// For now, we'll just use error_log if WP_DEBUG is enabled
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug logging for feedback
			error_log( 'WCVIP Deactivation Feedback: ' . wp_json_encode( $feedback_data ) );
		}

		// Optionally store in options table (last 10 feedback entries)
		$feedback_log = get_option( 'wcvip_deactivation_feedback_log', array() );
		$feedback_log[] = $feedback_data;
		// Keep only last 10 entries
		if ( count( $feedback_log ) > 10 ) {
			$feedback_log = array_slice( $feedback_log, -10 );
		}
		update_option( 'wcvip_deactivation_feedback_log', $feedback_log );
	}
}

