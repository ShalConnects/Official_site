<?php
/**
 * Pro display styles
 *
 * @package WCVIP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pro styles class
 */
class WCVIP_Pro_Styles {

	/**
	 * Get Pro display styles
	 *
	 * @return array Pro styles array
	 */
	public static function get_pro_styles() {
		return array(
			'buttons'           => __( 'Button Style (Image First)', 'dynamic-variation-images' ),
			'buttons_text_first' => __( 'Button Style (Text First)', 'dynamic-variation-images' ),
			'square'            => __( 'Square Thumbnails', 'dynamic-variation-images' ),
			'circular'          => __( 'Circular Thumbnails', 'dynamic-variation-images' ),
		);
	}

	/**
	 * Check if Pro styles are available
	 *
	 * @return bool
	 */
	public static function is_available() {
		return WCVIP_IS_PRO && class_exists( __CLASS__ );
	}
}

