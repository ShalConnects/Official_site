# WordPress.org Plugin Assets Guide

## Required Images

### 1. Plugin Icon (Required)
- **Size:** 256x256 pixels
- **Format:** PNG or JPG
- **Filename:** `icon-256x256.png` (or `.jpg`)
- **Location:** `assets/icon-256x256.png`
- **Usage:** Displayed in plugin directory listings

### 2. Plugin Banner (Recommended)
- **Size:** 772x250 pixels (or 1544x500 for high-DPI)
- **Format:** PNG or JPG
- **Filename:** `banner-772x250.png` (or `.jpg`)
- **Location:** `assets/banner-772x250.png`
- **Usage:** Displayed at the top of your plugin page

### 3. Screenshots (Optional but Recommended)
- **Size:** 1200px wide (height can vary)
- **Format:** PNG or JPG
- **Filenames:** `screenshot-1.png`, `screenshot-2.png`, etc.
- **Location:** `assets/screenshot-1.png`, etc.
- **Usage:** Displayed in a gallery on your plugin page
- **Limit:** Up to 5 screenshots

---

## Step-by-Step: Adding Assets

### Step 1: Prepare Your Images

Create or prepare these images:
1. **Icon:** 256x256px square icon/logo
2. **Banner:** 772x250px banner image
3. **Screenshots:** Up to 5 screenshots (1200px wide)

**Design Tips:**
- Icon should be clear and recognizable at small sizes
- Banner should showcase your plugin's main features
- Screenshots should demonstrate key functionality

### Step 2: Copy Images to Assets Folder

1. Open File Explorer
2. Navigate to: `C:\Users\salau\Downloads\Projects\Variation Images Pro\svn\assets`
3. Copy your prepared images here:
   - `icon-256x256.png`
   - `banner-772x250.png`
   - `screenshot-1.png`
   - `screenshot-2.png`
   - (etc.)

### Step 3: Add Files to SVN

1. **Right-click** in the `assets` folder
2. Select **"TortoiseSVN" → "Add..."**
3. Select all your image files
4. Click **OK**

### Step 4: Commit Assets

1. **Right-click** in the `assets` folder
2. Select **"SVN Commit..."**
3. Commit message: `Add plugin assets (icon, banner, screenshots)`
4. Click **OK**
5. Enter your SVN password if prompted

### Step 5: Wait and Verify

1. Wait 5-10 minutes for WordPress.org to process
2. Visit: https://wordpress.org/plugins/dynamic-variation-images
3. Your assets should appear!

---

## File Structure

Your SVN structure should look like:
```
svn/
├── assets/
│   ├── icon-256x256.png
│   ├── banner-772x250.png
│   ├── screenshot-1.png
│   ├── screenshot-2.png
│   └── screenshot-3.png
├── trunk/
├── tags/
└── branches/
```

---

## Image Specifications Summary

| Asset | Size | Format | Required | Filename |
|-------|------|--------|----------|----------|
| Icon | 256x256px | PNG/JPG | ✅ Yes | `icon-256x256.png` |
| Banner | 772x250px | PNG/JPG | ⭐ Recommended | `banner-772x250.png` |
| Screenshot 1 | 1200px wide | PNG/JPG | ⭐ Recommended | `screenshot-1.png` |
| Screenshot 2 | 1200px wide | PNG/JPG | Optional | `screenshot-2.png` |
| Screenshot 3-5 | 1200px wide | PNG/JPG | Optional | `screenshot-3.png` etc. |

---

## Quick Commands (If Using Command Line)

```bash
# Navigate to assets folder
cd "C:\Users\salau\Downloads\Projects\Variation Images Pro\svn\assets"

# Add all images
svn add *.png *.jpg

# Commit
svn commit -m "Add plugin assets"
```

---

## Design Resources

**Free Tools:**
- Canva (https://www.canva.com) - Easy banner/icon creation
- GIMP (https://www.gimp.org) - Free image editor
- Figma (https://www.figma.com) - Design tool

**Templates:**
- WordPress.org provides templates (check their documentation)

---

## Troubleshooting

**Images not appearing?**
- Wait 10-15 minutes (caching)
- Check filenames are exact (case-sensitive)
- Verify file sizes match requirements
- Ensure files are committed to SVN

**Wrong dimensions?**
- Use image editor to resize
- Maintain aspect ratio for screenshots
- Icon must be exactly 256x256px

---

**Need help creating the images?** Let me know and I can guide you through the design process!

